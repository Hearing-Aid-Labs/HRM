<?php
class Commision extends \Eloquent {


	// Add your validation rules here
	public static $rules = [
		 'tier_amount' => 'required',
         'comm_type'     =>  'required',
         'comm_amount'     =>  'required'
	];



	// Don't forget to fill this array
	protected $fillable = [];

    protected $guarded  =   ['id'];

}