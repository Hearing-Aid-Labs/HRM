<?php
class Employee_other_claims extends \Eloquent {


	// Add your validation rules here
	public static $rules = [
         'employee_monthly_claim_id' => 'required',
         'claim_amount' => 'required',
         'claim_reason' => 'required',
	];
	// Don't forget to fill this array
	protected $fillable = [];

    protected $guarded  =   ['id'];
    protected function employee_mothly_claim()
    {
        return $this->belongsTo('employee_mothly_claims','employee_monthly_claim_id','id');
    }

}