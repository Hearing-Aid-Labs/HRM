<?php
class Employee_monthly_claims extends \Eloquent {


	// Add your validation rules here
	public static $rules = [
		 'bto_amount' => 'required',
         'target_amount'     =>  'required',
		 'commision_applicable' => 'required',
         'commision_percentage'     =>  'required',
         'for_month'     =>  'required',
	];



	// Don't forget to fill this array
	protected $fillable = [];

    protected $guarded  =   ['id'];
	public function employee_other_claims(){
        return $this->hasMany('Employee_other_claims','employee_monthly_claim_id','id');
    }
}