<?php
class Commision_config extends \Eloquent {


	// Add your validation rules here
	public static $rules = [
		 'target_amount' => 'required',
         'commision_enabled'     =>  'required',
	];



	// Don't forget to fill this array
	protected $fillable = [];

    protected $guarded  =   ['id'];

}