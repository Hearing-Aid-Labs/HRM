@extends('admin.adminlayouts.adminlayout')

@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css")}}
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->
@stop


@section('mainarea')
  <h3 class="page-title">
			   Attendance <small>Attendance sheet</small>
			</h3>
		<table class="table table-bordered">
		<thead>
		  <th>Branch</th>
		  <th>Employee</th>
		  <th>Date</th> 
		  <th>Start work</th> 
		  <th>Leave work</th> 
		  <th>Join Office</th> 
		  <th>Leave Office</th> 

		</thead>
		@foreach($departments as $department)
		<tr>
		<?php 
		$employees=DB::table('employees')->join('designation','employees.designation','=','designation.id')
		->leftJoin('attendance_log',function($join) use ($date)
			  {
			   $join->on('attendance_log.employee_id','=','employees.id');
			   $join->where('attendance_log.date','=',$date);
		   })
		->leftJoin('office_timing','office_timing.department_id','=','designation.deptID')  
		->where('designation.deptID',$department->id)
		->where('status','active')
		->groupBy('employees.id')
		->get();

		?>
		<th rowspan="{{count($employees)}}">{{  $department->deptName  }}</th>
		@if(count($employees)>0)
		<?php   $employee=$employees[0];  ?>	
			<td>{{  $employee->fullName  }}</td>	
			<td>{{ date('d-M-y',strtotime($date)) }}</td>
			<td>{{ isset($employee->start_time) ? date('H:i',strtotime($employee->start_time)):"" }}</td>
			<td>{{ isset($employee->end_time) ? date('H:i',strtotime($employee->end_time)):"" }}</td>
			<td><?php if(isset($employee->start_time) && isset($employee->open_timing)){  
					$difference=strtotime(date('H:i:s',strtotime($employee->start_time)))-strtotime(date('H:i:s',strtotime($employee->open_timing)));
					if($difference==0){ echo "On Time";	}
				   else if($difference<0){ echo "Early";	}
					else{
						 if(gmdate("H",$difference)!=0) { 
						  echo ltrim(gmdate("H",$difference),'0')." Hours";
						  }  
						 if(gmdate("i",$difference)!=0){ 
							echo ltrim(gmdate("i",$difference),'0')." Minutes";
						  } 
						  echo " Late";
					}
				   ?> 
				  
				<?php  } ?>
			   </td>
			   <td>
			   <?php if(isset($employee->end_time) && isset($employee->close_timing)){  
					$difference=strtotime(date('H:i:s',strtotime($employee->close_timing)))-strtotime(date('H:i:s',strtotime($employee->end_time)));
					if($difference==0){ echo "On Time";	}
				   else if($difference<0){ echo "Late";	}
					else{
						 if(gmdate("H",$difference)!=0) { 
						  echo ltrim(gmdate("H",$difference),'0')." Hours";
						  }  
						 if(gmdate("i",$difference)!=0){ 
							echo ltrim(gmdate("i",$difference),'0')." Minutes";
						  } 
						  echo " Early";
					}
				   ?> 
				  
				<?php  } ?>
			   
			   </td>
			
			   
		@endif	

		</tr>
		<?php  $i=1;  ?>
			@foreach($employees as $employee)
			<?php  
			if($i==1)
			{
				$i++;
				continue;
			}
			?>
			 <tr>
			  <td>{{  $employee->fullName }}</td>
			  <td>{{ date('d-M-y',strtotime($date)) }}</td>
			   <td>{{ isset($employee->start_time) ? date('H:i',strtotime($employee->start_time)):"" }}</td>
			   <td>{{ isset($employee->end_time) ? date('H:i',strtotime($employee->end_time)):"" }}</td>
			   <td><?php if(isset($employee->start_time) && isset($employee->open_timing)){  
					$difference=strtotime(date('H:i:s',strtotime($employee->start_time)))-strtotime(date('H:i:s',strtotime($employee->open_timing)));
					if($difference==0){ echo "On Time";	}
				   else if($difference<0){ echo "Early";	}
					else{
						 if(gmdate("H",$difference)!=0) { 
						  echo ltrim(gmdate("H",$difference),'0')." Hours";
						  }  
						 if(gmdate("i",$difference)!=0){ 
							echo ltrim(gmdate("i",$difference),'0')." Minutes";
						  } 
						  echo " Late";
					}
				   ?> 
				  
				<?php  } ?>
			   </td>
			   <td>
			   <?php if(isset($employee->end_time) && isset($employee->close_timing)){  
					$difference=strtotime(date('H:i:s',strtotime($employee->close_timing)))-strtotime(date('H:i:s',strtotime($employee->end_time)));
					if($difference==0){ echo "On Time";	}
				   else if($difference<0){ echo "Late";	}
					else{
						 if(gmdate("H",$difference)!=0) { 
						  echo ltrim(gmdate("H",$difference),'0')." Hours";
						  }  
						 if(gmdate("i",$difference)!=0){ 
							echo ltrim(gmdate("i",$difference),'0')." Minutes";
						  } 
						  echo " Early";
					}
				   ?> 
				  
				<?php  } ?>
			   
			   </td>
			  
			   
			 </tr>
			@endforeach
		@endforeach
		</table>
@stop


@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    {{ HTML::script("assets/admin/pages/scripts/table-managed.js")}}
    {{HTML::script("assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js")}}
    {{HTML::script("assets/admin/pages/scripts/components-pickers.js")}}

<!-- END PAGE LEVEL PLUGINS -->

	

@stop
	