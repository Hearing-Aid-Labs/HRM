@extends('admin.adminlayouts.adminlayout')

@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css")}}
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->
@stop


@section('mainarea')
	 <?php  if(Session::has('success_message')){  ?>
     <div class="alert alert-success">
	    {{ Session::get('success_message')  }}
	 </div>
   
   <?php }   ?>
  	<h3 class="page-title">
			   {{$pageTitle}} <small>Office timings</small>
			</h3>
	<div class="row">

	 <div class="col-md-12">
	 	<a href="#" style="margin-bottom:10px" data-toggle="modal" data-target="#add_modal" class="btn green">
                    Add New
                    </a>
       <div class="portlet box blue">
	      <div class="portlet-title">
		     <div class="caption">
							<i class="fa fa-users"></i>Office Timings
		     </div> 
		  
		  </div>
		  <div class="portlet-body">
				<table class="table table-striped table-bordered table-hover">
				  <thead>
				  <th>Department</th>
				  <th>Opening Time</th>
				  <th>Close Time</th>
				  <th></th>
				  </thead>
				  <tbody>
				  @foreach($office_timings as $office_timing)
				      <tr>
					     <td>{{  $office_timing->deptName }}</td>
						 <td>{{  $office_timing->open_timing }}</td>
						 <td>{{  $office_timing->close_timing }}</td>
					     <td><a href="javascript:;" onclick='edit_office_timing(<?= $office_timing->timing_id ?>)' class="btn btn-success">Edit</a></td>
					  </tr>
				  @endforeach
				  </tbody>
				
				</table>
		  
		  </div>
	   
	   
	   </div>
	  </div> 
   </div>

 		<div id="add_modal"  class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
								<h4 class="modal-title"><strong>Add New</strong></h4>
						</div>
						<div class="modal-body">
						<form method="post" action="/admin/attendances/save_office_timings">
						  <input type="hidden" name="_token" value="{{Session::token()}}">
						  <div class="form-group">
						     <label>Department</label>
						     <select name="department" class="form-control">
							   <?php foreach($departments as $department){  ?>
							     <option value="<?= $department->id?>"><?=  $department->deptName ?></option>
							   
							  <?php  }   ?>
							 
							 </select>
						  </div>
						  <div class="form-group">
						     <label>Open Time</label>
						      <input  id="start_time_hours" required="required" value="" name="start_time_hours"><b>:</b><input required="required" value="0" name="start_time_minutes" value="00"  id="start_time_minutes">
						  </div>
						  <div class="form-group">
						     <label>Close Time</label>
						     <input  id="end_time_hours" required="required" value="" name="end_time_hours"><b>:</b><input  required="required"  name="end_time_minutes" value="0"  id="end_time_minutes">
						  </div>
						  <input type="submit" value="save" class="btn btn-success">
						  </form>
						</div>
						
				</div>	
			</div>
      </div>									
	<div id="edit_modal"  class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
								<button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
								<h4 class="modal-title"><strong>Edit</strong></h4>
						</div>
						<div class="modal-body">
						   <div id="edit_office_timings">
						   
						   
						   </div>
						</div>
						
				</div>	
			</div>
      </div>									
	
     



@stop


@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    {{ HTML::script("assets/admin/pages/scripts/table-managed.js")}}
    {{HTML::script("assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js")}}
    {{HTML::script("assets/admin/pages/scripts/components-pickers.js")}}

<!-- END PAGE LEVEL PLUGINS -->

	<script>
	jQuery(document).ready(function($) {
	  
	
        ComponentsPickers.init();
	   TableManaged.init();
	});
	</script>
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/smoothness/jquery-ui.css">
     <script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	 <script>
	 function edit_office_timing(id)
	 {
		$.get('/admin/attendances/edit_office_timings/'+id,function(data){
			
			$("#edit_office_timings").html(data);
			$("#edit_modal").modal('show');
		});
		
      
	 }
	 $(function($){
        $( "#start_time_hours" ).spinner({
			 max: 24,
			 min: 1
		});
	    $( "#end_time_hours" ).spinner({
			 max: 24,
			 min: 1
		});
		$( "#start_time_minutes" ).spinner({
			 max: 60,
			 min: 1
		});
		$( "#end_time_minutes" ).spinner({
			 max: 60,
			 min: 1
		});
	  
	 });
	 </script>

@stop
	