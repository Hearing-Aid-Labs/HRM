<form method="post" action="/admin/attendances/save_office_timings">
						  <input type="hidden" name="_token" value="{{Session::token()}}">
						  <div class="form-group">
						     <label>Department</label>
						     <select disabled="disabled"  class="form-control">
							   <?php foreach($departments as $department){  ?>
							   <option <?php if ($department->id==$office_timing->department_id) { ?> selected="selected" <?php }  ?> value="<?= $department->id?>"><?=  $department->deptName ?></option>
							   
							  <?php  }   ?>
							 
							 </select>
							 <input type="hidden" name="department" value="<?= $office_timing->department_id ?>">
						  </div>
						  <div class="form-group">
						     <label>Open Time</label>
						      <input  id="edit_start_time_hours" required="required" value="<?= $open_hours ?>" name="start_time_hours"><b>:</b><input required="required" value="<?= $open_minutes ?>" name="start_time_minutes" value="00"  id="edit_start_time_minutes">
						  </div>
						  <div class="form-group">
						     <label>Close Time</label>
						     <input  id="edit_end_time_hours" required="required" value="<?= $end_hours ?>" name="end_time_hours"><b>:</b><input  required="required"  name="end_time_minutes" value="<?= $end_minutes ?>"  id="edit_end_time_minutes">
						  </div>
						  <input type="submit" value="save" class="btn btn-success">
						  </form>
						  <script>
						   $(function($){
								$( "#edit_start_time_hours" ).spinner({
									 max: 24,
									 min: 1
								});
								$( "#edit_end_time_hours" ).spinner({
									 max: 24,
									 min: 1
								});
								$( "#edit_start_time_minutes" ).spinner({
									 max: 60,
									 min: 1
								});
								$( "#edit_end_time_minutes" ).spinner({
									 max: 60,
									 min: 1
								});
							  
	                    });
						  
						  
						  
						  
						  
						  
						  
						  </script>
						  