@extends('admin.adminlayouts.adminlayout')

@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css")}}
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->
@stop


@section('mainarea')
			<h3 class="page-title">
			   {{$pageTitle}} <small>Attendance Log</small>
			</h3>
			<div style="margin-bottom:10px" class="input-group input-medium date date-picker" data-date-format="yyyy-mm-dd" data-date-viewmode="years">
				<input type="text" class="form-control" id="date_filter" name="date" readonly="" placeholder="select Date">
					<span class="input-group-btn">
					  <button data-loading-text="Redirecting..." class="demo-loading-btn btn blue"><i class="fa fa-calendar"></i></button>
				   </span>
			</div>
            <table class="table table-striped table-bordered table-hover" id="table_sample">
                                     <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Employee</th>
                                        <th>Date</th>
                                        <th>Start work</th>
                                        <th>Leave work</th>
										<th>Join Office</th>
										<th>Leave Office</th>
                                       <th></th>

                                    </tr>
                                    </thead>
								    <tbody>
									
									
									
									</tbody>
				</table>					


<script>
function view_time_log(date,employeeID)
{
	$.get('/admin/attendances/view_timelog/'+date+"/"+employeeID,function(data){
		$("#time_log").modal('show');
		$("#time_log_response").html(data);
		
	});
	
}
function generateTable()
{
        $('#table_sample').dataTable( {
            "bProcessing": true,
            "bServerSide": true,
            "sAjaxSource": "/admin/attendances/get_attendance_daily_log",
			'fnServerData': function (sSource, aoData, fnCallback) {
                aoData.push({
                    "name": "_token",
                    "value": "<?= Session::token()  ?>",
					
                });
				aoData.push({
					"name":"date", 
					 "value":$("#date_filter").val()
				 });
				 
				
				
                $.ajax({'dataType': 'json', 'type': 'POST', 'url': sSource, 'data': aoData, 'success': fnCallback});
            },
            "aaSorting": [[ 1, "asc" ]],
            "lengthMenu": [
                            [10, 15, 20, 5000],
                            [10, 15, 20, "All"] // change per page values here
                        ],

            "sPaginationType": "full_numbers",
            "fnRowCallback": function( nRow, aData, iDisplayIndex ) {
                var row = $(nRow);
                row.attr("id", 'row'+aData['0']);
            },
			 "order": [[ 2, "desc" ]],
			"aoColumns": [null,null,null,{"mRender":function(data,type,row){
                  if(data!=null)
				  {
					  var d = new Date(data);
					  return d.getHours()+":"+d.getMinutes();
				  }else
				  {
					  return data;
				  }
                 }},{"mRender":function(data,type,row){
                  if(data==null)
				  {
					  return "";
				  }else
				  {
					 var d = new Date(data);
					  return d.getHours()+":"+d.getMinutes();
				  }
                 }}/*,{"mRender":function(data,type,row){
}
				if(row[4]!=null)
				{
				   var startTime = new Date(row[3]); 
				   var endTime = new Date(row[4]);
				    var difference = endTime.getTime() - startTime.getTime(); // This will give difference in milliseconds
                    var resultInMinutes = Math.round(difference / 60000);
				    var hours = Math.floor(resultInMinutes / 60);          
                    var minutes =resultInMinutes % 60;
			    	return hours+" hours and "+minutes+" minutes";
				}
				else{
					
					return "";
				}
			  }}*/,{"mRender":function(data,type,row){
                   if(data==null)
                   {
					   return "";
				   } 
				   var startTime = new Date(row[3]); 
				   start_hours= startTime.getHours();
				   start_minutes=startTime.getMinutes();
				   startDate=new Date('<?= date('Y-m-d')?>'+" "+start_hours+":"+start_minutes+":00");
				   var openingTime = new Date('<?= date('Y-m-d')." "?>'+data);
				    var difference =  startDate.getTime() - openingTime.getTime();
				  if(difference==0)
				  {
					  return "On Time";
				  }
				  else if(difference<0)
				  {
					  return "Early";
				  }
                  else
				  { 	  
						var resultInMinutes = Math.round(difference / 60000);
						var hours = Math.floor(resultInMinutes / 60);          
						var minutes =resultInMinutes % 60;
						if(hours>0)
						{
						  return hours+" hours and "+minutes+" minutes Late";	
						
						}	
						else{
							
							 return minutes+" minutes Late";	
						}
					  }		  
				  
				}},{"mRender":function(data,type,row){ 
					  if(row[4]==null || data==null)
					  {
						  return "";
					  }
					   var endTime = new Date(row[4]); 
					   end_hours= endTime.getHours();
					   end_minutes=endTime.getMinutes();
					   endDate=new Date('<?= date('Y-m-d')?>'+" "+end_hours+":"+end_minutes+":00");
					   var closeTime = new Date('<?= date('Y-m-d')." "?>'+data);
						var difference =  closeTime.getTime()- endDate.getTime();
						
					  if(difference==0)
					  {
						  return "On Time";
					  }
					  else if(difference<0)
					  {
						   return "Late";
					  }
					  else
					  { 	  
							var resultInMinutes = Math.round(difference / 60000);
							var hours = Math.floor(resultInMinutes / 60);          
							var minutes =resultInMinutes % 60;
							if(hours>0)
							{
							  return hours+" hours and "+minutes+" minutes Left Early";	
							
							}	
							else{
								
								 return minutes+" minutes Left Early";	
							}
						}		 
				  
				}},{"mRender":function(data,type,row){
					return "<a class='btn btn-primary' onclick='view_time_log(\""+row[2]+"\",\""+row[0]+"\")'>View Time Log</a>";
					
					}}]
			

        });
		
}




</script>
<div id="time_log"  class="modal fade" tabindex="-1" data-backdrop="static" data-keyboard="false">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h4 class="modal-title"><strong>View Time Log</strong></h4>
                                            </div>
                                            <div class="modal-body">
											  <div id="time_log_response">
											  
											  </div>
											
											</div>
										</div>	
									</div>
</div>									
	
											

@stop


@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    {{ HTML::script("assets/admin/pages/scripts/table-managed.js")}}
    {{HTML::script("assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js")}}
    {{HTML::script("assets/admin/pages/scripts/components-pickers.js")}}

<!-- END PAGE LEVEL PLUGINS -->

	<script>
	jQuery(document).ready(function($) {
	   	$("#date_filter").change(function(){
			//$('#table_sample').dataTable().fnDestroy();
		//	generateTable();
		window.location="{{URL::to('/')}}/admin/attendances/view_sheet/"+$("#date_filter").val();
		});
		generateTable();
        ComponentsPickers.init();
	   TableManaged.init();
	});
	</script>

@stop
	