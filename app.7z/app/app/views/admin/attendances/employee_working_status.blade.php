@extends('admin.adminlayouts.adminlayout')
@section('head')
    {{HTML::style("assets/global/plugins/bootstrap-switch/css/bootstrap-switch.min.css")}}
    {{HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css")}}


@stop
@section('mainarea')
<script type="text/javascript" src="http://static.fusioncharts.com/code/3.4.0-alpha1/fusioncharts.js"></script>
<script type="text/javascript" src="http://static.fusioncharts.com/code/3.4.0-alpha1/fusioncharts.charts.js"></script>
<div class="portlet box blue">
   <div class="portlet-title">
    <div class="caption">  Employee Working status</div>
   
   </div>
   <div class="portlet-body">
       <div id="chart-container" style="width:100%"></div>
   
   </div>
</div>
<div class="portlet box blue">
   <div class="portlet-title">
    <div class="caption"> Working Employees</div>
   </div>
   <div class="portlet-body">
    @foreach($working_employees as $employee)
           <p>{{  $employee->fullName }}   {{   $employee->fatherName   }}</p>
      @endforeach
   
    </div>
</div>
<div class="portlet box blue">
   <div class="portlet-title">
      <div class="caption">Not  Working Employees</div>
   </div>
   <div class="portlet-body">
    @foreach($not_working_employees  as $employee)
           <p>{{  $employee->fullName }}  {{   $employee->fatherName   }}</p>
      @endforeach
   
    </div>
</div>

  
      
      <script>
      FusionCharts.ready(function () {
    var ageGroupChart = new FusionCharts({
        type: 'pie2d',
        renderAt: 'chart-container',
        width: '450',
        height: '300',
        dataFormat: 'json',
        dataSource: {
            "chart": {
                "caption": "",
                    "subCaption": "",
                    "paletteColors": "#6baa01,#ff0000",
                    "bgAlpha": "0",
                    "borderAlpha": "20",
                    "use3DLighting": "0",
                    "showShadow": "0",
                    "enableSmartLabels": "0",
                    "startingAngle": "20",
                    "showLabels": "0",
                    "showLegend": "1",
                    "legendShadow": "0",
                    "legendBorderAlpha": "0",
                    "enableMultiSlicing": "0",
                    "slicingDistance": "15",
                    "showPercentValues": "1",
                    "showPercentInTooltip": "0",
                    "decimals": "1"
            },
                "data": [{
                "label": "Employee Working",
                    "value": "{{ count($working_employees )   }}"
            }, {
                "label": "Employee Not working",
                    "value": "{{ count($not_working_employees )   }}"
            }]
         }
       });
       ageGroupChart.render();
    });
      
      
      </script>
@stop
