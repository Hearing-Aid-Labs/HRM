<?php  if($total_time_worked!=0){ ?>
<h3>
<?php if(gmdate("H",$total_time_worked)!=0) { ?>
   <?php echo ltrim(gmdate("H",$total_time_worked),'0');?> Hours
<?php  }  ?>
<?php  if(gmdate("i",$total_time_worked)!=0){  ?>
<?php echo ltrim(gmdate("i",$total_time_worked),'0');?> Minutes
<?php  }  ?>
<?php if(gmdate("s",$total_time_worked)!=0) {   ?>
 <?php echo ltrim(gmdate("s",$total_time_worked),'0');?> Seconds</h3>
 
<?php } ?>

<?php  }?>

<table class="table table-bordered">
<thead>
 <tr>
	<th>Start Time</th>
	<th>Stop Time</th>
 </tr>	
</thead>
<tbody>
@if(count($time_log)>0)
	@foreach($time_log as $time)
	  <tr>
	   <td>{{  $time->start_time }}</td>
	   <td>{{  $time->end_time }}</td>
	  
	  
	  </tr>
	@endforeach
@else
	<tr>
	   <td colspan="10">No data Found</td>
	</tr>
@endif

</tbody>


</table>