<?php
include 'config.php';

// Number of records fetch
$numberofrecords = 10;

if(!isset($_POST['searchTerm'])){

	// Fetch records
	$stmt = $conn->prepare("SELECT DISTINCT(designation) FROM designation ORDER BY designation LIMIT :limit");
	$stmt->bindValue(':limit', (int)$numberofrecords, PDO::PARAM_INT);
	$stmt->execute();
	$usersList = $stmt->fetchAll();

}else{

	$search = $_POST['searchTerm'];// Search text
	
	// Fetch records
	$stmt = $conn->prepare("SELECT DISTINCT(designation) FROM designation WHERE designation like :designation ORDER BY designation LIMIT :limit");
	$stmt->bindValue(':designation', '%'.$search.'%', PDO::PARAM_STR);
	$stmt->bindValue(':limit', (int)$numberofrecords, PDO::PARAM_INT);
	$stmt->execute();
	$usersList = $stmt->fetchAll();

}
	
$response = array();

// Read Data
foreach($usersList as $user){
	$response[] = array(
		"id" => $user['id'],
		"text" => $user['designation']
	);
}

echo json_encode($response);
exit();
