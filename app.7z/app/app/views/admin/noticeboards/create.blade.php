@extends('admin.adminlayouts.adminlayout')

@section('head')
    <!-- BEGIN PAGE LEVEL STYLES -->
    {{HTML::style("assets/global/plugins/bootstrap-select/bootstrap-select.min.css")}}
    {{HTML::style("assets/global/plugins/select2/select2.css")}}
    {{HTML::style("assets/global/plugins/jquery-multi-select/css/multi-select.css")}}

  <meta charset="UTF-8">
        <!-- jQuery -->
        <script src='jquery-3.4.1.min.js' type='text/javascript'></script>



    <!-- BEGIN THEME STYLES -->

@stop

 @section('mainarea')
<?php
header('Content-Type: application/json');
require_once ("dbconn.php");
require_once ("sql.php");
$term = trim(strip_tags($_GET['q']));
$sql = new sql();
$countrylist = $sql->getAllCountry($term);
$country = array();
$i = 0;
foreach ($countrylist[1] as $key) {
	$countrylist[1][$i]['desc'] = $key['country_code'].' - '.$key['country_name'];;
	$countrylist[1][$i]['id'] = $key['country_code'];
	$i++;
}
$country['items'] = $countrylist[1];
echo json_encode($country);
?>


			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			{{$pageTitle}}
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="{{route('admin.dashboard.index')}}">Home</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="{{ route('admin.noticeboards.create') }}">Notice</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="">New Notice</a>
					</li>
				</ul>

			</div>
			<!-- END PAGE HEADER-->
			<!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->

                {{--INLCUDE ERROR MESSAGE BOX--}}
                      @include('admin.common.error')
                {{--END ERROR MESSAGE BOX--}}


					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-plus"></i>New Notice
							</div>
							<div class="tools">
							</div>
						</div>

						<div class="portlet-body form">

						<!-- BEGIN FORM-->
						{{Form::open(array('route'=>["admin.noticeboards.update",$notice->id],'class'=>'form-horizontal form-bordered','method'=>'PATCH'))}}


                                    <div class="form-body">

                                        <div class="form-group">
                                        <label class="col-md-2 control-label">Title: <span class="required">
                                        * </span>
                                            </label>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" name="title" placeholder="Title" value="{{$notice->title}}">
                                            </div>
                                        </div>
                                        <div class="form-group">
										                                        <label class="col-md-2 control-label">DES: <span class="required">
										                                        * </span>
										                                            </label>
										                                            <div class="col-md-6">
																												<select class="select2"></select>
																						<div>
																					</div> </div>

	                                      </div>



	<script
	src="https://code.jquery.com/jquery-2.2.4.js"
	integrity="sha256-iT6Q9iMJYuQiMWNd9lDyBUStIq/8PuOW33aOqmvFpqI="
	crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
	<script type="text/javascript">
		$(".select2").select2({
			placeholder: "Search country here...",
			width: '175px',
			ajax: {
				url: "ajax.php",
				dataType: 'json',
				delay: 250,
				data: function (params) {
					return {
		          q: params.term, // search term
		          page: params.page
		      };
		  },
		  processResults: function (data, params) {
		  	params.page = params.page || 1;
		  	return {
		  		results: data.items,
		  		pagination: {
		  			more: (params.page * 30) < data.total_count
		  		}
		  	};
		  },
		  cache: false
		},
			// escapeMarkup: function (markup) { return markup; }, // let our custom formatter work
			minimumInputLength: 1,
			templateResult: formatRepo,
			templateSelection: formatRepoSelection
		});

		function formatRepo (repo) {
			if (repo.loading) return repo.text;
			return repo.desc;
		}

		function formatRepoSelection (repo) {
			return repo.desc || repo.text;
		}
	</script>
                                        <div class="form-group"> <label class="col-md-2 control-label">Description: <span class="required"> * </span> </label>
										<div class="col-md-6"> <textarea class="form-control" name="description" rows="3">{{$notice->description}}</textarea>

                                            </div>
                                        </div>
                                         <div class="form-group">
                                                        <label class="col-md-2 control-label">Description: <span class="required">
                                                            * </span>
                                                            </label>
                                                            <div class="col-md-6">

								   <!-- jQuery library -->
								   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

								   <!-- JS & CSS library of MultiSelect plugin -->
								   <script src="multiselect/jquery.multiselect.js"></script>
								   <link rel="stylesheet" href="multiselect/jquery.multiselect.css">



								   <select name="langOpt[]" multiple id="langOpt">
								       <option value="C++">C++</option>
								       <option value="C#">C#</option>
								       <option value="Java">Java</option>
								       <option value="Objective-C">Objective-C</option>
								       <option value="JavaScript">JavaScript</option>
								       <option value="Perl">Perl</option>
								       <option value="PHP">PHP</option>
								       <option value="Ruby on Rails">Ruby on Rails</option>
								       <option value="Android">Android</option>
								       <option value="iOS">iOS</option>
								       <option value="HTML">HTML</option>
								       <option value="XML">XML</option>
								   </select>

								   <script>
								   $('#langOpt').multiselect({
								       columns: 1,
								       placeholder: 'Select Languages'
								   });



								   $('#langOpt').multiselect({
								       columns: 1,
								       placeholder: 'Select Languages',
								       search: true
								   });


								   $('#langOpt').multiselect({
								       columns: 1,
								       placeholder: 'Select Languages',
								       search: true,
								       selectAll: true
								   });


								   $('#langOptgroup').multiselect({
								       columns: 4,
								       placeholder: 'Select Languages',
								       search: true,
								       selectAll: true
								   });



</script>

                                                    </div>
                                                    </div>

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">
                                               <button type="submit" data-loading-text="Updating..." class="demo-loading-btn btn green">
                                               												<i class="fa fa-check"></i>	Update </button>


                                                </div>
                                            </div>
                                        </div>
                                {{ Form::close() }}
                                    <!-- END FORM-->
                                    <!-- END FORM-->

						</div>
					</div>

                                        <div class="form-actions">
                                            <div class="row">
                                                <div class="col-md-offset-3 col-md-9">

                                                       <button type="submit" data-loading-text="Submitting..." class="demo-loading-btn btn green">
																								<i class="fa fa-plus"></i>	Submit </button>

                                                </div>
                                            </div>
                                        </div>
                                {{ Form::close() }}
                                    <!-- END FORM-->


        									</div>



                                        </div>















 <script>
 tinymce.init({selector:'textarea'});

 </script>
<!-- END PAGE LEVEL PLUGINS -->
@stop








     <br>
                                                     <br>


        										</div>
        									</div>






						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->

				</div>
			</div>
			<!-- END PAGE CONTENT-->
	</div>


@stop

@section('footerjs')

