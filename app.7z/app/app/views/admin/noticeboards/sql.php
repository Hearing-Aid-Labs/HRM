<?php
class sql extends dbconn {
	public function __construct()
	{
		$this->initDBO();
	}

	public function getAllCountry($term){
		$term = '%'.$term.'%';
		$db = $this->dblocal;
		try
		{
			$stmt = $db->prepare("SELECT a.* FROM deaignation a WHERE a.deaignation LIKE :term OR  a.deaignation LIKE :term ");

			$stmt->bindParam("term",$term);
			$stmt->execute();
			$stat[0] = true;
			$stat[1] = $stmt->fetchAll(PDO::FETCH_ASSOC);
			return $stat;
		}
		catch(PDOException $ex)
		{
			$stat[0] = false;
			$stat[1] = $ex->getMessage();
			return $stat;
		}
	}

}