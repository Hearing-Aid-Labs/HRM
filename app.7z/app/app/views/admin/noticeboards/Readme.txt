Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/dynamically-load-data-in-select2-with-ajax-pdo-and-php/

#####

Instructions -

1. Import the attached users.sql in your database.
2. Update config.php.