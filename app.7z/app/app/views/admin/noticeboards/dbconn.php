<?php
//$dbuserx='root';
//$dbpassx='123456';
//$host_name = "localhost";
//$database = "halhrm13_hrm"; // Change your database name
//$dbuserx = "halhrm13_hrm";          // Your database user id
//$dbpassx = "hearing@2020";          // Your password


class dbconn {
	public $dblocal;
	public function __construct()
	{

	}
	public function initDBO()
	{
		global $dbuserx,$dbpassx;
		try {
			$this->dblocal = new PDO("mysql:host=localhost;dbname=halhrm13_hrm;charset=latin1",$dbuserx,$dbpassx,array(PDO::ATTR_PERSISTENT => true));
			$this->dblocal->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e)
		{
			die("Tidak dapat konek ke database");
		}

	}

}
?>
