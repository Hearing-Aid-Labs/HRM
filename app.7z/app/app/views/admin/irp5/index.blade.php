@extends('admin.adminlayouts.adminlayout')
@section('mainarea')
<style>
.dataTables_filter{
   float:right;    

}

</style>
@if(Session::has('success'))
    <div class="alert alert-success">
           {{   Session::get('success') }}
    </div>
    
@endif    

<a class="btn green" onclick="addNew()"  data-target="#addModal" data-toggle="modal" href="#static">
                                        Add New Irp5
                         <i class="fa fa-plus"></i> </a>  
                         <br><br>
 <table id="slips" class="table table-striped table-bordered table-hover">
        <thead>
                <tr>
                    <th>
                         Date Created
                    </th>
                    <th>Note</th>
                    <th>Employee</th>
                    <th></th>
                    <th></th>
                </tr>
        </thead>
        <tbody>
        
        </tbody>
 </table>       

<div id="addModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <form method="post" action="{{URL::to('/')}}/admin/irp5/add" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="{{ Session::token() }}">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">ADD NEW IRP5 </h4>
      </div>
      <div class="modal-body">
            <div class="form-group">
                <label>Employee</label>
                <select class="form-control" name="employee_id">
                  @foreach($employees as $employee)
                     <option value="{{ $employee->id }}">{{  $employee->fullName }}</option>
                  @endforeach
                
                </select>
            </div>
            <div class="form-group">
                <label>Select file</label>
                <input required="required" type="file" name="slip" class="form-control">
            </div>
             <div class="form-group">
                <label>Note</label>
                <textarea name="note" class="form-control"></textarea>
            </div>
      </div>
      <div class="modal-footer">
      <button type="submit" class="btn btn-success pull-right">Submit</button>
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>

<div id="editModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <form method="post" action="{{URL::to('/')}}/admin/irp5/update" method="post" enctype="multipart/form-data">
    <input type="hidden" name="_token" value="{{ Session::token() }}">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Edit</h4>
      </div>
      <div class="modal-body">
             <input type="hidden" id="slip_id" name="slip_id" value="">
            
             <div class="form-group">
                <label>Note</label>
                <textarea name="note" id="slip_note" class="form-control"></textarea>
            </div>
      </div>
      <div class="modal-footer">
      <button type="submit" class="btn btn-success pull-right">Submit</button>
        <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
      </div>
    </div>
  </form>
  </div>
</div>

@endsection
@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    {{ HTML::script("assets/admin/pages/scripts/table-managed.js")}}
    {{HTML::script("assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js")}}
    {{HTML::script("assets/admin/pages/scripts/components-pickers.js")}}
    
    <script>
        jQuery(function($){
          $('#slips').DataTable( {
                    "bProcessing": true,
                    "bServerSide": true,
                    "sAjaxSource": "/admin/irp5/get_payment_slips",
                    "aoColumns": [null,null,null,{"mRender":function(data){
                        return '<a class="btn btn-success" Download href="{{URL::to("/") }}/employee_documents/slips/'+data+'">Download</a>&nbsp;'
                       // '<a class="btn btn-success" href="javascript:;" onClick="view_slip(\''+data+'\')">View Slip</a>';
                      
                    }},{"mRender": function(data){
                           return '<a class="btn btn-danger"  href="javascript:;" onClick="delete_slip('+data+')">Delete</a>'+
                               '<a class="btn btn-success" onClick="edit_slip('+data+')">Edit</a>';    
                        } }]
                    
          });

    });
   function view_slip(id)
   {
    
       url='{{URL::to("/") }}/employee_documents/slips/'+id;
       window.open(url, "myWindow", 'width=800,height=600');
   }
   function edit_slip(id)
   {
       $.get('{{ URL::to("/")  }}/admin/irp5/get_slip/'+id,function(data){
           data=JSON.parse(data);
           $("#slip_note").val(data.note);
           $("#slip_id").val(data.id);
             $("#editModal").modal('show');
       });
       
     
       
   }
    
</script>
<script>
function delete_slip(id){
        if(confirm('Do yo realy want to delete?'))
        {
            window.location="{{  URL::to('/') }}/admin/irp5/delete/"+id;
        }
        
    }


</script>
@stop