@extends('admin.adminlayouts.adminlayout')

@section('head')
	
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style('assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->

@stop


@section('mainarea')

			
			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			{{$pageTitle}}
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="{{route('admin.dashboard.index')}}">Home</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="#">Claims</a>
						<i class="fa "></i>
					</li>
				</ul>
			</div>
			<!-- END PAGE HEADER-->

			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->

					<!--a href="{{ route('admin.commision.create')}}" class="btn green">
                                    Add New Commision <i class="fa fa-plus"></i>
                      </a-->
                    <hr>
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-database"></i>Commision List
							</div>
						</div>

						<div class="portlet-body">
							<div class="row float-left"  >
								<div class="col-md-2">
									<a  class="btn purple text-right"  href="javascript:void(0)" onclick="process_selected_claims('Accepted')" > Accept Selected</a>
								</div>
								<div class="col-sm-2">

		                          <div class="form-group">

		                          <label>Month</label>
									<select name="claim_month" id="claim_month" onchange="filterTable()" class="form-control">
									@foreach ( $month_range as $month )
										<option {{$for_month==$month?'selected':''}} value="{{$month}}">{{$month}}</option>
									@endforeach
									</select>

		                          </div>
		                     	</div>

								<div class="col-sm-2">

		                          <div class="form-group">

		                          <label>Year</label>
									<select name="claim_year" id="claim_year" onchange="filterTable()" class="form-control">
										@for( $yr = $start_year ; $yr<=$commission_till_year; $yr++ )
										<option {{$for_year==$yr?'selected':''}} value="{{$yr}}">{{$yr}}</option>
										@endfor
									</select>

		                         </div>

								</div>
							</div>


						     <table id="commision_claims" class="table table-striped table-bordered table-hover clearfix float-left">
						            <thead>
					                    <tr>
					                        <th style="min-width:30px; width: 30px; text-align: center;">
			                                    <input class="checkbox checkft" type="checkbox" name="check" id="select-all"/>
			                                </th>
	                        				<th>
					                             Employee Name
					                        </th>
					                        <th>
					                             Date Created
					                        </th>
					                        <th>For Month</th>
					                        <th>Shortfall</th>
					                        <th>Total BTO</th>
					                        <th data-orderable="false">Target</th>
					                        <th>Over Target</th>
					                        <th>Commision</th>
					                        <th>Other</th>
					                        <th>Total Commision</th>
					                        <th>Status</th>
					                        <th data-orderable="false">Action</th>
					                    </tr>
						            </thead>
						            <tbody>
						            
						            </tbody>
						     </table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
					
				</div>
			</div>
			<!-- END PAGE CONTENT-->

			<div id="singe_cliam" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Claim Approval</h4>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

@stop



@section('footerjs')
<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
    	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
    	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
<!-- END PAGE LEVEL PLUGINS -->
	<script>
		$(document).ready(function(){
			generateClaimsTable();
		});

		function filterTable(){
	        $('#commision_claims').dataTable().fnDestroy();
		    generateClaimsTable();
		}

		function generateClaimsTable(){

	    	table_1 = $('#commision_claims').DataTable( {
	                    "bProcessing": true,

	                    
	                    "bServerSide": true,
	                    "sAjaxSource": "{{route('admin.get_commision_claims')}}",
	                    "aoColumns": [{
		                    bSortable: false,
		                    mRender: function(id) {
		            			    return '<input class="claim-check" type="checkbox"  value='+id+' name="check['+id+']" id="check'+id+'">';
					            },
					        aTargets: [ -1 ]
		                },
						[
					    { "data":"fullname", "name":"fullname" }
					  ],
					  [
					    { "data":"created_at", "name":"emc.created_at" }
					  ],  [
					    { "data":"for_month", "name":"for_month" }
					  ],[
					    { "data":"shortfall", "name":"shortfall" }
					  ],[
					    { "data":"bto_amount", "name":"bto_amount" }
					  ],[
					    { "data":"target_amount", "name":"target_amount" }
					  ],[
					    { "data":"final_amount_commision_applicable", "name":"final_amount_commision_applicable" }
					  ],[
					    { "data":"commision_applicable", "name":"commision_applicable" }
					  ],[
					    { "data":"claim_amount", "name":"select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )as claim_amount", bsearchable: false, "atargets": [-1] }
					  ],[
					    { "data":"FinalCommission", "name":"(FORMAT((select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )+commision_applicable,2))", bsearchable: false, "atargets": [-1] }
					  ],[
					    { "data":"approval_status", "name":"approval_status", bsearchable: false, "atargets": [-1] }
					  ],{
					     bSortable: false,
					     aTargets: [ -1 ]
					  }],
					  'fnCreatedRow': function (nRow, aData, iDataIndex) {
				        $(nRow).attr('id', 'my' + aData[0]); // or whatever you choose to set as the id
					  },
  					  'fnServerData': function (sSource, aoData, fnCallback) {


		                aoData.push({

							"name":"claim_month", 

							 "value":$("#claim_month").val()

						 });

						 aoData.push({

							"name":"claim_year", 

							 "value":$("#claim_year").val()

						 });
						 $.ajax({'dataType': 'json', 'type': 'GET', 'url': sSource, 'data': aoData, 'success': fnCallback});
						}

	         		});


			// Handle click on "Select all" control
			$('#select-all').on('click', function(){
			   // Get all rows with search applied
			   var rows = table_1.rows({ 'search': 'applied' }).nodes();
			   // Check/uncheck checkboxes for all rows in the table
			   $('input[type="checkbox"]', rows).prop('checked', this.checked);
			});
		}
		function process_selected_claims( action ){
			total_selected = '';
			console.log( "action " + action );
			$('.claim-check').each(function(){
				if( $(this).is(':checked') ){
					console.log($(this).attr('id')+"Checked");
					if( total_selected == '' ){
						total_selected = $(this).val();
					}else{
						total_selected = total_selected+','+$(this).val();
					}
					console.log("selected "+total_selected);
				}else{
					console.log($(this).attr('id')+"Not Checked");
				}
			
			});
			if( total_selected == '' ){
				alert("Please select at least one Claim!");
				return;
			}

			if( confirm("Are you sure to change status to be "+action) ){
				//$('#approval_status').val(action);
				data = {employee_claim_id:total_selected,'approval_status':action}
				$.ajax({
					url:'/admin/submit_claim_status',
					method:'post',
					data:data,
					success: function( response ){
						console.log(response);
						alert(response);
//							$('#singe_cliam').modal('show');
						//$('#singe_cliam .modal-body').html("Status Saved Successfully!");
					}
				});
			}
			
		}

		function edit_view( employee_claim_id ){
			$.ajax({
				url:'/admin/get_single_claim/'+employee_claim_id,
				method:'get',
				success: function( response ){
					console.log(response);
					$('#singe_cliam').modal('show');
					$('#singe_cliam .modal-body').html(response);
				}
			});
		}

</script>
@stop
	