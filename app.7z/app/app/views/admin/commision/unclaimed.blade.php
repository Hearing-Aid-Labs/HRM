@extends('admin.adminlayouts.adminlayout')

@section('head')
	
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style('assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css')}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->

@stop


@section('mainarea')

			
			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			{{$pageTitle}}
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="{{route('admin.dashboard.index')}}">Home</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="#">Unclaimed</a>
						<i class="fa "></i>
					</li>
				</ul>
			</div>
			<!-- END PAGE HEADER-->

			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->

					<!--a href="{{ route('admin.commision.create')}}" class="btn green">
                                    Add New Commision <i class="fa fa-plus"></i>
                      </a-->
                    <hr>
					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-database"></i>Unclaimed Commision List
							</div>

						</div>

						<div class="portlet-body">
							<div class="row float-left"  >
								<div class="col-sm-2">
		                          <div class="form-group">
		                          <label>Month</label>
									<select name="claim_month" id="claim_month" onchange="filterTable()" class="form-control">
									@foreach ( $month_range as $month )
										<option {{$for_month==$month?'selected':''}} value="{{$month}}">{{$month}}</option>
									@endforeach
									</select>
		                          </div>
		                     	</div>
								<div class="col-sm-2">
		                          <div class="form-group">
		                          <label>Year</label>
									<select name="claim_year" id="claim_year" onchange="filterTable()" class="form-control">
										@for( $yr = $start_year ; $yr<=$commission_till_year; $yr++ )
										<option {{$for_year==$yr?'selected':''}} value="{{$yr}}">{{$yr}}</option>
										@endfor
									</select>
		                         </div>
								</div>
							</div>
						    <table id="commision_claims" class="table table-striped table-bordered table-hover">
						            <thead>
						                    <tr>
						                        <th>
						                             Employee ID
						                        </th>
						                        <th>
						                             Employee Name
						                        </th>
						                        <th>Designation</th>
						                        <th>Department</th>
						                        <th>For Month</th>
						                        <th data-orderable="false">Action</th>
						                    </tr>
						            </thead>
						            <tbody>
						            
						            </tbody>
						     </table>
						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
					
				</div>
			</div>
			<!-- END PAGE CONTENT-->

			<div id="singe_cliam" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Claim Approval</h4>
      </div>
      <div class="modal-body">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>

@stop



@section('footerjs')
<!-- BEGIN PAGE LEVEL PLUGINS -->
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
    	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
    	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
<!-- END PAGE LEVEL PLUGINS -->
	<script>
		$(document).ready(function(){
				generateUnclaimedTable();
			});
			function filterTable(){
		        $('#commision_claims').dataTable().fnDestroy();
			    generateUnclaimedTable();
			}

			function generateUnclaimedTable(){

		    	var table = $('#commision_claims').DataTable( {
		                    "bProcessing": true,
		                    "bServerSide": true,
		                    "sAjaxSource": "{{route('admin.get_unclaimed_employees')}}",
		                    "aoColumns": [ null,null,null,null,null,null],
		                    'fnServerData': function (sSource, aoData, fnCallback) {
		                	aoData.push({
								"name":"claim_month", 
								 "value":$("#claim_month").val()
							 });
							 aoData.push({
								"name":"claim_year", 
								 "value":$("#claim_year").val()
							 });
							 $.ajax({'dataType': 'json', 'type': 'GET', 'url': sSource, 'data': aoData, 'success': fnCallback});
						}
	/*    [[{ "data":"fullname", "name":"fullname" }
	  ],
	  [
	    { "data":"created_at", "name":"emc.created_at" }
	  ],  [
	    { "data":"for_month", "name":"for_month" }
	  ],[
	    { "data":"shortfall", "name":"shortfall" }
	  ],[
	    { "data":"bto_amount", "name":"bto_amount" }
	  ],[
	    { "data":"target_amount", "name":"target_amount" }
	  ],[
	    { "data":"final_amount_commision_applicable", "name":"final_amount_commision_applicable" }
	  ],[
	    { "data":"commision_applicable", "name":"commision_applicable" }
	  ],[
	    { "data":"claim_amount", "name":"select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )as claim_amount", bsearchable: false, "atargets": [-1] }
	  ],[
	    { "data":"FinalCommission", "name":"(FORMAT((select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )+commision_applicable,2))", bsearchable: false, "atargets": [-1] }
	  ],[
	    { "data":"approval_status", "name":"approval_status", bsearchable: false, "atargets": [-1] }
	  ],{
	     bSortable: false,
	     aTargets: [ -1 ]
	  }]*/

		         });
		    }

		function edit_view( employee_claim_id ){
			$.ajax({
				url:'/admin/get_single_claim/'+employee_claim_id,
				method:'get',
				success: function( response ){
					console.log(response);
					$('#singe_cliam').modal('show');
					$('#singe_cliam .modal-body').html(response);
				}
			});
		}
		function email_reminder( employee_id ){
			$.ajax({
				url:'/admin/unclaimed_email_reminder/'+employee_id,
				method:'post',
				success: function( response ){
					console.log(response);
					alert("Email sent to "+response);
					//$('#singe_cliam .modal-body').html(response);
				}
			});
		}

</script>
@stop
	