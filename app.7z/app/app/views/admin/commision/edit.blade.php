@extends('admin.adminlayouts.adminlayout')

@section('head')
    <!-- BEGIN PAGE LEVEL STYLES -->
    {{ HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css") }}
    {{ HTML::style("assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.css") }}
    <!-- BEGIN THEME STYLES -->
@stop


@section('mainarea')

			
			<!-- BEGIN PAGE HEADER-->
			<h3 class="page-title">
			Commisions Edit page
			</h3>
			<div class="page-bar">
				<ul class="page-breadcrumb">
					<li>
						<i class="fa fa-home"></i>
						<a href="{{route('admin.dashboard.index')}}">Home</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="{{ route('admin.commision.index') }}">Commision</a>
						<i class="fa fa-angle-right"></i>
					</li>
					<li>
						<a href="">Edit Item</a>
					</li>
				</ul>
			
			</div>
			<!-- END PAGE HEADER-->
			<!-- BEGIN PAGE CONTENT-->
			<div class="row">
				<div class="col-md-12">
					<!-- BEGIN EXAMPLE TABLE PORTLET-->

                {{--INLCUDE ERROR MESSAGE BOX--}}
                @include('admin.common.error')
                {{--END ERROR MESSAGE BOX--}}


					<div class="portlet box blue">
						<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-edit"></i>Edit Commision Tier
							</div>
							<div class="tools">
							</div>
						</div>

						<div class="portlet-body form">

						<!-- BEGIN FORM-->
						{{Form::open(array('route'=>["admin.commision.update",$commision->id],'class'=>'form-horizontal form-bordered','method'=>'PATCH','files'=>true))}}


                                    <div class="form-body">

                                        <div class="form-group">
                                        <label class="col-md-2 control-label">Tier: <span class="required"> * </span></label>
                                            <div class="col-md-6">
                                                <input type="text" readonly title="You can not edit Tier number" class="form-control" name="tier" placeholder="Tier 1" value="{{ $commision->tier }}">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                          <label class="col-md-2 control-label">Commision Type:  </label>
                                          <div class="col-md-6">
                                            <input type="text" class="form-control" name="comm_type" placeholder="10" value="{{ $commision->comm_type }}" >
                                          </div>
                                        </div>
                                        <div class="form-group">
                                             <label class="col-md-2 control-label">Tier Amount: </label>
                                            <div class="col-md-6">
                                                <input type="text" class="form-control" name="tier_amount" placeholder="Tier Amount" value="{{ $commision->tier_amount }}" >
                                            </div>
                                        </div>


                                     <div class="form-group">
                                        <label class="col-md-2 control-label">Commision Amount:<span class="required">  * </span></label>
                                                <div class="col-md-6">
                                                    <input type="text" class="form-control" name="comm_amount" placeholder="percentage / fixed" value="{{ $commision->comm_amount }}">
                                                </div>
                                     </div>




                        								<div class="form-actions">
                        									<div class="row">
                        										<div class="col-md-offset-3 col-md-9">
                        											<button type="submit" data-loading-text="Updating..." class="demo-loading-btn btn green"><i class="fa fa-edit"></i> Update</button>

                        										</div>
                        									</div>
                        								</div>
                                      </div>
                        						{{ Form::close() }}
                        							<!-- END FORM-->

						</div>
					</div>
					<!-- END EXAMPLE TABLE PORTLET-->
					
				</div>
			</div>
			<!-- END PAGE CONTENT-->



@stop

@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
{{ HTML::script("assets/global/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js") }}
{{ HTML::script("assets/admin/pages/scripts/components-pickers.js") }}
{{ HTML::script("assets/global/plugins/bootstrap-fileinput/bootstrap-fileinput.js") }}
<!-- END PAGE LEVEL PLUGINS -->
<script>
jQuery(document).ready(function() {

           ComponentsPickers.init();


        });
</script>
@stop