

			<div class="row">
				<div class="col-md-12">
						     <table id="commision_claims" class="table table-striped table-bordered table-hover">
						            <thead>
						                    <tr>
						                        <th>Submitted on</th>
						                        <td>{{$claim_array['created_at']}}</td>
						                    </tr>
											<tr><th>For Month</th><td>{{$claim_array['for_month'] }}</td> </tr>
											<tr><th>Total BTO</th><td>{{$claim_array['bto_amount'] }}</td> </tr>
											<tr>
						                        <th>Target</th><td>{{$claim_array['target_amount'] }}</td>
						                    </tr>
											<tr>
						                        <th>Shortfall</th><td>{{$claim_array['shortfall'] }}</td>
						                    </tr>
											<tr>
						                        <th>Over Target</th><td>{{$claim_array['final_amount_commision_applicable'] }}</td>
						                    </tr>
											<tr>
						                        <th>Commision Applicable</th><td>{{$claim_array['commision_applicable'] }}
						                        @if($claim_array['commision_percentage'] && $claim_array['commision_percentage'] >= 1)
						                        	({{$claim_array['commision_percentage']}}%)
						                        @endif
						                        @if($claim_array['commision_amount_fixed'] && $claim_array['commision_amount_fixed'] >= 1)
						                        	( Fixed {{$claim_array['commision_amount_fixed']}})
						                        @endif

						                        </td> </tr>
						                    </tr>
											<tr>
						                        <th>Other Claims</th><td>
						                        	@forelse( $claim_array['other_claims'] as $other_claim )
						                        		<p><span>{{$other_claim['claim_reason']}} {{$other_claim['claim_details']}}</span> <strong>Amount: {{$other_claim['claim_amount']}}</strong></p>
						                        	@empty
						                        		No other claims
						                        	@endforelse
						                        </td>
											</tr>
						    				<tr>
						                        <td colspan="2">
						                        	<hr />
						                        	@if( $claim_array['approval_status'] == 'Submitted' )
						                    		<input type="text" name="comments" id="comments" value="" placeholder="Good Job - Accepted / Need more clarification - Rejected" class="col-md-12">
						                    		<br />
						                    		<input type="hidden" name="approval_status" id="approval_status" value=''>    
						                    		<input type="hidden" id="employee_claim_id" name="employee_claim_id" value="{{ $claim_array['id'] }}">    	
					                        		
					                        		<input type="button" name="accept" class="btn green" onclick="submit_status('Accepted')" id="Approve_Status" value="Approve"/>

					                        		<input type="button" class="btn purple" onclick="submit_status('Rejected')" name="reject" id="reject" value="Reject"/>
					                        		@else

					                        		<p>Comments: <strong>{{$claim_array['comments']}}</strong></p>
					                        		<p><h2>{{$claim_array['approval_status']}}</h2></p>
					                        		@endif
						                        	
						                        </td> </tr>
						                    </tr>
							        </thead>
						            <tbody>
						            
						            </tbody>
						     </table>

					<!-- END EXAMPLE TABLE PORTLET-->
					
				</div>
			</div>
			<!-- END PAGE CONTENT-->
		<script type="text/javascript">
			function submit_status(status){
				if( confirm("Are you sure to change status to be "+status) ){
					$('#approval_status').val(status);
					data = {comments:$('#comments').val(),employee_claim_id:$('#employee_claim_id').val(),'approval_status':$('#approval_status').val()}
					$.ajax({
						url:'/admin/submit_single_claim_status',
						method:'post',
						data:data,
						success: function( response ){
							console.log(response);
//							$('#singe_cliam').modal('show');
							$('#singe_cliam .modal-body').html("Status Saved Successfully!");
						}
					});
				}
			}
		</script>



	