<table>
@foreach(employees as $employee)
<tr>
 <td>{{ $employee->fullName }}</td>

</tr>

@endforeach

</table>