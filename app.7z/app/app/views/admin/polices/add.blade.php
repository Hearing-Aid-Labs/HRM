@extends('admin.adminlayouts.adminlayout')
@section('mainarea')
<script>
function edit_page(id)
{
    $("#pages_div").css("opacity","0.5");
    $.get("{{URL::to('/')}}/admin/edit_policy_page/"+id,function(data){
        $("#pages_div").css("opacity","1.0");
        resp=JSON.parse(data);
        $("#edit_modal").modal('show');
        tinyMCE.activeEditor.setContent( resp.page);
        $("#page_title").val(resp.title);
        $("#parent_page").val(resp.parent_page);
		$("#order_no").val(resp.order_no);
        $("#page_id").val(id);
        $("#edit_btn_submit").prop("disabled",false);
      
        
    });
    
    
}
function addNew()
{
     tinyMCE.activeEditor.setContent("");
    
    
}
function view_accpted_employees(id)
{
      $("#pages_div").css("opacity","0.5");
   $.get('{{URL::to("/")}}/admin/accpted_employees/'+id,function(data){
         $("#pages_div").css("opacity","1.0");
       $("#employee_modal_view").modal('show');
       $("#employees_div").html(data);
   });    
    
    
}
function view_unaccpted_employees(id)
{
    $("#pages_div").css("opacity","0.5");
    $.get('{{URL::to("/")}}/admin/unaccpted_employees/'+id,function(data){
          $("#pages_div").css("opacity","1.0");
         $("#employee_modal_view").modal('show');
         $("#employees_div").html(data);
       
   });    
    
    
}
function delete_page(id,element)
{
    
   if( confirm("Do You realy want to delete!"))
   {
    $("#pages_div").css("opacity","0.5");
       $.get('{{URL::to("/")}}/admin/delete_policy_page/'+id,function(data){
           $("#pages_div").css("opacity","1.0");
          $(element).closest('tr').remove();
          $("#msg_box").show();
          $("#msg_box").text("Successfully deleted!");
          setTimeout(function(){
              $("#msg_box").fadeOut();
          },1500);
           
           
       });
       
   }
    
    
}

</script>
@if (Session::has('message'))
   <div class="alert alert-success">{{ Session::get('message') }}</div>
@endif
 <div id="msg_box" style="display:none" class="alert alert-success"></div>
   <h3 class="page-title">
			Policy Pages
			</h3>
    <a class="btn green" onclick="addNew()" data-toggle="modal" href="#static">
                                        Add New Page
                         <i class="fa fa-plus"></i> </a>        
    <div class="portlet box blue" style="margin-top:10px">
         <div class="portlet-title">
           <div class="caption"> Pages</div>
         
         </div>
         <div class="portlet-body" id="pages_div">
           
             <table class="table table-striped table-bordered table-hover">
							<thead>
							<tr>
								<th>
									 Title
								</th>
								<th>Parent Page</th>
								<th>Order No</th>
								<th>Actions</th>
							</tr>
							</thead>
                           <tbody>
                         @if(count($pages)>0)  
                           @foreach($pages as $page)
                             <tr>
                             <td>{{$page->title}}</td>
                             <td>{{$page->parent_title}}</td>
                             <td>{{ $page->order_no }}</td>                             
                             <td class=" ">
                                	<a class="btn purple" data-toggle="modal" href="#edit_static" onclick="edit_page({{$page->id}})"><i class="fa fa-edit"></i> View/Edit</a>

              						<a class="btn red" href="javascript:;" onclick="delete_page({{ $page->id }},this)" ><i class="fa fa-trash"></i> Delete</a>
                                    <a class="btn purple" onclick="view_accpted_employees(<?= $page->id?>)">View accpeted employees</a>
                                    <a class="btn purple" onclick="view_unaccpted_employees(<?= $page->id?>)">View Not accpeted employees</a>
                            </td>
                            
                        
                             
                             </tr>
                           
                           @endforeach
                        @else
                            <tr>
                             <td colspan="2">No result found</td>
                            </tr>
                        @endif    
                           </tbody>
              </table>    
                            
         </div>
         
    </div>   


		<div id="static" class="modal fade"  tabindex="-1" data-backdrop="static" data-keyboard="false">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h4 class="modal-title"><strong><i class="fa fa-plus"></i> New Page</strong></h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="portlet-body form">

                                                                    						<!-- BEGIN FORM-->
                                        {{Form::open(array('route'=>"admin.create_policy",'class'=>'form-horizontal ','method'=>'POST'))}}


                                            <div class="form-body">

                                                    <p class="text-success">
                                                            Title
                                                           </p>
                                                  <div class="form-group">
                                                      <div class="col-md-12">
                                                         <input class="form-control form-control-inline" required="required"  name="title" type="text" value="" />

                                                      </div>

                                                 </div>
                                                  <div class="form-group">
                                                   <div class="col-md-12">
                                                     <label>Parent Page</label>
                                                     <select class="form-control" name="parent_page">
                                                     <option value="">No Parent</option>
                                                     @foreach($parent_pages as $page)
                                                      <option value="{{ $page->id}}">{{ $page->title}}</option>
                                                     @endforeach
                                                     </select>
                                                   
                                                   </div>
                                                 
                                                  </div>
                                                <hr>
												<div class="form-group">
                                                   <div class="col-md-12">
                                                     <label>Order No</label>
                                                     <input type="text" class="form-control"  name="order_no">
                                                   
                                                   </div>
                                                 
                                                  </div>
                                                 <p class="text-success">
                                                          Page
                                                </p>
                                                <div class="form-group">
                                                     <div class="col-md-12">
                                                       <textarea name="page" rows="50" class="form-control"></textarea>
                                                     </div>
                                                   
                                                </div>
                                                <div class="form-group">
                                                 <div class="col-md-12">
                                                     <label>
                                                     <input type="checkbox"  name="send_email" value="1">
                                                     Send email to employees
                                                     </label>
                                                 </div>    
                                                
                                                </div>
                                                
                                                 

                                         </div>

                                           <div class="modal-footer">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" data-loading-text="Submitting..." class="btn green"><i class="fa fa-check"></i> Submit</button>

                                                </div>
                                            </div>    
                                          
                                            {{ Form::close() }}
                                         <!-- END FORM-->
                                     </div>
                                            </div>
                                            <!-- END EXAMPLE TABLE PORTLET-->
                    </div>

                </div>
            </div>  
     <!-- end add modal--->
           
            <div id="edit_modal" class="modal fade"  tabindex="-1" data-backdrop="static" data-keyboard="false">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                                                <h4 class="modal-title"><strong> Edit Page</strong></h4>
                                            </div>
                                            <div class="modal-body">
                                                <div class="portlet-body form">

                                                                    						<!-- BEGIN FORM-->
                                        {{Form::open(array('url'=>"/admin/edit_policy_page",'class'=>'form-horizontal ','method'=>'POST'))}}


                                            <div class="form-body">

                                                    <p class="text-success">
                                                            Title
                                                           </p>
                                                  <div class="form-group">
                                                      <div class="col-md-12">
                                                         <input class="form-control form-control-inline" id="page_title" required="required" name="title" type="text" value="" />

                                                      </div>

                                                 </div>
                                                 <div class="form-group">
                                                   <div class="col-md-12">
                                                     <label>Parent Page</label>
                                                     <select class="form-control" id="parent_page" name="parent_page">
                                                     <option value="">No Parent</option>
                                                      @foreach($parent_pages as $page)
                                                      <option value="{{ $page->id}}">{{ $page->title}}</option>
                                                     @endforeach
                                                     
                                                     </select>
                                                   
                                                   </div>
                                                 
                                                 </div>
												 <div class="form-group">
                                                   <div class="col-md-12">
                                                     <label>Order No</label>
                                                     <input type="text" class="form-control" id="order_no" name="order_no">
                                                   
                                                   </div>
                                                 
                                                  </div>
                                                <hr>
                                                 <p class="text-success">
                                                          Page
                                                </p>
                                                <div class="form-group">
                                                     <div class="col-md-12">
                                                       <textarea name="page" rows="50" class="form-control"></textarea>
                                                     </div>
                                                   
                                                </div>
                                                
                                       <input type="hidden" name="page_id" id="page_id" value="">

                                         </div>

                                           <div class="modal-footer">
                                                <div class="col-md-offset-3 col-md-9">
                                                    <button type="submit" id="edit_btn_submit" data-loading-text="Submitting..." class="btn green"><i class="fa fa-check"></i> Submit</button>
                                                     
                                                </div>
                                            </div>    
                                          
                                            {{ Form::close() }}
                                         <!-- END FORM-->
                                     </div>
                                            </div>
                                            <!-- END EXAMPLE TABLE PORTLET-->
                    </div>

                </div>
            </div>  <!-- end edit modal------>
            
            
             <div class="modal fade" id="employee_modal_view"  tabindex="-1" data-backdrop="static" data-keyboard="false">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                              <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                              <h4 class="modal-title"><strong>Employees</strong></h4>
                            </div>
                            <div calss="modal-body">
                                <div id="employees_div">
                                
                                </div>
                            
                            </div>
                            <div class="modal-footer">
                             <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                            
                            </div>
                        </div>
                     </div> 
              </div>       
   
            
            
                   

@endsection
@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
{{HTML::script("assets/global/plugins/bootstrap-select/bootstrap-select.min.js")}}
{{HTML::script("assets/global/plugins/select2/select2.min.js")}}
{{HTML::script("assets/global/plugins/jquery-multi-select/js/jquery.multi-select.js")}}
{{HTML::script("assets/global/plugins/tinymce/tinymce.min.js")}}
 <script>
 tinymce.init({selector:'textarea', height : "200"});

 </script>
<!-- END PAGE LEVEL PLUGINS -->
@stop