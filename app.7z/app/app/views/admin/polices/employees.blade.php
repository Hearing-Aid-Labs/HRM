@if(count($employees)>0)
   <div style="max-height:400px;overflow-y:scroll">  
    <table class="table table-strpped">
    @foreach($employees as $employee)
    <tr>
     <td>{{ $employee->fullName }}</td>

    </tr>

    @endforeach

    </table>
    </div>
@else
 <div class="col-md-12">   
  <h4>No employee yet</h4>  
 </div> 
 
    
@endif    