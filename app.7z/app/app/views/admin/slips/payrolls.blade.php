@extends('admin.adminlayouts.adminlayout')
@section('mainarea')

@if(Session::has('success'))
    <div class="alert alert-success">
           {{   Session::get('success') }}
    </div>
    
@endif
@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
  {{ HTML::style("assets/css/MonthPicker.min.css") }}
   {{ HTML::style("assets/css/test.css") }}
   {{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- END PAGE LEVEL STYLES -->

@stop

<div class="portlet box blue">
<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-briefcase"></i>Payrolls for <?=   $commission_month  ?>
							</div>
							<div class="tools">
							</div>
</div>
<div class="portlet-body">
<div class="pull-right" style="margin-bottom:20px">
      <a class="btn btn-success" class="" onClick="export_to_csv()" href="javascript:;">Export To Csv</a>
   </div>
<div class="input-group" style="margin:30px">
   <label>Select month &nbsp;&nbsp;&nbsp;&nbsp;</label>
   <input type="text" readonly="readonly" id="monthpicker" class="" name="month">

</div>


      <table id="commisions" class="table table-striped table-bordered table-hover">
        <thead>
            <th>Employee id</th>
            <th>Employee Name</th>
            <th>Surname</th>
            <th>Occupation</th>
            <th>Branch</th>
            <th>Salary</th>
            <th>Commission</th>
        
        </thead>
         <tbody>
            @foreach($employees as $employee)
               <tr>
                   <td>{{   $employee->employeeID  }}</td>
                     <td>{{  $employee->fullName  }}</td>
                     <th>{{  $employee->fatherName }}</th>
                     <th>{{  $employee->designation_name }}</th>
                     <th>{{  $employee->deptName }}</th>
                     <td>{{   $employee->salary }}</td>
                     <td>{{   $employee->commission }}</td>
               </tr>
            @endforeach
        </tbody>
     </table>

</div>



</div>

<script>
	jQuery(document).ready(function() {
       $('#commisions').DataTable({
           });
       $('#monthpicker').MonthPicker( {Button: '<button>...</button>',
           OnAfterChooseMonth: function(selectedDate) {
                 window.location="{{URL::to('/admin/payrolls')}}"+"/"+$(this).val();
              }
       
       });
	});
    function export_to_csv()
    {
        window.location=window.location+"?export_to_payroll_csv=1";
        
    }


	</script>

@section('footerjs')
   {{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
{{HTML::script("assets/js/MonthPicker.min.js")}}
{{ HTML::style("assets/css/MonthPicker.min.css") }}

@stop

@stop