@extends('admin.adminlayouts.adminlayout')
@section('mainarea')

@if(Session::has('success'))
    <div class="alert alert-success">
           {{   Session::get('success') }}
    </div>
    
@endif
@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
  {{ HTML::style("assets/css/MonthPicker.min.css") }}
   {{ HTML::style("assets/css/test.css") }}
   {{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" />
<!-- END PAGE LEVEL STYLES -->

@stop

<div class="portlet box blue">
<div class="portlet-title">
							<div class="caption">
								<i class="fa fa-briefcase"></i>Employee Commissions for <?=   $commission_month  ?>
							</div>
							<div class="tools">
							</div>
</div>

<div class="portlet-body">
<div class="pull-right" style="margin-bottom:20px">
      <a class="btn btn-success" class="" onClick="export_to_csv()" href="javascript:;">Export To Csv</a>
   </div>
<div class="input-group" style="margin:30px">
   <label>Select month &nbsp;&nbsp;&nbsp;&nbsp;</label>
   <input type="text" readonly="readonly" id="monthpicker" class="" name="month">

</div>
   
<table id="commisions" class="table table-striped table-bordered table-hover">
        <thead>
                <tr>
                    <th>Employee Name</th>
                    <th>Employee Id</th>
                    <th>Commission</th>
                     <th>BTO</th>
                </tr>
        </thead>
        <tbody>
            @foreach($commissions as $commission)
               <tr>
                   <td>{{  $commission->first_name." ".$commission->last_name  }}</td>
                     <td>{{  $commission->employeeID  }}</td>
                     <td>{{  $commission->commission  }}</td>
                     <td>{{  $commission->bto  }}</td>
               </tr>
            @endforeach
        </tbody>
 </table>       

</div>
</div>
@stop
@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
    {{HTML::script("assets/js/jquery.maskedinput.min.js")}}
    {{HTML::script("assets/js/MonthPicker.min.js")}}
	{{ HTML::script("assets/global/plugins/select2/select2.min.js")}}
	<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
<!-- END PAGE LEVEL PLUGINS -->
<script src="//cdn.datatables.net/buttons/1.2.1/js/buttons.html5.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="//cdn.datatables.net/buttons/1.0.3/js/dataTables.buttons.min.js"></script>
	<script>
	jQuery(document).ready(function() {
       $('#commisions').DataTable({
           });
       $('#monthpicker').MonthPicker( {Button: '<button>...</button>',
           OnAfterChooseMonth: function(selectedDate) {
                 window.location="{{URL::to('/admin/commissions')}}"+"/"+$(this).val();
              }
       
       });
	});
    function export_to_csv()
    {
        window.location=window.location+"?export_to_csv=1";
        
    }


	</script>
    
@stop   