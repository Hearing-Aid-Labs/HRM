@extends('front.layouts.frontlayout')

@section('head')

{{HTML::style("assets/global/css/components.css")}}
{{HTML::style("assets/global/css/plugins.css")}}
{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
@stop

@section('mainarea')
<div class="col-md-9">
                <!--Profile Body-->
  <div class="profile-body">

    <input type="button" name="claim" value="Submit Claim" onclick="window.location.href='/add_claim'"/>
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i> My Commision Hisotry</h3>
            </div>
      <div class="panel-body">

     <table id="commision" class="table table-striped table-bordered table-hover">
            <thead>
                    <tr>
                        <th>
                            Claimed on
                        </th>
                        <th>Month</th>
                        <th>BTO</th>
                        <th>Target</th>
                        <th>Shortfall</th>
                        <th>Over target</th>
                        <th>Commision</th>
                        <th>Other</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
            </thead>
            <tbody>
            
            </tbody>
     </table>
     </div>
     </div>
    </div>
</div>    




@stop
@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->

	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    <script>
    
    
    
        jQuery(function($){
          $('#commision').DataTable( {
                    "bProcessing": true,
                    "bServerSide": true,
                    "pageLength": 20,
                    "sAjaxSource": "/ajaxcommision",
                    "aoColumns": [null,null,null,null,null,null,null,null,null,null]
          });

    });
    
    
    
    </script>
    
    
@stop    