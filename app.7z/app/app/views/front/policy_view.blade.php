@extends('front.layouts.frontlayout')
@section('mainarea')
<style>
input[type="checkbox"]{
  width: 30px; /*Desired width*/
  height: 30px; /*Desired height*/
}
</style>
 <div class="col-md-9">
 <h1>{{$page->title}}</h1>
 <div class="col-md-12" style="max-height:400px;overflow-y:scroll">
   {{$page->page}}
  </div>  
  {{ Form::open(['url'=>'policy/accpet'])}}  
  @if($is_accpeted==0)
  <div class="col-md-12">
 
   <div class="form-group">
   <div class="checkbox">
    <label><h2><input type="checkbox" required="required" name="accpet" value="1">&nbsp;&nbsp;&nbsp;I have read the page and i accept this page</h2></label>
    </div> 
    <input type="hidden" name="page_id" value="{{$page->id}}" >
    <input type="submit" class="btn btn-primary">
   </div>
  @else
      <div class="col-md-12">
       <h1>You have accpeted this page</h1>
      
      </div>
  @endif 
  
  </div>
  </form>
 </div>
 
@endsection