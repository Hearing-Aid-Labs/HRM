@extends('front.layouts.frontlayout')

@section('head')

{{HTML::style("assets/global/css/components.css")}}
{{HTML::style("assets/global/css/plugins.css")}}
{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
@stop

@section('mainarea')
<div class="col-md-9">
                <!--Profile Body-->
  <div class="profile-body">
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i> My Payment Slips</h3>
            </div>
      <div class="panel-body">
     <table id="slips" class="table table-striped table-bordered table-hover">
            <thead>
                    <tr>
                        <th>
                             Date Created
                        </th>
                        <th>Admin Note</th>
                        <th>Action</th>
                    </tr>
            </thead>
            <tbody>
            
            </tbody>
     </table>
     </div>
     </div>
    </div>
</div>    




@stop
@section('footerjs')

<!-- BEGIN PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->

	{{ HTML::script("assets/global/plugins/datatables/media/js/jquery.dataTables.min.js")}}
	{{ HTML::script("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.js")}}
    <script>
    
    
    
        jQuery(function($){
          $('#slips').DataTable( {
                    "bProcessing": true,
                    "bServerSide": true,
                    "sAjaxSource": "/get_payment_slips",
                    "aoColumns": [null,null,{"mRender":function(data){
                        return '<a href=" {{URL::to("/") }}/employee_documents/slips/'+data+'">Download</a>';
                    }}]
          });

    });
    
    
    
    </script>
    
    
@stop    