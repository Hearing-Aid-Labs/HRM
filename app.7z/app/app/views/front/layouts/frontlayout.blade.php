<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<head>
    <title>{{$setting->website}} - {{$pageTitle}} </title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

 

    <!-- CSS Global Compulsory -->
    <script src="https://albert-gonzalez.github.io/easytimer.js/dist/easytimer.min.js"></script>
        {{ HTML::style('front_assets/plugins/bootstrap/css/bootstrap.min.css') }}
        {{ HTML::style('front_assets/css/style.css')}}
        <!-- CSS Implementing Plugins -->

        {{ HTML::style('front_assets/plugins/font-awesome/css/font-awesome.min.css') }}
        {{ HTML::style('front_assets/plugins/sky-forms/version-2.0.1/css/custom-sky-forms.css') }}

        {{ HTML::style('front_assets/plugins/scrollbar/src/perfect-scrollbar.css') }}
        {{ HTML::style('front_assets/plugins/fullcalendar/fullcalendar.css') }}
        {{ HTML::style('front_assets/plugins/fullcalendar/fullcalendar.print.css',array('media' => 'print')) }}


        <!-- CSS Page Style -->
        {{ HTML::style('front_assets/css/pages/profile.css') }}



        <!-- CSS Theme -->
        {{ HTML::style('front_assets/css/theme-colors/default.css') }}

        <!-- CSS Customization -->
        {{ HTML::style('front_assets/css/custom.css') }}
        @yield('head')
		<script>
		<?php if(empty($today_attendance)){ ?>
		var current_check_status=0;
		<?php } else { ?>
		var current_check_status=1;
		<?php  }   ?>
		
		current_time_status=0;
		function start_work()
		{
			$.get('start_work/',function(){
				if(current_time_status==0)
				{
					start_time();
				}
				current_check_status=1;
				$("#stop_work_btn").show();
				$("#start_work_btn").hide();
				$("#working_status").text('Working');
				
			});
			
		}
		function stop_work()
		{
		
			$.get('stop_work/',function(){
				
				$("#stop_work_btn").hide();
				$("#start_work_btn").hide();
				$("#working_status").text('Finished working!');
				 pause_time();
			});
			
		}
//		var timer = new Timer();
		var timer = new easytimer.Timer();
		var total_timer_logged=0;;
	 <?php  	if  ($working_status==1){ ?>
	          timer.start({startValues: {seconds: <?= $employee_time_log ?>}});
		     
	<?php  }   ?>
       // 
		timer.addEventListener('secondsUpdated', function (e) {
            $('#basicUsage').html(timer.getTimeValues().toString());
         });
		 function start_time()
		 {
			  current_time_status=1; 
			  $.get('start_time',function(data){
				  if(data!=="")
				  {
					  alert(data);
					  return;
				  }
				 if(total_timer_logged==0)
			      {
				   timer.start({startValues: {seconds: <?= $employee_time_log ?>}});
				  }
				  else{
					  timer.start();
				   }
				   total_timer_logged++;
				
				   $("#start_time_btn").hide();
				   $("#stop_time_btn").show();
				   
				   if(current_check_status==0)
				   {
					   start_work();
				   }
				   
				  
			  });
		 }
		 function pause_time()
		 {
			   $.get('stop_time',function(data){

				  
			  });
			  timer.pause();
			    $("#stop_time_btn").hide();
				 $("#start_time_btn").show();
		 }
		</script>

</head>	

<body>
<div class="wrapper">
    <!--=== Header ===-->    
    <div class="header">
        <!-- Navbar -->
        <div class="navbar navbar-default mega-menu" role="navigation">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="fa fa-bars"></span>
                    </button>
                    <a class="navbar-brand" href="{{ URL::to('dashboard')}}">
                    {{HTML::image("assets/admin/layout/img/{$setting->logo}",'Logo',array('class'=>'logo-default','id'=>'logo-header','height'=>'22px','width'=>'86px'))}}
                  

                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse navbar-responsive-collapse">
                    <ul class="nav navbar-nav">

                        <!-- Home -->
                        <li class="{{$homeActive or ''}}">
                            <a href="{{ URL::to('dashboard')}}">
                                Home
                            </a>
                        </li>
                        <!-- End Home -->
						
						<!-- Leave -->
                        <li class="dropdown {{$leaveActive or ''}}">
                            <a href="" href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"  >
                                Leave
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="" data-toggle="modal" data-target=".apply_modal">Apply Leave</a></li>
                                <li><a href="{{route('front.leave')}}">My Leave</a></li>
                                 <li><a href="{{ URL::to('leaves_calendar')}}">Sick Leaves Calendar</a></li>
                              
                            </ul>
                        </li>
                       
                        <!-- End Leave -->
						<!-- My Account -->
                        <li class="dropdown">
                            <a href="" href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
                                My Account
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="" data-toggle="modal" data-target=".change_password_modal" id="change_password_link">Change Password</a></li>
                                <!-- Logout -->
                                @if(Auth::employees()->check())
                                <li>
                                    <a href="{{route('front.logout')}}">
                                        Logout
                                    </a>

                                </li>
                                @endif
                                <!-- End Logout -->

                            </ul>
                        </li>
                        <!-- End Leave -->
                        <li class="dropdown">
                         <a href="" href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown">
                         Complains  </a>
                          <ul class="dropdown-menu">
                                <li><a href="" data-toggle="modal" data-target=".add_complain">Add Complain</a></li>
                                <li><a href="{{route('front.complain')}}">My Complains</a></li>
                              
                            </ul>
                      
                        </li>
                        <li class="{{ $slipsActive  or "" }}">
                            <a href="{{ URL::to('/')}}/payment_slips">
                              Payment Slips
                            </a>
                        </li>
                        <li class="{{ $commisionActive  or "" }}">
                            <a href="{{ URL::to('/')}}/commision_history">
                              Claim Commision
                            </a>
                        </li>
                    </ul>
                </div><!--/navbar-collapse-->
            </div>    
        </div>            
        <!-- End Navbar -->
    </div>
    <!--=== End Header ===-->    

    <!--=== Profile ===-->
    <div class="profile container content">
            	<div class="row">
                        <!--Left Sidebar-->
                        <div class="col-md-3 md-margin-bottom-40">
                          {{HTML::image("/profileImages/{$employee->profileImage}",'ProfileImage',['class'=>"img-responsive profile-img margin-bottom-20",'style'=>'border:1px solid #ddd;margin:0 auto'])}}
                            {{--<img class="img-responsive profile-img margin-bottom-20" src="front_assets/img/team/5.jpg" alt="">--}}
            				<p>
            				<h3 style="text-align: center">{{$employee->fullName}}</h3>
            				<h6 style="text-align: center">{{$employee->getDesignation->designation}}</h6>
            				<h6 style="text-align: center;background: rgb(235, 235, 235);padding: 10px;"><strong>At work for : </strong>{{$employee->workDuration($employee->employeeID)}}</h6>
            				</p>
                            <hr>
							<h3 style="display:none">Attendance</h3>
							<div class="service-block-v3 service-block-u" style="">
							  <?php if(empty($today_attendance)){ ?>
							  <b>Working Status: <span id="working_status"> NOT started for today</span> </b>
							  <?php } else if($today_attendance->end_time==""){?>
							  <b>Working Status: <span id="working_status"> Working</span> </b>
							  <?php } else {?>
							   <b>Working Status: <span id="working_status">Finished Working</span> </b>
							 <?php  }  ?>
							<?php if(empty($today_attendance)){ ?>
							  <input type="button" class="btn btn-primary" onClick="start_work()" id="start_work_btn" value="Check In">
							<?php } ?>
							
							  <input type="button" class="btn btn-primary" onClick="stop_work()" id="stop_work_btn" <?php if(empty($today_attendance) || $today_attendance->end_time!=""){ ?> style="display:none" <?php  } ?> value="Check Out">
						  
							</div>
							<h3 style="display:none">Time Log</h3>
							<div class="service-block-v3 service-block-u" style="">
							  Today worked so far
							  <h3 id="basicUsage"><?=  gmdate('H:i:s',$employee_time_log) ?></h3>
							   <input type="button" class="btn btn-primary" onClick="start_time()" id="start_time_btn"  <?php if ($working_status==1){ ?> style="display:none" <?php } ?>  value="Start Time">
							   <input type="button" class="btn btn-primary" onClick="pause_time()" id="stop_time_btn" <?php if ($working_status==0){ ?> style="display:none" <?php } ?>  value="Pause Time">
							</div>
            				<div class="service-block-v3 service-block-u">
            						<!-- STAT -->
            							<div class="row profile-stat">
            								<!--<div class="col-md-4 col-sm-4 col-xs-6" data-toggle="tooltip" data-placement="bottom" title="{{date('F')}}">
            									<div class="uppercase profile-stat-title">
            										 {{$attendance_count}}
            									</div>
            									<div class="uppercase profile-stat-text">
            										 Attendance
            									</div>
            								</div>-->
            								<div class="col-md-4 col-sm-4 col-xs-6" data-toggle="tooltip" data-placement="bottom" title="Leaves">
            									<div class="uppercase profile-stat-title">
            										{{$leaveLeft}}
            									</div>
            									<div class="uppercase profile-stat-text">
            										 Leave
            									</div>
            								</div>
            								<div class="col-md-4 col-sm-4 col-xs-6" data-toggle="tooltip" data-placement="bottom" title="Sick Leave">
            									<div class="uppercase profile-stat-title">
            										{{$sickleave}}
            									</div>
            									<div class="uppercase profile-stat-text">
            										 Sick Leave
            									</div>
            								</div>
            							</div>
            							<!-- END STAT -->
                            </div>


                            <!--Notification-->
                     @if(count($current_month_birthdays)>0)
                            <div class="panel-heading-v2 overflow-h">
                                <h2 class="heading-xs pull-left"><i class="fa fa-birthday-cake"></i> Birthdays</h2>
                            </div>
                            <ul id="scrollbar5" class="list-unstyled contentHolder margin-bottom-20" style="height: auto">
                            @foreach($current_month_birthdays as $birthday)
                                <li class="notification">
                                 {{HTML::image("/profileImages/{$birthday->profileImage}",'ProfileImage',['class'=>"rounded-x"])}}

                                    <div class="overflow-h">
                                        <span><strong>{{$birthday->fullName}}</strong> has birthday on</span>
                                        <strong>{{date('d F',strtotime($birthday->date_of_birth))}}</strong>
                                    </div>
                                </li>
                             @endforeach

                            </ul>
                      @endif
                            <!--End Notification-->


                            <div class="margin-bottom-50"></div>
                        </div>
                        <!--End Left Sidebar-->

                        {{--------------------Main Area----------------}}
                               @yield('mainarea')
                        {{---------------Main Area End here------------}}


                    </div><!--/end row-->


    </div>
    <!--=== End Profile ===-->

    <!--=== Footer Version 1 ===-->
    <div class="footer-v1">

        <div class="copyright">
            <div class="container">
                <div class="row">
				<div class="col-md-4"></div>
                    <div class="col-md-4">                     
                        <p style="text-align: center;">
                            {{date('Y')}} &copy; {{$setting->website}}
                           
                        </p>
                    </div>

                    <!-- Social Links -->
                    <div class="col-md-4">

                    </div>
                    <!-- End Social Links -->
                </div>
            </div> 
        </div><!--/copyright-->
    </div>     
    <!--=== End Footer Version 1 ===-->


{{--------------------------Apply Leave  MODALS-----------------------------}}

            <div class="modal fade apply_modal in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                            <h4 id="myLargeModalLabel" class="modal-title">
                            Apply Leave
                            </h4>
                        </div>
                        <div class="modal-body">
                           <div class="portlet-body form">

                      <!------------------------------ BEGIN FORM ----------------------------------------->
                           {{Form::open(array('route'=>"front.leave_store",'files'=>true,'class'=>'sky-form','id'=>'sky-form1','method'=>'POST'))}}

                                   <div class="row">
                                        <div class="col-md-2">
                                              <label class="input">
                                              <i class="icon-append fa fa-calendar"></i>
                                              <input type="text" name="date[0]" id="leave" placeholder="Leave date">
                                              </label>
                                        </div>
                                     <div class="col-md-2">
                                          {{ Form::select('leaveType[0]', $leaveTypes,null,['class' => 'form-control leaveType','id'=>'leaveType0','onchange'=>'halfDayToggle(0,this.value)'] ) }}
                                    </div>
                                       <div class="col-md-2">
										  {{ Form::select('halfleaveType[0]', $leaveTypeWithoutHalfDay,null,['class' => 'form-control halfLeaveType','id'=>'halfLeaveType0'] ) }}
									</div>
                                       <div class="col-md-3">
                                               <input class="form-control form-control-inline"  type="text" name="reason[0]" placeholder="Reason"/>
                                       </div>
                                         <div class="col-md-3">
                                               <input type="file" class="form-control form-control-inline"  name="attachment_0" placeholder="Attachment"/>
                                       </div>
                                   </div>
                                    <div id="insertBefore"></div>

                                   <button type="button" id="plusButton" class="btn-u btn-u-green">
                                          Add More <i class="fa fa-plus"></i>
                                   </button>
                               <div class="row">
                                   <div class="col-md-offset-4 col-md-8">
                                       <button type="submit" class="btn-u btn-u-sea"><i class="fa fa-check"></i> Submit</button>

                                   </div>

                           </div>
                               {{ Form::close() }}
                         <!------------------------ END FORM ------------------------------------------>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
{{------------------------Apply Leave MODALS-------------------------}}

{{-----------------Compalin modal ---------------------------------------}}

 <div class="modal fade add_complain in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                            <h4 id="myLargeModalLabel" class="modal-title">
                            Add Complain
                            </h4>
                        </div>
                        <div class="modal-body">
                           <div class="portlet-body form">
                            {{Form::open(array('route'=>"front.complain_store",'class'=>'sky-form','id'=>'sky-form1','method'=>'POST'))}}
                              <div class="form-group">
                                <label>Problem</label>
                                <textarea rows="7" name="problem" required="required" class="form-control"></textarea> 
                              </div>
                              <div class="form-group">
                               <label>Do you have any solution?</label>
                               <textarea rows="7" name="solution" class="form-control"></textarea>  
                              </div>
                              <div class="form-group">
                              <input type="submit" class="btn btn-success" value="save">
                              </div>
                            {{ Form::close() }}
                           </div>
                        </div>
                     </div>
                   </div>
 </div>                   
         



{{--------------------------Change Password  MODALS-----------------------------}}

            <div class="modal fade change_password_modal in" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">

                        <div class="modal-header">
                            <button aria-hidden="true" data-dismiss="modal" class="close" type="button">×</button>
                             <h4  class="modal-title">
                                 Change Password
                                 </h4>
                        </div>
                        <div class="modal-body" id="change_password_modal_body">
							{{--Load with Ajax call--}}

                        </div>
                    </div>
                </div>
            </div>
{{------------------------Change Password  MODALS-------------------------}}



</div><!--/wrapper-->


<!-- JS Global Compulsory -->
{{HTML::script('front_assets/plugins/jquery/jquery.min.js')}}
{{HTML::script('front_assets/plugins/jquery/jquery-migrate.min.js')}}
{{HTML::script('front_assets/plugins/bootstrap/js/bootstrap.min.js')}}

<!-- JS Implementing Plugins -->
{{HTML::script('front_assets/plugins/back-to-top.js')}}

<!-- Scrollbar -->
{{HTML::script('front_assets/plugins/scrollbar/src/jquery.mousewheel.js')}}
{{HTML::script('front_assets/plugins/scrollbar/src/perfect-scrollbar.js')}}
<!-- JS Customization -->
{{HTML::script('front_assets//plugins/sky-forms/version-2.0.1/js/jquery-ui.min.js')}}
{{HTML::script('front_assets/plugins/sky-forms/version-2.0.1/js/jquery.form.min.js')}}
<!-- JS Page Level -->
{{HTML::script('front_assets/plugins/lib/moment.min.js')}}
{{HTML::script('front_assets/plugins/fullcalendar/fullcalendar.min.js')}}

<script>
    jQuery(document).ready(function ($) {
        "use strict";
        $('.contentHolder').perfectScrollbar();



    });
</script>
@yield('footerjs')

<script>
	$(function () {
  $('[data-toggle="tooltip"]').tooltip()
})
</script>

<!--[if lt IE 9]>
    {{HTML::script('front_assets/plugins/respond.js')}}
    {{HTML::script('front_assets/plugins/html5shiv.js')}}
<![endif]-->
<script>
{{'';$j=0;}}
        $('#leave').datepicker({minDate: 0});
        $('.halfLeaveType').hide();
            var $insertBefore = $('#insertBefore');
            var $i = 0;

		 $('#plusButton').click(function(){

              $i = $i+1;

              $(' <div class="row" id="row'+$i+'"> ' +
               	'<div class="col-md-2"><label class="input"><i class="icon-append fa fa-calendar"></i><input type="text" name="date['+$i+']" id="leave'+$i+'" placeholder="Leave Date"></label></div>' +
                '<div class="col-md-2">{{ Form::select('leaveType[]', $leaveTypes,null,['class' => 'form-control leaveType','id'=>'leaveType','onchange'=>'halfDayToggle(0,this.value)'] ) }}</div>'+
                '<div class="col-md-2">{{ Form::select('halfleaveType[]', $leaveTypeWithoutHalfDay,null,['class' => 'form-control halfLeaveType','id'=>'halfLeaveType'] ) }}</div>'+
                '<div class="col-md-3"><input class="form-control form-control-inline" name="reason['+$i+']" type="text" value="" placeholder="Reason"/></div>'+
                '<div class="col-md-3"><input type="file" class="form-control form-control-inline" name="attachment_'+$i+'" placeholder="Attachment"></div>'+
                '</div>').insertBefore($insertBefore);

			 $("#row"+$i+" .leaveType").attr('id','leaveType'+$i);
			 $("#row"+$i+" .halfLeaveType").hide();
			 $("#row"+$i+" .halfLeaveType").attr('id','halfLeaveType'+$i);
			 $("#row"+$i+" .leaveType").attr('onchange','halfDayToggle('+$i+',this.value)');

              $('#leave'+$i).datepicker({
                                              minDate: 0,
                                       });
            });

		 function halfDayToggle(id,value)
		 {
				if(value	==	'half day')
				{
					$('#halfLeaveType'+id).show(100);
				}else{
					$('#halfLeaveType'+id).hide(100);
				}
		 }

// Show change password modal body
		$('#change_password_link').click(function(){

			$('#change_password_modal_body').css("padding", "100px");
			$('#change_password_modal_body').html('{{HTML::image('front_assets/img/loading-spinner-blue.gif')}}');
			$('#change_password_modal_body').attr('class','text-center');

			$.ajax({
            			    type: 'POST',
            			    url: "{{route('front.change_password_modal')}}",

            			    data: {

            			    },
            			    success: function(response) {

            			    	$('#change_password_modal_body').css("padding", "0px");
            			    	$('#change_password_modal_body').removeClass('text-center');
            			    	$('#change_password_modal_body').html(response);
            			    },

            			    error: function(xhr, textStatus, thrownError) {
								$('#change_password_modal_body').html('<div class="alert alert-danger">Error Fetching data</div>');
            			    }
            			});

			});


		 function change_password()
		 {
			$("#submitbutton").prop('disabled', true);

			$('#error').html('{{HTML::image('front_assets/img/loading-spinner-blue.gif')}}');
			$('#error').attr('class','text-center');
			$.ajax({
				type:'POST',
				url:'{{route('front.change_password')}}',
				dataType: 'json',
				data: $('#change_password_form').serialize()
			}).done(function(response)
			{
				if(response.status=='success')
				{
					$('.field').hide();
					$('#error').html('<div class="alert alert-success"><span class="fa fa-check"></span> '+response.msg+'</div>');
					setTimeout(function () {
                              $('.change_password_modal').modal('hide');
                            }, 2000);

				}else if(response.status == "error")
							 {

								 var arr = response.msg;
								 var alert='';
								$('#error').attr('class','');
								 $("#submitbutton").prop('disabled', false);

								 $.each(arr, function(index, value)
								 {
									 if (value.length != 0)
									 {
										 alert += '<p><span class="fa fa-warning"></span> '+ value+ '</p>';

									 }
								 });

								 $('#error').html('<div class="alert alert-danger alert-dismissable">'+alert+'</div>');

							 }

			});


		 }
         $(function(){
             
            setInterval(function(){
               $.get('check_login_status',function(data){
                       data= JSON.parse(data);
                       if(data.type=='0'){
                           window.location="/";
                       }
                       
                   }); 
                
               },5000);
             
             
         });
</script>
</body>
</html>	