@extends('front.layouts.frontlayout')

@section('head')

{{HTML::style("assets/global/css/components.css")}}
{{HTML::style("assets/global/css/plugins.css")}}
{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
<link media="all" type="text/css" rel="stylesheet" href="https://fullcalendar.io/js/fullcalendar-2.2.5/fullcalendar.css">
@stop

@section('mainarea')
  <div class="col-md-9">
        <div id="calendar">
        
        
        </div>
  </div>       


@stop
@section('footerjs')
 <script src="https://fullcalendar.io/js/fullcalendar-2.2.5/fullcalendar.min.js"></script>
  <script src="https://fullcalendar.io/js/fullcalendar-2.2.5/lib/moment.min.js"></script>
 
 <script>
 $(function(){
      	$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			defaultView: 'month',
			editable: true,
			events: [
               @foreach($leaves as $leave)
				{
					title: 'Sick Leave',
					start: '<?= $leave->date  ?>'
				},
               @endforeach 
				
			]
		});
		
 });
 
 </script> 
@stop