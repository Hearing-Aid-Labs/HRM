@extends('front.layouts.frontlayout')

@section('head')
<style type="text/css">
  .other-container{
    margin-bottom: 10px;
  }
  .other-container input,.other-container select{
    margin-bottom: 10px;
    padding:5px;
  }

</style>

{{HTML::style("assets/global/css/components.css")}}
@stop
@section('mainarea')
<div class="col-md-9">
                <!--Profile Body-->
  <div class="profile-body">
    @if($employee->commision_type != 'percentage' && $employee->commision_type != 'fixed' )
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Claim submission form</h3>
            </div>
      <div class="panel-body">
        <h2>Your commision is disabled. Pleas ask HR to enable it.</h2>
      </div>
    </div>
    @elseif( $claim_found == '1' && $claim->approval_status=='Submitted' )
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Claim submission form</h3>
            </div>
      <div class="panel-body">
        <h2>You have already submitted the claim for {{$for_month}}. Approval is under process.</h2>
      </div>
    </div>
    @elseif( $claim_found == '1' && $claim->approval_status=='Apporved' )
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Claim submission form</h3>
            </div>
      <div class="panel-body">
        <h2>You have already submitted the claim for {{$for_month}} which is approved.</h2>
      </div>
    </div>
    @else
    <div class="panel panel-grey">
            <div class="panel-heading">
                    <h3 class="panel-title"><i class="fa fa-tasks"></i>Claim submission form</h3>
            </div>
      <div class="panel-body">
        @if( $claim_found == '1' && $claim->approval_status=='Rejected' )
          <div class="panel-body">
            <h2>Your last claim for {{$for_month}} is rejected. Below are comments from HR.</h2>
            <p><strong>{{$claim->comments}}</strong></p>
          </div>
        @endif
        {{Form::open(array('route'=>'commision.claim_submit','class'=>'form-horizontal form-bordered','method'=>'POST', 'id'=>"claim_submit"))}}
         <table id="slips" class="table table-striped table-bordered table-hover">
                <tbody>
                          <tr>
                            <th>For Month</th><td>{{$for_month}}
                              <input type="hidden" name="claim_id" value="{{ $claim_found == 1 ? '0':'0'}}" />
                              <input type="hidden" name="claim_form_moth" value="{{strtolower($for_month)}}" />
                              <input type="hidden" id="final_amt_hdn" name="final_amt_hdn" value="0" />

                            </td>
                          </tr>
                          <tr>
                            <th>Actual BTO</th><td><input type="text" value="{{ $BTO}}" readonly name="bto_amount" id="bto_amount" style="border:none"></td>
                          </tr>
                          <tr>
                            <th>Less Target {{$target_amount}}</th><td><input type="text" value="{{ $target_amount}}" readonly name="target_amount" id="target_amount" style="border:none" ></td>
                          </tr>
                          <tr>
                            <th>Final BTO over target</th><td id="bto_after_target"></td>
                          </tr>
                          <tr>
                            <th>Less Shortfall </th><td><input type="text" name="shortfall" id="shortfall" value="{{ $shortfall}}"></td>
                          </tr>
                          <!--tr>
                            <th>Less Branch Refund</th><td><input type="text" name="branch_refund" id="branch_refund" value="{{ $claim_found == 1 ? $claim->branch_refund:'0'}}"></td>
                          </tr>
                          <tr>
                            <th>Branch Refund reason</th><td><input type="text" name="refund_reason" value="{{ $claim_found == 1 ? $claim->refund_reason:''}}"></td>
                          </tr-->
                          
                          <tr>
                            <th>Final Amount Applicable</th><td id="final_amt"></td>
                          </tr>
                          <tr>
                            @if($employee->commision_type =='percentage')
                            <th>Actual %(percentage)</th><td><input type="number" name="commision_percentage" id="commision_percentage" value="{{ $claim_found == 1 ? $claim->commision_percentage: 0 }}"></td>
                            @else
                            <th>Actual Commision Fixed</th><td><input type="text" name="commision_amount_fixed" id="commision_amount_fixed" value="{{ $claim_found == 1 ? $claim->commision_amount_fixed: '0' }}"></td>
                            @endif

                          </tr>
                          <tr>
                            <th>Actual amount for commision </th><td id="commision_amount"></td>
                          </tr>
                          <tr>
                            <th valign="top">Other claims</th><td>
                              <div id="other_claims">
                                @forelse( $other_claims as $cl_index => $other_cl )
                                <div class="other-container" id="claim_box_{{$cl_index}}" >
                                  <select name="reason[]" >
                                    <option value="" >Select</option>
                                    <option {{ $other_cl->claim_reason=='travel'?" selected='selected' ":"" }} value="travel">Travel</option>
                                    <option {{ $other_cl->claim_reason=='refund'?" selected='selected' ":"" }} value="refund">Refund</option>
                                    <option {{ $other_cl->claim_reason=='other'?" selected='selected' ":"" }} value="other">Other</option>
                                  </select>
                                  <input type="text" name="details[]" placeholder="travelled 10 km from city1 to city 2" style="width: 100%;" value="{{ $other_cl->claim_details }}" />
                                  <input type="text" name="amount[]" placeholder="100.00" value="{{ $other_cl->claim_amount  }}" />
                                  @if( $cl_index >= 1 )
                                     <span style="float:right;cursor:pointer" onclick='$("#claim_box_{{$cl_index}}").remove()' > X </span>
                                  @endif
                                </div>
                                @empty
                                <div class="other-container">
                                  <select name="reason[]" >
                                    <option value="" >Select</option>
                                    <option value="travel">Travel</option>
                                    <option value="refund">Refund</option>
                                    <option value="other">Other</option>
                                  <input type="text" name="details[]" placeholder="travelled 10 km from city1 to city 2" style="width: 100%;" value="" />

                                  <input type="text" name="amount[]" placeholder="100.00"  />
                                </div>
                                @endforelse
                              </div>
                                <input type="button" name="add_other_claim" id="add_other_claim" Value="Add More claim">
                            </td>
                          </tr>
                
                </tbody>
         </table>
         <input type="submit" name="submit" value="Submit">
     </form>
     </div>
     </div>
     @endif
    </div>
</div>    

@stop
@section('footerjs')
<script type="text/javascript">
  commision_type = '{{$employee->commision_type}}';
  employee_json = {{ json_encode($employee) }};
  console.log(employee_json);
  function calculateafterTarget(){
    console.log("in calculate");
    $("#bto_after_target").html( Math.round( $("#bto_amount").val() - $("#target_amount").val() ) );
  }
  function calculateafterShortfall(){

    console.log("in calculate shortfall");
    $("#final_amt_hdn").val($("#bto_amount").val() - $("#target_amount").val()- $("#shortfall").val() );
    $("#final_amt").html( Math.round( $("#bto_amount").val() - $("#target_amount").val()- $("#shortfall").val() ) );
    if( commision_type != 'fixed' ){
        comm_amt_per = 0;
        console.log( "final amount hdn "+ $("#final_amt_hdn").val() );
        commision_chargable_amount = employee_json.target - employee_json.tier_1_amount ;//$("#bto_amount").val() - $("#shortfall").val();
        if( $("#final_amt_hdn").val() >= commision_chargable_amount ){
              comm_amt_per = employee_json.commision_1_amount;
              console.log("in 1 "+ comm_amt_per);
            }
            console.log("commision percentage after 1st if  "+comm_amt_per+" actual used "+$("#commision_percentage").val() );
        commision_chargable_amount = employee_json.target - employee_json.tier_2_amount ;//            
            if( $("#final_amt_hdn").val() >= commision_chargable_amount ){
              comm_amt_per=employee_json.commision_2_amount;
              console.log("in 2 "+ comm_amt_per);
            }
            console.log("commision percentage after second if "+comm_amt_per+" actual used "+$("#commision_percentage").val() );
        commision_chargable_amount = employee_json.target - employee_json.tier_3_amount ;//            
            if( $("#final_amt_hdn").val() >= commision_chargable_amount ){
              console.log("in 3 "+ comm_amt_per);
              comm_amt_per=employee_json.commision_3_amount;
            }
            console.log("commision percentage after third if "+comm_amt_per+" actual used "+$("#commision_percentage").val() );

            $("#commision_percentage").val(comm_amt_per);
            console.log("commision percentage "+comm_amt_per+" actual used "+$("#commision_percentage").val() );
    }else{



        comm_amt_fixed = 0;
            console.log("before"+ comm_amt_fixed+ " - final amount val "+$("#final_amt_hdn").val());

      //  commision_chargable_amount = employee_json.tier_1_amount - employee_json.target  ;//            

            if( $("#final_amt_hdn").val() >= employee_json.tier_1_amount ){
              comm_amt_fixed=employee_json.commision_1_amount;
              console.log("in 1 "+ comm_amt_fixed);
            }
            if( $("#final_amt_hdn").val() >= employee_json.tier_2_amount ){
              comm_amt_fixed=employee_json.commision_2_amount;
              console.log("in 2 "+ comm_amt_fixed);
            }
            if( $("#final_amt_hdn").val() >= employee_json.tier_3_amount ){
              console.log("in 3 "+ comm_amt_fixed);
              comm_amt_fixed=employee_json.commision_3_amount;
            }
            console.log( comm_amt_fixed);
            $("#commision_amount_fixed").val(comm_amt_fixed);
            $("#commision_amount").html(Math.round(comm_amt_fixed));
        console.log("in else calculating percentage ");
      }

    calculateafterCommisionAmt();
  }

  function calculateafterCommisionAmt(){
    if( commision_type != 'fixed' ){
      if( parseInt( $("#commision_percentage").val() )  >= 0 ){
        console.log("calculating percentage "+ $("#final_amt_hdn").val() );
        $("#commision_amount").html( Math.round($("#final_amt_hdn").val() / 100 * $("#commision_percentage").val() ) );
            
      
      }else{
        $("#commision_amount").html('0');
      }
    }else{
//            $("#commision_amount_fixed").val();
            $("#commision_amount").html($("#commision_amount_fixed").val());
        console.log("in else calculating percentage ");

//        $("#commision_amount").html( $("#commision_amount_fixed").val() );
    }
  }


  $("#commision_percentage,commision_amount_fixed").change( function(){
    console.log("in key up");
    calculateafterCommisionAmt();
  });
  $("#bto_amount").keyup( function(){
    console.log("in key up");
    calculateafterTarget();
  });
  $("#target_amount").keyup(function(){
    console.log("in key up");
    calculateafterTarget();
  });

  /*$("#shortfall").keyup(function(){
    console.log("in key up shorfall");
    calculateafterShortfall();
  });*/ /*
  $("#branch_refund").keyup(function(){
    console.log("in key up shorfall");
    calculateafterShortfall();
  }); */

  $(document).ready( function(){
    total_div_added={{$other_claims_count}};

    $("#add_other_claim").click(function(){
      total_div_added++;
      $("#other_claims").append('<div class="other-container" id="claim_box_'+total_div_added+'">'+
          '<select name="reason[]" ><option value="" >Select</option><option value="travel">Travel</option><option value="refund">Refund</option><option value="other">Other</option><input type="text" name="details[]" placeholder="travelled 10 km from city1 to city 2" style="width: 100%;" value="" />'+
        '<input type="text" name="amount[]" placeholder="100.00" /> <span style="float:right;cursor:pointer" onclick=\'$("#claim_box_'+total_div_added+'").remove()\' > X </span> </div>');
    });
    
      calculateafterTarget();
      calculateafterShortfall();
//      calculateafterCommisionAmt();

   if( commision_type != 'fixed' ){
        comm_amt_per = 0;
        if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_1_amount ){
              comm_amt_per=employee_json.commision_1_amount;
              console.log("in 1 "+ comm_amt_per);
            }
            if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_2_amount ){
              comm_amt_per=employee_json.commision_2_amount;
              console.log("in 2 "+ comm_amt_per);
            }
            if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_3_amount ){
              console.log("in 3 "+ comm_amt_per);
              comm_amt_per=employee_json.commision_3_amount;
            }
            $("#commision_percentage").val(comm_amt_per);
    }else{



        comm_amt_fixed = 0;
            console.log("before"+ comm_amt_fixed+ " - final amount val "+$("#final_amt_hdn").val());
            if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_1_amount ){
              comm_amt_fixed=employee_json.commision_1_amount;
              console.log("in 1 "+ comm_amt_fixed);
            }
            if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_2_amount ){
              comm_amt_fixed=employee_json.commision_2_amount;
              console.log("in 2 "+ comm_amt_fixed);
            }
            if( $("#bto_amount").val()-$("#shortfall").val() >= employee_json.tier_3_amount ){
              console.log("in 3 "+ comm_amt_fixed);
              comm_amt_fixed=employee_json.commision_3_amount;
            }
            console.log( comm_amt_fixed);
            $("#commision_amount_fixed").val(comm_amt_fixed);
            $("#commision_amount").html(Math.round(comm_amt_fixed));
        console.log("in else calculating percentage in ready  ");
      }
/*      calculateafterTarget();
      calculateafterShortfall();
      calculateafterCommisionAmt();*/

  });

</script>

<!-- BEGIN PAGE LEVEL PLUGINS -->
<!-- BEGIN PAGE LEVEL PLUGINS -->

    
    
@stop    