We have  received a password reset request for a user with this email address: {{ $user->email}}<br>
To reset your password, click the link below:<br><br>
@if(isset($is_admin) && $is_admin==1)
  <a href="{{App::make('url')->to('/')}}/admin/reset_password/{{$user->id}}/{{$token}}"> {{App::make('url')->to('/')}}/admin/reset_password/{{$user->id}}/{{$token}} </a><br>
@else
<a href="{{App::make('url')->to('/')}}/reset_password/{{$user->id}}/{{$token}}"> {{App::make('url')->to('/')}}/reset_password/{{$user->id}}/{{$token}} </a><br>
@endif
You can ignore this email if you did not request to reset your password.