Admin has invited you to accpet the new policy page "{{ $title}} "
To view page <a href="{{URL::to('/')}}/policy/view/{{$id}}">click here</a>

