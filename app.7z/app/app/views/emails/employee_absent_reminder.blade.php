<table width="100%" border="1" style="border-collapse:collapse; border-color:white;padding:10px">
		<tr>
	    	<td style="background-color:black;padding:10px;">
	    		 {{HTML::image("assets/admin/layout/img/logo-big.png",'Logo',array('class'=>'logo-default','height'=>'30px','width'=>'117px'))}}
	    	</td>
	    </tr>
	    <tr>
		  <td>
		    <h1>These employees are still not joined office today</h1>
		  
		  </td>
		
		</tr>
		@foreach($absent_employees as $employee)
		<tr>
	      <td>
              {{  $employee->fullName }}   {{   $employee->fatherName   }}
		  </td>
		 </tr> 
		@endforeach
		
</table>