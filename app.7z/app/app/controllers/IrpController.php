<?php
/*
 * Attendance Controller of Admin Panel
 */
class IrpController extends \AdminBaseController {


    public function __construct()
    {
        parent::__construct();
        $this->data['pageTitle'] =      'Irp5 documents';
          
    }  
    public function index()
    {
    
        $this->data['employees']=Employee::where('status','active')
        ->orderBy('fullName','asc')
        ->get();
        $this->data['irp5Active']  =   'active open';
         return View::make('admin.irp5.index',$this->data);    
    }
    public function add()
    {
        if(Input::has('employee_id'))
        {
            $ar['employee_id']=Input::get('employee_id');
            if(Input::hasFile('slip'))
            {
                  $destinationPath= public_path().'/employee_documents/slips/';
                  $name=rand()."_".time()."_".Input::file('slip')->getClientOriginalName();
                  Input::file('slip')->move($destinationPath, $name);
                
            }
            $ar['slip']= $name;
            $ar['date_created']=date('Y-m-d H:i:s');
            $ar['note']=Input::get('note');
            DB::table('irp5_documents')->insert($ar);
        }
        Session::flash('success',"Irp5 created successfully");
        return Redirect::back();
        
    }
   public function get_payment_slips()
   {
        $result = DB::table('irp5_documents')
            ->select('irp5_documents.date_created','irp5_documents.note','employees.fullName','irp5_documents.slip','irp5_documents.id')
	        ->join('employees', 'employees.id', '=', 'irp5_documents.employee_id')
            ->orderBy('irp5_documents.id','desc');
            
         return  Datatables::of($result)->make();	
       
   }
   public function get_slip($id)
   {
     $slip= DB::table('irp5_documents')->where('id',$id)->first();
      echo json_encode($slip);
      exit;    
   }
   public function update()
   {
       if(Input::has('slip_id'))
        {
             $slip_id=Input::get('slip_id');
             $ar['note']=Input::get('note');
             DB::table('irp5_documents')->where('id',$slip_id)->update($ar);
        }
        Session::flash('success',"irp5 updated successfully!");
        return Redirect::back();
        
       
   }
   public function delete($id)
   {
        DB::table('irp5_documents')
                   ->where('id',$id) 
                   ->delete();
        Session::flash('success',"irp5 deleted successfully");
        return Redirect::back();        
   
       
   }   
  
  
/*
 * This is the view page of attendance.
 */
	
		

}
