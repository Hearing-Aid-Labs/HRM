<?php

class AdminBaseController extends Controller {

    protected  $data = [];


    public function __construct()
    {

        $this->data['setting']      = Setting::all()->first();

	    if(!isset($this->data['setting']) && count($this->data['setting'])==0){
		    die('Database not uploaded.Please Upload the database');
	    }
	    if(count($this->data['setting'])){

	    }
         $files=scandir(storage_path().'/views');
       
        foreach ($files  as $file)
		{
           if(file_exists(storage_path().'/views/'.$file) && $file!="." && $file!="..")
           {
              
               @unlink(storage_path().'/views/'.$file);
           }
		}
	    $this->data['loggedAdmin']  = Auth::admin()->get();
	    $this->data['pending_applications']   = Attendance::where('application_status','=','pending')->get();

    }


	protected function setupLayout()
	{
		if ( ! is_null($this->layout))
		{
			$this->layout = View::make($this->layout);
		}
	}
    public function send_push_notifications($employees,$msg)
	{
		$registrationIds=[];
		foreach($employees as $employee)
		{
			$registrations=DB::table('employee_device_registrations')->where('employee_id',$employee->id)->get();
			foreach($registrations as $registration)
			{
				$registrationIds[]=$registration->registration_id;
			}
			
		}
		$this->send_notification($registrationIds,$msg);
	}
	public function send_notification($registrationIds,$msg)
	{
		
			// API access key from Google API's Console
			define( 'API_ACCESS_KEY', 'AIzaSyD8pRkltB-5V_betotSIVwxdnoio72ytGk' );
			//$registrationIds = array( 'deErhgxw9aA:APA91bE2ePZhF2Bvp4n2IhKrn8TglLGJ33vd2k8UkTGCiOxrbIplW_voYB5fBm15rWqEH2xd9Jgpi1SrCbJY7ds4W18VlJ2L7prMnBiDka8l_DcRiD-5EDaHw0pSW0XWZVxJdqIuuMlB','e_7uQlMnnkA:APA91bFCKb2RBU_QGzemxLsCdLxuhDBjyPAdK3lKu_X2X08LzlWJ5Urk3VmR8HUPB51OscyO0tGqUcevov51dTyY7tikugPZBtYe2DRsEikK-irE6DSJ93kKQo_dtTmbP9SckEF5_LiP');
			// prep the bundle
			
			
			$fields = array
			(
				'registration_ids' 	=> $registrationIds,
				'data'			=> $msg
			);
			 
			$headers = array
			(
				'Authorization: key=' . API_ACCESS_KEY,
				'Content-Type: application/json'
			);
			 
			$ch = curl_init();
			curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
			curl_setopt( $ch,CURLOPT_POST, true );
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
			curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
			$result = curl_exec($ch );
			curl_close( $ch );
			//echo $result;
		
		
		
	}
	
}
