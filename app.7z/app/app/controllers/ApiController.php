<?php

class ApiController extends \BaseController {
	public function __construct()
    {
		 parent::__construct();
		 //header('Access-Control-Allow-Origin:*');
		
	}
	public function login()
	{
		
		  $data	=	[
                'email'	    =>	Input::get('email'),
                'password'	=>	Input::get('password'),
	            'status'    =>  'active'
            ];
			if (Auth::employees()->attempt($data))
            {
			   $employee= Auth::employees()->get();
               $ar['employee_id']=$employee->id;
			   $ar['token']=md5(rand()).md5(time()).time();
			   $ar['date_created']=date('Y-m-d H:i:s');
			   DB::table('employee_app_tokens')->insert($ar);
			   $employee->token= $ar['token'];
               $result['type']=1;	
               $result['employee']=$employee;		
				
			}
			else 
			{
			   $result['type']=0;	
			}
	     return $result;
	
	}
	public function  start_work()
    {
        if(date("w",time())==7)
		{	
		     $ar['type']=0;
             $ar['message']="Today is off";
             return $ar;
		}  
		$employee_id=Input::get('employee_id');
		$token=Input::get('token');
		if($this->authnticate($employee_id,$token))
		{
			 $ar['employee_id']=$employee_id;
			 $ar['start_time']=date('Y-m-d H:i:s');
			 $ar['checked_in_from']=2;
			 $ar['date']=date('Y-m-d');
			if(Input::get('current_latitude')!=0 && Input::get('current_longitude')!=0 )
			 {
				 $ar['start_location']=Input::get('current_latitude').",".Input::get('current_longitude');
			 }
			 $attendance_count=DB::table('attendance_log')->where('employee_id',$ar['employee_id'])
			 ->where('date',$ar['date'])->count();
			  $employee=DB::table('employees')->where('id',$employee_id)->first();
               $admins = Admin::select('email')->get()->toArray();
               $admin=$admins[0];
               $to=$employee->email;
                 Mail::send('emails.user_logged_in', $this->data, function ($message) use ($admin,$to) {
                    $message->from($admin['email']);
                    $message->to($to)
                        ->subject('You are now checked in  ' . $this->data['setting']->website);
                });

			 if($attendance_count==0)
			 {
			   DB::table('attendance_log')->insertGetId($ar);	 
			   $attendanceAr['employeeID']=$employee->employeeID;
			  if( DB::table('attendance')->where('employeeID',$employee->employeeID)
				->where('date',$ar['date'])->count()==0)
				{		
				   $attendanceAr['date']=date('Y-m-d');
				   $attendanceAr['status']='present';
				   $attendanceAr['created_at']=date('Y-m-d H:i:s');
				   $attendanceAr['updated_at']=date('Y-m-d H:i:s');
				  // DB::table('attendance')->insertGetId($attendanceAr);	 
				}
			 }
			 $response['type']=1;
			 return $response;
	   }
	   else{
		   $response['type']=0;
		    return $response;
	   }
	   
		 
	}
	public function stop_work()
	{
		$employee_id=Input::get('employee_id');
		$token=Input::get('token');
		if($this->authnticate($employee_id,$token))
		{
			 $attendance=DB::table('attendance_log')->where('employee_id',$employee_id)
			 ->where('date',date('Y-m-d'))->first();
			 $attendance_id=$attendance->id;
			 $ar['end_time']=date('Y-m-d H:i:s');
			 if(Input::get('current_latitude')!=0 && Input::get('current_longitude')!=0 )
			 {
				 $ar['end_location']=Input::get('current_latitude').",".Input::get('current_longitude');
			 }
			 DB::table('attendance_log')->where('id',$attendance_id)->update($ar);
			  $response['type']=1;
			 return $response;
		}
		else
		{
			 $response['type']=0;
			 return $response;
			
		}
	}
	
	public function authnticate($employee_id,$token)
	{
		return true;
	    $total=DB::table('employee_app_tokens')->where('employee_id',$employee_id)->where('employee_id',$employee_id)->where('token',$token)->count();	
		return $total;
		
	}
	public function check_status()
	{
		$employee_id=Input::get('employee_id');
		$employee_working_status=$this->employee_working_status($employee_id);
		$employee_check_in_status=$this->employee_check_in_status($employee_id);
		$ar['type']='1';
		$ar['check_in_status']=$employee_check_in_status;
		$ar['working_status']=$employee_working_status;
		$ar['total_time_logged']=$this->employee_time_log($employee_id);
		return $ar;
		
	}
	public function start_time()
	{
        if(date("w",time())==7)
		{	
		     $ar['type']=0;
             $ar['message']="Today is off";
             return $ar;
		}
		$employee_id=Input::get('employee_id');
		$token=Input::get('token');
		if(DB::table('attendance_log')->where('employee_id',$employee_id)
		 ->where('date',date('Y-m-d'))->count()!=0)
		 {	 
			 $attendance=DB::table('attendance_log')->where('employee_id',$employee_id)
		    ->where('date',date('Y-m-d'))->first();
			if($attendance->end_time!=null)
			{
				 $ar['type']=0;
				 $ar['message']="You are now Check out";
				 return $ar;
			}
		 
		 }
		$time_log=DB::table('employee_time_log')->where('employee_id',$employee_id)
		 ->where('date',date('Y-m-d'))
		 ->orderBy('id','desc')
		 ->first();	
	    if(!(isset($time_log) && $time_log->end_time==null))
		{
			 $ar['employee_id']=$employee_id;
	         $ar['start_time']=date('H:i:s');
	         $ar['date']=date('Y-m-d H:i:s');
			 if(Input::get('current_latitude')!=0 && Input::get('current_longitude')!=0 )
			 {
				 $ar['start_location']=Input::get('current_latitude').",".Input::get('current_longitude');
			 }
			
             DB::table('employee_time_log')->insert($ar);	 
		}
		$ar['type']=1;
		$ar['check_in_status']=$this->employee_check_in_status($employee_id);
		
		return $ar;
		
	}
	public function stop_time()
	{
		$employee_id=Input::get('employee_id');
		$token=Input::get('token');
		 $time_log=DB::table('employee_time_log')->where('employee_id',$employee_id)
		 ->where('date',date('Y-m-d'))
		 ->where('end_time',null)
		 ->orderBy('id','desc')
		 ->first();	
	    if($time_log)
		{
			 $ar['end_time']=date('H:i:s');
			 if(Input::get('current_latitude')!=0 && Input::get('current_longitude')!=0 )
			 {
				 $ar['end_location']=Input::get('current_latitude').",".Input::get('current_longitude');
			 }
			 DB::table('employee_time_log')
			 ->where('id',$time_log->id)
			 ->update($ar);	  
			
		}
		$ar['type']=1;
		return $ar;
		
	}
	
	
	function employee_working_status($employee_id)
	{
		$time_log=DB::table('employee_time_log')
		->where('employee_id',$employee_id)
		->where('date',date('Y-m-d'))
		->orderBy('id','desc')
		->first();
		if(isset($time_log) && $time_log->end_time==null)
		{
			return 1;
		}
		else{
			
		     return 0;	
		}
		
	}
	
	function employee_check_in_status($employee_id)
	{ 
		  $date=date('Y-m-d');
		  $attendance_log= DB::table('attendance_log')
		 ->where('employee_id',$employee_id)
		 ->where('date',$date)->first();
		 if(isset($attendance_log))
		 {
			 if($attendance_log->end_time==null)
			 {
				 return 1;
			 }
			 else{
				 return 2;
			 }
		 }
		 else{
			 return 0;
		 }
		
		
	}
	function employee_time_log($employee_id)
	{
		
		$time_logs=DB::table('employee_time_log')
		->where('employee_id',$employee_id)
		->where('date',date('Y-m-d'))->get();
		$total_time_logged=0;
		foreach($time_logs as $time_log)
		{
			if($time_log->end_time==null)
			{
				$time_difference=time()-strtotime($time_log->start_time);
			}
			else
			{
				$time_difference=strtotime($time_log->end_time)-strtotime($time_log->start_time);
			}
			$total_time_logged+=$time_difference;
		}
	   return $total_time_logged;
	}
	public function set_registration_id()
	{
		$ar['employee_id']=Input::get('employee_id');
		$ar['registration_id']=Input::get('registration_id');
		$ar['date_created']=date('Y-m-d H:i:s');
		DB::table('employee_device_registrations')->insertGetId($ar);
		//echo 1;
		
	}
	public function send_check_in_reminder()
	{
		if(date("w",time())==0)
		{	
		 exit;
		}
		$check_timer=5*60;
        $departments=DB::table('department')
		->join('office_timing','office_timing.department_id','=','department.id')
		->get();
		  $employee_absentAr=[];
		 foreach($departments as $department)
		 {
			 $date=date('Y-m-d');
			 $total_email_sent=DB::table('checkin_reminder_cron')->where('department_id',$department->id)->where('date',$date)->count();
			 if($total_email_sent==0)
			 {
				
				 $open_timings=$department->open_timing;
				 if(time() > (strtotime($open_timings)+$check_timer))
			     {
				       $employees=DB::table('employees')->join('designation','designation.id','=','employees.designation')
						->where('designation.deptID',$department->id)
						->where('status','active')
						->select('employees.*')
						->get();
							foreach($employees as $employee)
							{
								$attendance_log=DB::table('attendance_log')->where('employee_id',$employee->id)->where('date',date('Y-m-d'))->first();
								
								if(empty($attendance_log))
								{
									$employee_absentAr[]=$employee;
								}
							  
							}
				       DB::table('checkin_reminder_cron')->insert(['date_sent'=>date('Y-m-d H:i:s'),'date'=>date('Y-m-d'),'department_id'=>$department->id]);	
				 }		
			 }
		  }
		  $msg = array
			(
				'message' 	=> 'Your office time is started, But your timer is still off please start timer if you are at work',
				'title'		=> 'Check in Reminder',
				'subtitle'	=> 'Check in Reminder',
				'tickerText'	=> 'Check in Reminder',
				'largeIcon'	=> 'large_icon',
				'smallIcon'	=> 'small_icon'
			);
		$this->send_reminder_notifications($employee_absentAr,$msg);
		  
		
		
	}
	public function send_check_out_reminder()
	{
		if(date("w",time())==7)
		{	
		 exit;
		}
		$check_timer=5*60;
        $departments=DB::table('department')
		->join('office_timing','office_timing.department_id','=','department.id')
		->get();
		  $employee_absentAr=[];
		 foreach($departments as $department)
		 {
			 $date=date('Y-m-d');
			 $total_email_sent=DB::table('checkout_reminder_cron')->where('department_id',$department->id)->where('date',$date)->count();
			 if($total_email_sent==0)
			 {
				
				 $close_timings=$department->close_timing;
				 if(time() > (strtotime($close_timings)+$check_timer))
			     {
				       $employees=DB::table('employees')->join('designation','designation.id','=','employees.designation')
						->where('designation.deptID',$department->id)
						->where('status','active')
						->select('employees.*')
						->get();
							foreach($employees as $employee)
							{
								$attendance_log=DB::table('attendance_log')->where('employee_id',$employee->id)->where('date',date('Y-m-d'))->first();
								if(!empty($attendance_log) && $attendance_log->end_time==NULL)
								{
									$employee_absentAr[]=$employee;
								}
							  
							}
				        DB::table('checkout_reminder_cron')->insert(['date_sent'=>date('Y-m-d H:i:s'),'date'=>date('Y-m-d'),'department_id'=>$department->id]);	
				 }		
			 }
		  }
		  $msg = array
			(
				'message' 	=> 'Your office time is ended, But your timer is still on,Please Turn off timer  if you finished work',
				'title'		=> 'Check out Reminder',
				'subtitle'	=> 'Check out Reminder',
				'tickerText'	=> 'Check out Reminder',
				'largeIcon'	=> 'large_icon',
				'smallIcon'	=> 'small_icon'
			);
		$this->send_reminder_notifications($employee_absentAr,$msg);
		  
		
		
	}
	public function send_reminder_notifications($employees,$msg)
	{
		$registrationIds=[];
		foreach($employees as $employee)
		{
			$registrations=DB::table('employee_device_registrations')->where('employee_id',$employee->id)->get();
			foreach($registrations as $registration)
			{
				$registrationIds[]=$registration->registration_id;
			}
			
		}
		$this->send_notification($registrationIds,$msg);
	}
	public function send_notification($registrationIds,$msg)
	{
		
			// API access key from Google API's Console
			define( 'API_ACCESS_KEY', 'AIzaSyD8pRkltB-5V_betotSIVwxdnoio72ytGk' );
			//$registrationIds = array( 'deErhgxw9aA:APA91bE2ePZhF2Bvp4n2IhKrn8TglLGJ33vd2k8UkTGCiOxrbIplW_voYB5fBm15rWqEH2xd9Jgpi1SrCbJY7ds4W18VlJ2L7prMnBiDka8l_DcRiD-5EDaHw0pSW0XWZVxJdqIuuMlB','e_7uQlMnnkA:APA91bFCKb2RBU_QGzemxLsCdLxuhDBjyPAdK3lKu_X2X08LzlWJ5Urk3VmR8HUPB51OscyO0tGqUcevov51dTyY7tikugPZBtYe2DRsEikK-irE6DSJ93kKQo_dtTmbP9SckEF5_LiP');
			// prep the bundle
			
			
			$fields = array
			(
				'registration_ids' 	=> $registrationIds,
				'data'			=> $msg
			);
			 
			$headers = array
			(
				'Authorization: key=' . API_ACCESS_KEY,
				'Content-Type: application/json'
			);
			 
			$ch = curl_init();
			curl_setopt( $ch,CURLOPT_URL, 'https://android.googleapis.com/gcm/send' );
			curl_setopt( $ch,CURLOPT_POST, true );
			curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
			curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
			curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
			$result = curl_exec($ch );
			curl_close( $ch );
			//echo $result;
		
		
		
	}
	
	
	
	
}


?>