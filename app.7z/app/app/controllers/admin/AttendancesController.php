<?php
/*
 * Attendance Controller of Admin Panel
 */
class AttendancesController extends \AdminBaseController {


    public function __construct()
    {
        parent::__construct();
        $this->data['attendanceOpen'] ='active open';
        $this->data['pageTitle'] =      'Attendance';
    }


/*
 * This is the view page of attendance.
 */
	public function index()
	{
		$this->data['attendances']          =   Attendance::all();
        $this->data['viewAttendanceActive'] =   'active';

        $this->data['date']     = date('Y-m-d');
        $this->data['employees']            =   Employee::where('status','=','active')->get();
        $this->data['leaves'] = Attendance::absentEveryEmployee();
		return View::make('admin.attendances.index', $this->data);
	}


/*
 * This method is called when we mark the attendance and redirects to edit page.
 */
	public function create()
	{
            $date             = (Input::get('date') != '') ? Input::get('date') : date('Y-m-d');
            $date             = date('Y-m-d', strtotime($date));

            $attendance_count           = Attendance::where('date','=',$date)->count();
            $employee_count             = Employee::where('status','=','active')->count();

            if($employee_count  ==  $attendance_count)
            {
                if(!Session::get('success'))
                    Session::flash('success',"<strong>Attendance already marked</strong>");
            }else
            {
                Session::forget('success');
            }
                return Redirect::route('admin.attendances.edit',$date );
	}




	/**
	 * Display the specified attendance
	 */
	public function show($id)
    {
        $this->data['viewAttendanceActive'] = 'active';

        $this->data['employee']     = Employee::where('employeeID', '=', $id)->get()->first();
        $this->data['attendance']   = Attendance::where('employeeID', '=', $id)
                                            ->where(function($query)
                                            {
                                                $query->where('application_status','=','approved')
                                                      ->orwhere('application_status','=',null)
                                                      ->orwhere('status','=','present');
                                            })->groupBy('date')->get();
        $this->data['holidays']     = Holiday::all();
        $this->data['employeeslist'] = Employee::lists('fullName','employeeID');


		return View::make('admin.attendances.show', $this->data);
	}

	/**
	 * Show the form for editing the specified attendance.
	 */
	public function edit($date)
	{
        $attendanceArray = array();
		$this->data['attendance']   = Attendance::where('date','=',$date)->get()->toArray();

        $this->data['todays_holidays'] = Holiday::where('date','=',$date)->get()->first();

        foreach($this->data['attendance'] as $attend)
        {
            $attendanceArray[$attend['employeeID']] = $attend;
        }

        $this->data['date']             =   $date;
        $this->data['attendanceArray']  =   $attendanceArray;



		$this->data['leaveTypes']  =    Attendance::leaveTypesEmployees();
        $this->data['leaveTypeWithoutHalfDay']   =   Attendance::leaveTypesEmployees('half day');
        $this->data['employees']    =   Employee::where('status','=','active')->get();

		return View::make('admin.attendances.edit', $this->data);
	}

	/**
	 * Update the specified attendance in storage.
	 */
	public function update($date)
    {

		$validator = Validator::make($input = Input::all(), Attendance::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

        foreach ($input['employees'] as $employeeID)
        {

            $user     =  Attendance::firstOrCreate([
                'employeeID'    => $employeeID,
                'date'          => $date,
            ]);
			if($user->application_status !='approved' || ($user->application_status =='approved' && isset($input['checkbox'][$employeeID])=='on'))
			{
				$update = Attendance::find($user->id);
				$update->status     = (isset($input['checkbox'][$employeeID])=='on')?'present':'absent';
				$update->leaveType  = (isset($input['checkbox'][$employeeID])=='on')?null:$input['leaveType'][$employeeID];
				$update->halfDayType  = ( (!isset($input['checkbox'][$employeeID])=='on') && ($input['leaveType'][$employeeID]=='half day'))?$input['leaveTypeWithoutHalfDay'][$employeeID]:null;
				$update->reason     = (isset($input['checkbox'][$employeeID])=='on')?'':$input['reason'][$employeeID];
				$update->application_status     = null;
				$update->updated_by     = Auth::admin()->get()->email;
				$update->save() ;
			}

        }
		$this->data['date'] = date('d M Y',strtotime($date));

        if($this->data['setting']->attendance_notification==1) {

            $employees = Employee::select('email','fullName')->where('status', '=', 'active')->get();
            foreach ($employees as $employee) {
                $email = "{$employee->email}";
				$this->data['employee_name'] = $employee->fullName;
	            //  Send Email to All active users
	            Mail::send('emails.admin.attendance', $this->data, function ($message) use ($email) {
	                $message->from($this->data['setting']->email, $this->data['setting']->name);
	                $message->to($email)
	                    ->subject('Attendance marked - ' . $this->data['date']);
	            });
            }
        }

        Session::flash('success',date('d M Y',strtotime($date)). " successfully Updated");
		return Redirect::route('admin.attendances.edit',$date);
	}

    public function report()
    {

        $month          =   Input::get('month');
        $year           =   Input::get('year');
        $employeeID     =   Input::get('employeeID');

        $firstDay       =   $year.'-'.$month.'-01';


        $presentCount   =   Attendance::countPresentDays($month,$year,$employeeID);

        $totalDays      =  date('t',strtotime($firstDay));

        $holidaycount   =   count(DB::select( DB::raw("select * from holidays where MONTH(date)=".$month )));
        $workingDays    =   $totalDays - $holidaycount;


        $percentage     =   ($presentCount/$workingDays)*100;
        $output['success']  =   'success';
        $output['presentByWorking']    =   "{$presentCount}/$workingDays";

        $output['attendancePerReport']    =   number_format((float)$percentage, 2, '.', '');
        return Response::json($output, 200);



    }
	/**
	 * Remove the specified attendance from storage.
	 */
	public function destroy($id)
	{

		Attendance::destroy($id);

		return Redirect::route('admin.attendances.index');
	}
	public function attendance_log()
	{
	   return View::make('admin.attendances.log', $this->data);
	}
    public function attendance_log_calendar()
    {
		//ini_set("display_error",1);
		//error_reporting(E_ALL);    	
    	$firstdate = date('Y').'-01-01';
    	$today_date = date('Y-m-d'); 
        $attendance_log_calendar= DB::table('attendance_log')
		    ->select(DB::raw('group_concat(employee_id) as employees,date'))
		    ->where('attendance_log.date', '>=', $firstdate )
		    ->where('attendance_log.date', '<=', $today_date )
            ->groupBy('attendance_log.date')->get() ;
          $absentEmployees=[];
//          echo "in log";
          //print_r( $attendance_log_calendar );

         foreach($attendance_log_calendar as $log)
         {
        //       echo "<br /> key".$log->date;
               $employeeIds=explode(',',$log->employees);
               $employeesAr=DB::table('employees')
						->where('status','active')
						->select('employees.*')
                        ->whereNotIn('id',$employeeIds)
						->get();  
               $absentEmployees[$log->date]=$employeesAr;        
             
         }

         $this->data['absent_employees']= $absentEmployees;
       //  echo "after absent";

         return View::make('admin.attendances.attendance_log_calendar', $this->data);
    }
	public function get_attendance_daily_log()
	{
		 $result = DB::table('attendance_log')
		    ->select('employees.employeeID','employees.fullName','attendance_log.date','attendance_log.start_time','attendance_log.end_time','open_timing','close_timing','attendance_log.date','attendance_log.id')
	        ->join('employees', 'employees.id', '=', 'attendance_log.employee_id')
		    ->leftJoin('designation','employees.designation','=','designation.id')					
			->leftJoin('office_timing','designation.deptID','=','office_timing.department_id');
		
			
		if(Input::get('date'))
		{
			 $result ->where('date',Input::get('date'));
			
		}	
		 
       return  Datatables::of($result)->make();	
		    
		
	}
	public function office_timings()
	{
		$this->data['departments']=DB::table('department')->get();
		$this->data['office_timings']=DB::table('office_timing')
		->select('office_timing.id as timing_id','office_timing.*','department.*')
		->join('department','office_timing.department_id','=','department.id')->get();
	
		return View::make('admin.attendances.office_timings', $this->data);
	}
	public function view_timelog($date,$employeeID)
	{
		$employee=DB::table('employees')->where('employeeID',$employeeID)->first();
		$employee_id=$employee->id;
		$time_log=DB::table('employee_time_log')->where('date',$date)->where('employee_id',$employee_id)->get();
		$total_time_worked=$this->employee_time_log($employee_id,$date);
		$this->data['total_time_worked']=$total_time_worked;
		$this->data['time_log']=$time_log;
		return View::make('admin.attendances.view_time_log', $this->data);
		
		
	}
    public function leave_application_reminder_cron()
    {
        $leaves=\DB::table('attendance')->whereNotNull('applied_on')->where('application_status','pending')->where('date','>',date('Y-m-d'))->get();
        foreach($leaves as $leave)
        {
            $time_to_check="";
            if($leave->last_email_sent=="")
            {
               
                $time_to_check=strtotime($leave->applied_on);
              
            } 
            else{
               
            $time_to_check=strtotime($leave->last_email_sent); 
                   
            }
           
            if(time()>($time_to_check+2*24*36*36))
            {
                
                \DB::table('attendance')->where('id',$leave->id)->update(array('last_email_sent'=>date('Y-m-d H:i:s')));
                $this->data['dates'][0] = date('d-M-Y', strtotime($leave->date));
                $this->data['leaveType'][0] = $leave->leaveType;
                $this->data['reason'][0] = $leave->reason;
                $admins = Admin::select('email')->get()->toArray();
                $employee=\DB::table('employees')->where('employeeID',$leave->employeeID)->first();
                $this->data['employee_name']=$employee->fullName;
                foreach ($admins as $admin){
                    Mail::send('emails.leave_request', $this->data, function ($message) use ($admin,$employee) {
                        $message->from($employee->email, $employee->fullName);
                        $message->to($admin['email'])
                            ->subject('Leave Request - ' . $this->data['setting']->website);
                    });
                }     
            
                
            }
        
        }
        
    }
	public function employee_attedance_reminder_cron()
	{
		//exit;
		if(date("w",time())==0)
		{	
		 exit;
		}
		$check_timer=30*60;
        $departments=DB::table('department')
		->join('office_timing','office_timing.department_id','=','department.id')
		->get();
		  $employee_absentAr=[];
		 foreach($departments as $department)
		 {
			 $date=date('Y-m-d');
			 $total_email_sent=DB::table('attendance_reminder_cron')->where('department_id',$department->id)->where('date',$date)->count();
			 if($total_email_sent==0)
			 {
				
				 $open_timings=$department->open_timing;
				 if(time() > (strtotime($open_timings)+$check_timer))
			     {
				       $employees=DB::table('employees')->join('designation','designation.id','=','employees.designation')
						->where('designation.deptID',$department->id)
						->where('status','active')
						->select('employees.*')
						->get();
							foreach($employees as $employee)
							{
								$attendance_log=DB::table('attendance_log')->where('employee_id',$employee->id)->where('date',date('Y-m-d'))->first();
								
							//	print_r($attendance_log);
								if(empty($attendance_log))
								{
									$employee_absentAr[]=$employee;
								}
							  
							}
				        DB::table('attendance_reminder_cron')->insert(['date_sent'=>date('Y-m-d H:i:s'),'date'=>date('Y-m-d'),'department_id'=>$department->id]);	
				 }		
				
				 
			 }
			
		 }
		   if(!empty($employee_absentAr))
		   {   
			  
				$this->data['absent_employees']=$employee_absentAr;
				$admins = Admin::select('email')->get()->toArray();
				foreach ($admins as $admin){
					Mail::send('emails.employee_absent_reminder', $this->data, function ($message) use ($admin) {
						//$admin['email']="shehzadbaqir@gmail.com";
						$message->from($this->data['setting']->email, $this->data['setting']->name);
						$message->to($admin['email'])
							->subject('Absent Employees ' . $this->data['setting']->website);
					});
				}
		   }
		
		
	}
	
	
	
	function employee_time_log($employee_id,$date)
	{
		
		$time_logs=DB::table('employee_time_log')
		->where('employee_id',$employee_id)
		->where('date',$date)->get();
		$total_time_logged=0;
		foreach($time_logs as $time_log)
		{
			if($time_log->end_time==null)
			{
				//$time_difference=time()-strtotime($time_log->start_time);
				return 0;
			}
			else
			{
				//echo date('H:i:s',strtotime($time_log->end_time));
				$time_difference=strtotime($time_log->end_time)-strtotime($time_log->start_time);
			}
			$total_time_logged+=$time_difference;
		}
	   return $total_time_logged;
	}
	public function save_office_timings()
	{
		if(Input::get('start_time_hours'))
		{
		  $ar['open_timing']=Input::get('start_time_hours').":".Input::get('start_time_minutes').":"."00";
		  $ar['close_timing']=Input::get('end_time_hours').":".Input::get('end_time_minutes').":"."00";
		  $ar['department_id']=Input::get('department');
		  if(DB::table('office_timing')->where('department_id',$ar['department_id'])->count()==0)
		  {
			  DB::table('office_timing')->insert($ar);
			  Session::flash('success_message', 'successfully added!');
		  }
		  else
		  {
			  DB::table('office_timing')->where('department_id',$ar['department_id'])->update($ar);
			   Session::flash('success_message', 'successfully updated!');
			  
		  }
		  
		}
		return Redirect::back();
		
	}
	public function edit_office_timings($id)
	{
		$this->data['departments']=DB::table('department')->get();
		$timings=DB::table('office_timing')->where('id',$id)->first();
		$this->data['office_timing']=$timings;
		$open_timing_ar=explode(":",$timings->open_timing);
		$end_timing_ar=explode(":",$timings->close_timing);
		$this->data['open_hours']=$open_timing_ar[0];
		$this->data['open_minutes']=$open_timing_ar[1];
		$this->data['end_hours']=$end_timing_ar[0];
		$this->data['end_minutes']=$end_timing_ar[1];
	     return View::make('admin.attendances.edit_office_timings', $this->data);
	   	
	}
	public function view_sheet($date)
	{
		$this->data['date']=$date;
		$this->data['departments']=DB::table('department')->get();
		return View::make('admin.attendances.sheet', $this->data);
	}
    public function employee_working_status()
    {
        
        $this->data['employees']=$employees=DB::table('employees')
        ->leftjoin('attendance_log',function($join)
        {
            $date=date('Y-m-d');
            $join->on('attendance_log.employee_id','=','employees.id');
            $join->on('attendance_log.date','=',DB::raw("'".$date."'"));
        })->where('employees.status','=','active')
        ->get();
        $working_employees=[];
        $not_working_employees=[];
        foreach($employees as $employee)
        {
            if($employee->start_time!="" && $employee->end_time=="")
            {
              $working_employees[]=$employee;
            }
            else{
                 $not_working_employees[]=$employee;
            }
            
        }
        $this->data['working_employees']=$working_employees;
        $this->data['not_working_employees']=$not_working_employees;
        $this->data['workingStatusActive']='active';
		return View::make('admin.attendances.employee_working_status', $this->data);   
        
    }
		

}
