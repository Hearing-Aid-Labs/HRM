@extends('admin.adminlayouts.adminlayout')

@section('head')
	<!-- BEGIN PAGE LEVEL STYLES -->
	{{HTML::style("assets/global/plugins/bootstrap-datepicker/css/datepicker3.css")}}
	{{HTML::style("assets/global/plugins/select2/select2.css")}}
	{{HTML::style("assets/global/plugins/datatables/plugins/bootstrap/dataTables.bootstrap.css")}}
	<!-- END PAGE LEVEL STYLES -->
     <link media="all" type="text/css" rel="stylesheet" href="/front_assets/plugins/fullcalendar/fullcalendar.css">

        <link media="print" type="text/css" rel="stylesheet" href="/front_assets/plugins/fullcalendar/fullcalendar.print.css">
@stop
@section('mainarea')
<div class="row">

                    <div class="col-sm-2">

                            <div class="form-group">

                                <label for="start_date">Start Date</label>

                                <input type="text" name="start_date" value="" class="form-control date input-xs" onchange="date_change(this.value)" aria-controls="medical_aid" id="start_date">

                            </div>

                        </div>

                 <div class="col-sm-2">

                            <div class="form-group">

                                <label for="end_date">End Date</label>

                                <input type="text" name="end_date" value="" class="form-control date input-xs" aria-controls="medical_aid" onchange="date_change(this.value)" id="end_date">

                            </div>

                   </div> 

                </div>
<div class="row">
  <div class="col-md-12">
        <div id="calendar">
        
        
        </div>
  </div>       
</div>

@stop
@section('footerjs')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.js"></script>
<script src="/front_assets/plugins/fullcalendar/fullcalendar.min.js"></script>
  
 
 <script>
 $(function(){
      	$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,agendaWeek,agendaDay'
			},
			defaultView: 'month',
			editable: false,
			events: [
            <?php  
            foreach($absent_employees as $index=>$date)  { 
                ?>
               @foreach($date as $employee)
				{
					title: '<?=  $employee->fullName ?>',
					start: '<?=  $index ?>'
				},
                @endforeach
            <?php  } ?>
				
			]
		});
		
 });
 
 </script> 
 @stop