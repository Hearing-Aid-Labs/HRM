<?php

class CommisionController extends \AdminBaseController {



    public function __construct()
    {
        parent::__construct();
        $this->data['CommisionOpen'] ='active open';
        $this->data['pageTitle'] ='Commision';
    }

    public function index()
	{
		$this->data['Commision']          =   Commision::all();
        $this->data['CommisionActive']    =   'active';
        $this->data['commisionOpen']      =   'open';

		$this->data['commision_config']   =   Commision_config::first();
		//print_r( $this->data['commision_config'] );

		return View::make('admin.commision.index', $this->data);
	}

	public function commision_unclaimed(){
		$this->data['pageTitle'] ='Commision UnClaimed';
        $this->data['unclaimListActive']    =   'active';
        $this->data['commisionOpen']      =   'open';

        $this->data['for_year'] = $year = date("Y", strtotime("first day of previous month") );
        $this->data['for_month'] = date("M", strtotime("first day of previous month") );

        $this->data['start_year'] = 2021;
        $this->data['commission_till_year'] = $year;
        $this->data['month_range'] = array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");

		return View::make('admin.commision.unclaimed', $this->data);

	}


	public function commision_claims(){
		$this->data['pageTitle'] ='Commision Claims';
        $this->data['claimListActive']    =   'active';
        $this->data['commisionOpen']      =   'open';

        $this->data['for_year'] = $year = date("Y", strtotime("first day of previous month") );
        $this->data['for_month'] = date("M", strtotime("first day of previous month") );

        $this->data['start_year'] = 2021;
        $this->data['commission_till_year'] = $year;
        $this->data['month_range'] = array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec");


		return View::make('admin.commision.claims', $this->data);

	}

	public function get_single_claim( $claim_id = 0 ){
		$claim = Employee_monthly_claims::where(["id"=>$claim_id])->first();
		if( $claim ){
			
			$claim_array = $claim->toArray();
			
			$other_claims = Employee_other_claims::where( [ 'employee_monthly_claim_id' => $claim_array['id'] ] )->get();
			if( $other_claims ){
				$other_claims_arr = $other_claims->toArray();
				$claim_array['other_claims']=$other_claims_arr;
			}else{
				$claim_array['other_claims']=[];
			}
			
			json_encode( array("success"=>1,"msg"=>"Found", "claim_array" => $claim_array) );
			$this->data['claim_array'] = $claim_array;
			return View::make('admin.commision.single', $this->data );
		
		}else{
			echo json_encode( array("success"=>0,"msg"=>"Record not found") );
		}
	}

	public function post_unclaimed_email_reminder( $employeeID ){
		$employee = Employee::where([ "employeeID" => $employeeID ])->first();
		////print_r( $employee);
		$employee_name = $this->data['employee_name'] = $employee->fullName." - ".$employee->email;
		echo "email is ".$employee->email;
		Mail::send('emails.admin.claim_reminder', $this->data, function($message) use($employee_name)
            {
                $message->from($this->data['setting']->email, $this->data['setting']->name);

                $message->to( 'sudhirpur123@gmail.com', $employee_name)
                    ->subject('Commission Claim Reminder - '.$this->data['setting']->website);
            });

	}	

	public function get_unclaimed_employees(){
	    $input = Input::all();
	    //$this->input->post()
	    $year = $claim_month = $input['claim_month'];
	    $month = $claim_year = $input['claim_year'];
	    $for_month = strtolower( $claim_month."-".$claim_year );

        $year = date("Y", strtotime("first day of previous month"));
        $month = date("M", strtotime("first day of previous month"));

////        $this->data['for_month'] = $for_month =  $month."-".$year;

		$emp =  Employee_monthly_claims::select( 'employee_id')->where( ['for_month' => $for_month ] )->get();
		$found_emp[] = 0;
		if( $emp ){
			$emp_arr = $emp->toArray();
			foreach ( $emp_arr  as $key => $emp_single) {
				$found_emp[] = $emp_single['employee_id'];
			} 
		}
//		print_r( $found_emp );
        $result = DB::table('employees as e')
            ->select('e.employeeID as employeeID','e.fullName as fullname', 'd.designation as designation','dept.deptName' ,DB::raw( '"'. $for_month .'" as for_month')
                  )
            ->join('designation as d ','e.designation','=','d.id')
            ->join('department as dept ','d.deptID','=','dept.id')
            ->whereIn( 'd.designation',['Sales manager','Secretary'])
            ->where( 'e.status','active')
            ->whereNotIn("e.employeeID", $found_emp );

         return  Datatables::of($result)
			->add_column('Send Email Reminder', '
            <a  class="btn purple"  href="javascript:void(0)" onclick="email_reminder(\'{{$employeeID}}\')" ><i class="fa fa-edit"></i> Send Email Reminder</a>')
            ->remove_column('id')->make(); 
	}

	public function get_commision_claims(){
    $year = date("Y", strtotime("first day of previous month"));
    $month = date("M", strtotime("first day of previous month"));

    $this->data['for_month'] = $for_month =  $month."-".$year;
    $input = Input::all();
    //$this->input->post()
    $claim_month = $input['claim_month'];
    $claim_year = $input['claim_year'];
    $for_month = strtolower( $claim_month."-".$claim_year );
/*	 
    $sql = "SELECT SUM(amount) AS total_paid FROM sma_payments inner join sma_sales on sma_sales.id=sma_payments.sale_id ";
    if ($Sdate) {
        $sql .= " WHERE sma_payments.date >='" . $Sdate . " 00:00:00' AND sma_payments.date<= '" . $Edate . " 23:59:59'";
*/

/*        $result = DB::table('employee_monthly_claims as emc')
            ->select('emc.id as id','e.fullName as fullname', 'emc.created_at','for_month', 'shortfall','bto_amount','target_amount','final_amount_commision_applicable','commision_applicable',DB::raw('FORMAT(sum(claim_amount),2) as claim_amount'), DB::raw('(FORMAT(sum(claim_amount)+commision_applicable,2)) as FinalCommission'),'approval_status')
            ->join('employees as e ','emc.employee_id','=','e.employeeID')
                ->leftJoin('employee_other_claims', 'emc.id', '=', 'employee_other_claims.employee_monthly_claim_id');
*/
/*
        $result = DB::table('employee_monthly_claims as emc')
            ->select('emc.id as id','e.fullName as fullname', 'emc.created_at','for_month', 'shortfall','bto_amount','target_amount','final_amount_commision_applicable','commision_applicable',
                  DB::raw(' (select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )as claim_amount'), DB::raw('(FORMAT((select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )+commision_applicable,2)) as FinalCommission'),'approval_status')
            ->join('employees as e ','emc.employee_id','=','e.employeeID');*/
        $result = DB::table('employee_monthly_claims as emc')
            ->select('emc.id as id','e.fullName as fullname', 'emc.created_at','for_month', 'shortfall','bto_amount','target_amount','final_amount_commision_applicable','commision_applicable',
                  DB::raw(' (select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id) '), DB::raw('FORMAT((select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = emc.id )+commision_applicable,2)'),'approval_status')
            ->join('employees as e ','emc.employee_id','=','e.employeeID')
            ->where(['for_month'=> $for_month ]);
        /*$result = DB::table('employee_monthly_claims as emc')
            ->select('emc.id as id','e.fullName as fullname', 'emc.created_at as created_on',
            	'for_month', 'shortfall','bto_amount','target_amount','final_amount_commision_applicable','commision_applicable',
                  DB::raw(' sum(eoc.claim_amount) as claim_amount') , DB::raw('FORMAT(sum(claim_amount)+commision_applicable,2) as FinalCommission'),'approval_status')
            ->join('employees as e ','emc.employee_id','=','e.employeeID')
            ->leftJoin('employee_other_claims as eoc', 'emc.id', '=', 'eoc.employee_monthly_claim_id' );
            ->groupBy('emc.id');*/

         return  Datatables::of($result)
         ->edit_column('created_at',function($row){
                return date('d-M-Y',strtotime($row->created_at));
            })->add_column('edit', '
            <a  class="btn purple"  href="javascript:void(0)" onclick="edit_view({{$id}})" ><i class="fa fa-edit"></i> View/Edit</a>')->make();
//            ->remove_column('id')->make(); 

	}

	public function submit_claim_status(){
		$input = Input::all();
		$msg = '';
		$employee_claim_id_str = $input['employee_claim_id'];
		$employee_claim_id_arr = explode( ",", $employee_claim_id_str);
		
		foreach ($employee_claim_id_arr as $key => $employee_claim_id ) {
			$employee_claim   =   Employee_monthly_claims::find($employee_claim_id);
				$employeeID = $employee_claim->employee_id;

	            $employee = Employee::where(["employeeID"=>$employeeID])->first();
			if( $employee_claim->approval_status != $input['approval_status'] ){
	            

	            $this->data['claim_status'] = $input['approval_status'];
		        $this->data['employee_name'] = $employee->fullName;
		        //$this->data['comments'] = $input['comments'];

		        Mail::send('emails.admin.commission_status_changed', $this->data, function ($message) use ($employee) {
		            $message->from($this->data['setting']->email, $this->data['setting']->name);
		            $message->to($employee->email, $employee->fullName)
		                ->subject('Commision claim status changed! ');
		        });
		        Mail::send('emails.admin.commission_status_changed', $this->data, function ($message) use ($employee) {
		            $message->from($this->data['setting']->email, $this->data['setting']->name);
		            $message->to('sudhirpur123@gmail.com', $employee->fullName)
		                ->subject('Commision claim status changed! ');
		        });
				$employee_claim->approval_status=$input['approval_status'];
	    		$msg.= "\n ".$employee->fullName."'s claim sttus set to ".$input['approval_status']." successfully";
//				$employee_claim->comments=$input['comments'];
				$employee_claim->save();
	    	}else{
	    		$msg.= "\n ".$employee->email.$employee->fullName."'s claim sttus already set to ".$input['approval_status'];
	    	}
		}
	    	echo $msg;
	}

	public function submit_single_claim_status(  ){
    	$input = Input::all();
		$employee_claim   =   Employee_monthly_claims::find($input['employee_claim_id']);

		if( $employee_claim->approval_status != $input['approval_status'] ){
			$employeeID = $employee_claim->employee_id;
            
            $employee = Employee::where(["employeeID"=>$employeeID])->first();

            $this->data['claim_status'] = $input['approval_status'];
	        $this->data['employee_name'] = $employee->fullName;
	        $this->data['comments'] = $input['comments'];

	        Mail::send('emails.admin.commission_status_changed', $this->data, function ($message) use ($employee) {
	            $message->from($this->data['setting']->email, $this->data['setting']->name);
	            $message->to($employee->email, $employee->fullName)
	                ->subject('Commision claim status changed! ');
	        });
	        Mail::send('emails.admin.commission_status_changed', $this->data, function ($message) use ($employee) {
	            $message->from($this->data['setting']->email, $this->data['setting']->name);
	            $message->to('sudhirpur123@gmail.com', $employee->fullName)
	                ->subject('Commision claim status changed! ');
	        });

    	}
		$employee_claim->approval_status=$input['approval_status'];
		$employee_claim->comments=$input['comments'];
		$employee_claim->save();
	}

    //Datatable ajax request
    public function ajax_commision()
    {
        $result = Commision::
            select('id','tier','comm_type','tier_amount','comm_amount')
            ->orderBy('created_at','desc');

        return Datatables::of($result)
            ->add_column('edit', '
                        <a  class="btn purple"  href="{{ route(\'admin.commision.edit\',$id)}}" ><i class="fa fa-edit"></i> View/Edit</a>
                            &nbsp;<!--a href="javascript:;" onclick="del(\'{{ $id }}\',\'{{ $tier ." ". $comm_type}}\');return false;" class="btn red">
                        <i class="fa fa-trash"></i> Delete</a-->')
            ->make();
    }

    public function saveCommisionConfig(){
    	$input = Input::all();
  //  	echo "input is ";
    //	print_r( $input );
		$commision_config   =   Commision_config::find(1);

    	if( isset( $input['target_amount'] ) ){
    		if( (int)$input['target_amount'] >=1 ){
    			$comm_conf['target_amount'] = $input['target_amount'];
    			$commision_config->target_amount = $input['target_amount'];
    		}
    	}
    	if( isset( $input['status'] ) ){
    		$commision_config->commision_enabled = 1;
    	}else{
    		$commision_config->commision_enabled = 0;
    	}
		$commision_config->save();
		echo json_encode( array("status"=>"success", "msg"=>"Updated successfully") );
    }
	
	public function create()
	{
        $this->data['commisionAddActive']    =   'active';


		return View::make('admin.commision.create',$this->data);
	}

	/**
	 * Store a newly created Commision in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($input = Input::all(), Commision::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}
        //----------------   Check if Bill is attached or not


        $input['purchaseDate']   =   date('Y-m-d',strtotime( $input['purchaseDate']));
	    $commision =	Commision::create($input);

		return Redirect::route('admin.commision.index')->with('success',"<strong>{$input['itemName']}</strong> successfully added to the Database");;
	}



	/**
	 * Show the form for editing the specified commision.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$this->data['commision'] = Commision::find($id);
		return View::make('admin.commision.edit', $this->data);
	}

	/**
	 * Update the specified commision in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$commision = Commision::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Commision::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

		$commision->update($data);

        Session::flash('success',"<strong>Tier {$data['tier']}</strong> updated successfully");
		return Redirect::route('admin.commision.edit',$id);
	}

	/**
	 * Remove the specified commision from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (Request::ajax()) {

			Commision::destroy($id);
			$output['success'] = 'deleted';

			return Response::json($output, 200);
		}
	}

}
