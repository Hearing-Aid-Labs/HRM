<?php

class LoansController extends \AdminBaseController {



    public function __construct()
    {
        parent::__construct();
        $this->data['LoansOpen'] ='active open';
        $this->data['pageTitle'] ='Loan';
    }

    public function index()
	{
	    $this->data['Loans']  = Loan::all();
            $this->data['loansActive']    =   'active';
            return View::make('admin.loans.index', $this->data);
	}

    //Datatable ajax request
    public function ajax_loans()
    {
        $result = Loan::
            select('id','employeeID','itemName','purchaseFrom','purchaseDate','price')
            ->orderBy('created_at','desc');
        
        $this->data['employees'] = Loan::selectRaw('SUM(price) as total')
	                                        ->where('status','=','active');

        return Datatables::of($result)
            ->edit_column('purchaseDate',function($row){
                return date('d-M-Y',strtotime($row->purchaseDate));
            })
            ->add_column('edit', '
                        <a  class="btn purple"  href="{{ route(\'admin.loans.edit\',$id)}}" ><i class="fa fa-edit"></i> View/Edit</a>
                            &nbsp;<a href="javascript:;" onclick="del(\'{{ $id }}\',\'{{ $itemName }}\');return false;" class="btn red">
                        <i class="fa fa-trash"></i> Delete</a>')
            ->make();
    }


	public function create()
	{
        $this->data['loansAddActive']    =   'active';
        $this->data['employees'] = Employee::selectRaw('CONCAT(fullName, " (EmpID:", employeeID,")") as full_name, employeeID')
	                                        ->where('status','=','active')
	                                        ->lists('full_name','employeeID');

            return View::make('admin.loans.create',$this->data);
	}

	/**
	 * Store a newly created expense in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make($input = Input::all(), Loan::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}
        //----------------   Check if Bill is attached or not


        $input['purchaseDate']   =   date('Y-m-d',strtotime( $input['purchaseDate']));
	    $loan =	Loan::create($input);

        if (Input::hasFile('bill')) {

            $loan = loan::find($loan ->id);

            $path = public_path()."/loan/bills/";
            File::makeDirectory($path, $mode = 0777, true, true);

            $file 	= Input::file('bill');
            $extension      = $file->getClientOriginalExtension();
            $filename	= "bill-{$loan->slug}.$extension";
            Input::file('bill')->move($path, $filename);
            $loan->bill = $filename;

            $loan->save();

        }
		return Redirect::route('admin.loans.index')->with('success',"<strong>{$input['itemName']}</strong> successfully added to the Database");;
	}



	/**
	 * Show the form for editing the specified expense.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$this->data['loan'] = Loan::find($id);
		return View::make('admin.loans.edit', $this->data);
	}

	/**
	 * Update the specified expense in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$loan= Loan::findOrFail($id);

		$validator = Validator::make($data = Input::all(), Loan::$rules);

		if ($validator->fails())
		{
			return Redirect::back()->withErrors($validator)->withInput();
		}

        $data['purchaseDate']   =   date('Y-m-d',strtotime( $data['purchaseDate']));


        if (Input::hasFile('bill')) {

            $path = public_path()."/loan/bills/";
            File::makeDirectory($path, $mode = 0777, true, true);

            $file 	= Input::file('bill');
            $extension      = $file->getClientOriginalExtension();
            $filename	= "bill-{$loan->slug}.$extension";

            Input::file('bill')->move($path, $filename);
            $data['bill'] = $filename;

        }else{
            $data['bill'] = $data['billhidden'];
        }
            unset($data['billhidden']);
		$loan->update($data);

        Session::flash('success',"<strong>{$data['itemName']}</strong> updated successfully");
		return Redirect::route('admin.loans.edit',$id);
	}

	/**
	 * Remove the specified expense from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (Request::ajax()) {

			Expense::destroy($id);
			$output['success'] = 'deleted';

			return Response::json($output, 200);
		}
	}

}
