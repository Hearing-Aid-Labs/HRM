<?php
/*
 * Admin Login Controller
 */

class AdminLoginController extends AdminBaseController {


    public function __construct()
    {
        parent::__construct();
    }

/*  When Admin is not logged in show the login page.
 *  Otherwise redirect to Dashboard
 */
	public function index()
	{
		if(Auth::admin()->check())
		{
       
           return Redirect::to('/admin/dashboard');
		}else{

			return View::make('admin/login',$this->data);
		}	
	}


/*
 * When login button of admin is clicked .This Method checks the credentails from
 * Database and return as success value.
 */
	public function ajaxAdminLogin()
	{

		$input = Input::all();
		
		$data	=	[
			'email'	    =>	$input['email'],
			'password'	=>	$input['password']
		];

		//Rules to validate the incoming username and password
		$rules  =[
			'email'	=> 'required',
			'password'	=>	'required'
		];

		$validator	= Validator::make($input,$rules);


		//if validator fails then move to this block
		if($validator->fails())
		{	
			$output['status']	=	'error';
			//Check if login is from lock screen or from login page 
			$output['msg']		=	(Session::get("lock")!=1)	?	'Both Fields are Required':'Password is required';
			
		}
		// Check if admin exists in database with the credentials of not 
		else if (Auth::admin()->attempt($data,true))
        {        	
			$event = Event::fire('auth.login', Auth::admin()->get());
            $admin=DB::table('admins')->where('email',$data['email'])->first();
            Session::put('admin_type', $admin->admin_type);
			Session::put('lock', '0'); //Reset the lock screen session;
			$output['status']	=	'success';
			$output['msg']		=	'Logged in Successfully';
		}
		//Show error Message if admin with posted data doesnot exists
		else
		{
			$output['status']	=	'error';
			//Check if login is from lock screen or from login page
			$output['msg']		=	(Session::get("lock")!=1)	?	'Wrong Login Details':'Wrong Password';
			
		}

		return Response::json($output, 200); 


	}



/*
 * When logout button of admin panel is clicked.This method is called.This method destroys all the
 * the session stored and redirect to the Login Page
 */
	public function logout()
	{
		Auth::admin()->logout();
        Session::forget('admin_type');
		return Redirect::route('admin.getlogin');
	}
     public function reset_password_send_email()
    {
        $email=Input::get('email');
        if(!$user=DB::table('admins')->where('email',$email)->first())
        {
             return Redirect::back()->withErrors(['The email you entered does not belong to any account']);
        }
        $token=md5(rand(5, 15)).time().md5(time());
        $ar['reset_password_token']=$token;
        DB::table('admins')->where('id',$user->id)->update($ar);
        $this->data['token']=$token;
        $this->data['user']=$user;
        $this->data['is_admin']=1;
        Mail::send('emails.reset_password', $this->data, function ($message) use ($email) {
                            $message->from($this->data['setting']->email, $this->data['setting']->name);
                            $message->to($email)
                                ->subject('Reset Password');
                        });
        Session::flash('message', 'The reset password link has been sent to your email account please check you email account');                
        return Redirect::back();
        
    }
    public function reset_password($id=null,$token=null)
    {    
          if($id)
          {  
              $user=DB::table('admins')->where('id',$id)->first();
              if($user->reset_password_token==$token)
              {
                   return View::make('admin.reset_change_password',$this->data);
              }   
              else
              {
                  echo "<h3>Link is expired or invalid token</h3>";
                  exit;
              }
          }
          else
          {
            return View::make('admin.reset_password',$this->data);
          }  
    }
    public function change_password($id,$token)
    {
        $user=DB::table('admins')->where('id',$id)->first();
        if($user->reset_password_token!=$token)
        {
          echo "<h3>Link is expired or invalid token</h3>";
          exit;
        }
        $password=Input::get('password');
        $confirm_password=Input::get('confirm_password');
        if($password!=$confirm_password)
        {
            return Redirect::back()->withErrors(['Confirm password and password must match']);
            
        }  
        else
        {
              $ar['password']=Hash::make($password); 
              DB::table('admins')->where('id',$id)->update($ar);
              Session::flash('message', 'Your new  password has been reset');
              return Redirect::to('/admin');
        }
        
    }
}