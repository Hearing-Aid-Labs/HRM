<?php
/*
 * Attendance Controller of Admin Panel
 */
class SlipsController extends \AdminBaseController {


    public function __construct()
    {
        parent::__construct();
        $this->data['pageTitle'] =      'Slips';
          
    }  
    public function index()
    {
    
        $this->data['employees']=Employee::where('status','active')
        ->orderBy('fullName','asc')
        ->get();
        $this->data['slipActive']  =   'active open';
         return View::make('admin.slips.index',$this->data);    
    }
    public function add()
    {
        if(Input::has('employee_id'))
        {
            $ar['employee_id']=Input::get('employee_id');
            if(Input::hasFile('slip'))
            {
                  $destinationPath= public_path().'/employee_documents/slips/';
                  $name=rand()."_".time()."_".Input::file('slip')->getClientOriginalName();
                  Input::file('slip')->move($destinationPath, $name);
                
            }
            $ar['slip']= $name;
            $ar['date_created']=date('Y-m-d H:i:s');
            $ar['note']=Input::get('note');
            DB::table('payment_slips')->insert($ar);
        }
        Session::flash('success',"Slip created successfully");
        return Redirect::back();
        
    }
   public function get_payment_slips()
   {
        $result = DB::table('payment_slips')
            ->select('payment_slips.date_created','payment_slips.note','employees.fullName','payment_slips.slip','payment_slips.id')
	        ->join('employees', 'employees.id', '=', 'payment_slips.employee_id')
            ->orderBy('payment_slips.id','desc');
            
         return  Datatables::of($result)->make();	
       
   }
   public function get_slip($id)
   {
     $slip= DB::table('payment_slips')->where('id',$id)->first();
      echo json_encode($slip);
      exit;    
   }
   public function update()
   {
       if(Input::has('slip_id'))
        {
             $slip_id=Input::get('slip_id');
             $ar['note']=Input::get('note');
             DB::table('payment_slips')->where('id',$slip_id)->update($ar);
        }
        Session::flash('success',"Slip updated successfully!");
        return Redirect::back();
        
       
   }
   public function delete($id)
   {
        DB::table('payment_slips')
                   ->where('id',$id) 
                   ->delete();
        Session::flash('success',"Slip deleted successfully");
        return Redirect::back();        
   
       
   }
   public function commissions($month="",$year="",$return_array=false)
   {
       $api_key="ZcExXcxdqqgyUaDYrmfSoKfGNiXTaLIZN";
       $api_url="http://hearingaidlabs.co.za/stock/v3/Api/getCommissions";
        if($month!="" && $year!="")
       {
           $api_url.="/".$month."/".$year;
       }
       else{
           $month=date('m');
           $year=date('Y');
       }
       $api_url.="?api_key=".$api_key;
       $this->data['commission_month']=$month."-".$year;
       $commissons= file_get_contents($api_url);
       $this->data['commissions']= $commissons=json_decode($commissons); 
          if(isset($_GET['export_to_csv']))
          {
              $results[]=['Employee Name','Employee Id','Commission','Bto'];
              
                foreach($commissons as $commission)
                {
                    $ar=array();
                    $ar[]=$commission->first_name." ".$commission->last_name;
                     $ar[]=$commission->employeeID;
                     $ar[]=$commission->commission ;
                     $ar[]=$commission->bto;
                     $results[]=$ar;
                }
              $this->array_to_csv_download($results);
          }
         else if($return_array){
             
             return  $commissons;
         } 
      else{
             $this->data['commissionsActive']  =   'active open';
             return View::make('admin.slips.commissions',$this->data);     
      }
   
   }
    function payrolls($month="",$year="")
    {
          if($month=="")
          {
              $year=date('Y', strtotime('last month'));
              $month=date('m', strtotime('last month'));
          }
          
          $this->data['payrollActive'] ="active";    
          $commissions=$this->commissions($month,$year,true);  
          $this->data['commissions']=$commissions;
          $employees=Employee::where('status','active')->join('salary','salary.employeeID','=','employees.employeeID')
          ->leftjoin('designation','employees.designation','=','designation.id')
          ->leftjoin('department','designation.deptID','=','department.id')
          ->select("employees.*","salary.salary","designation.designation as designation_name","department.deptName")
          ->get();
          $csv_ar=[];
          $csv_ar[]=array("employeeID","Employee Name","Fater Name","Occupation","Branch","Period","Basic Salary","Commission","Cell Phone","Travel Allowance (Fuel)","Bonuses","Staff Uniform","Fines","Staff Loans","Medical Aid","Overtime","Overtime Sunday","Garnishes");
          foreach($employees as $employee)
          {
              $ar['employeeID']=$employee->employeeID;
              $ar['fullName']=$employee->fullName;
              $ar['fatherName']=$employee->fatherName;
              $ar['role']=$employee->designation_name;
              $ar['deptName']=$employee->deptName;
              $ar['period']="";
              $ar['salary']=$employee->salary;
              $ar['commission']=NULL;
              foreach($commissions as $commission)
              {
                  if($commission->employeeID==$employee->employeeID)
                  {
                     if($commission->commission_status==1)
                     { 
                       $employee->commission =$commission->commission;  
                       $ar['commission']=$employee->commission;   
                     }
                  }
              }
            $ar["CellPhone"]="";
            $ar["TravelAllowance"]="";
            $ar["Bonuses"]="";
            $ar["StaffUniform"]="";
            $ar["Fines"]="";
            $ar["StaffLoans"]="";
            $ar["MedicalAid"]="";
            $ar["Overtime"]="";
            $ar["OvertimeSunday"]="";
            $ar["Garnishes"]="";
              $csv_ar[]=$ar;
          }
           if(isset($_GET['export_to_payroll_csv']))
          {
              
             $this->array_to_csv_download($csv_ar);    
          }
          $this->data['employees']=$employees;
          return View::make('admin.slips.payrolls',$this->data);    
    }
  function array_to_csv_download(array $array) {
    
    if (count($array) == 0) {
        return null;
    }
    
    $filename = "data_export_" . date("Y-m-d") . ".csv";
    // disable caching
    $now = gmdate("D, d M Y H:i:s");
    header("Expires: Tue, 03 Jul 2001 06:00:00 GMT");
    header("Cache-Control: max-age=0, no-cache, must-revalidate, proxy-revalidate");
    header("Last-Modified: {$now} GMT");
 
    // force download  
    header("Content-Type: application/force-download");
    header("Content-Type: application/octet-stream");
    header("Content-Type: application/download");
 
    // disposition / encoding on response body
    header("Content-Disposition: attachment;filename={$filename}");
    header("Content-Transfer-Encoding: binary");
 
    $df = fopen("php://output", 'w');
   // fputcsv($df, array_keys(reset($array)));
    foreach ($array as $row) {
        fputcsv($df, $row);
    }
    fclose($df);
    die();    
}
  
/*
 * This is the view page of attendance.
 */
	
		

}
