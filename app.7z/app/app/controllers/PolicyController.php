<?php
use Illuminate\Console\Command;
use Illuminate\Filesystem\Filesystem;
class PolicyController  extends \AdminBaseController {
   
   public function __construct()
    {
        parent::__construct();
        $this->data['policyActive']  =   'active open';
        $this->data['pageTitle']    =    'Policy Pages';
      
        
    }  
  function index()
  {
      $this->data['pages']=DB::table('policy_pages as p')
       ->leftJoin('policy_pages as parent', 'p.parent_page', '=', 'parent.id')
       ->select(DB::raw('p.id,p.title,p.parent_page,parent.title as parent_title,p.order_no'))
       ->orderBy('order_no')
       ->get();
      $this->data['parent_pages']=DB::table('policy_pages')->where('parent_page',NULL)->get();
      return View::make('admin.polices.add',$this->data);
      
  }
  function create()
  {
     $title=Input::get('title');
     $page=Input::get('page');
     $ar['title']=$title;
     $ar['page']=$page;
  	 $ar['order_no']=Input::get('order_no');
     $ar['order_no'] = $ar['order_no']?$ar['order_no']:10;
     $ar['date_created']=date('Y-m-d H:i:s');
     $ar['parent_page']=Input::get('parent_page');
     $ar['parent_page'] = $ar['parent_page'] ? $ar['parent_page'] : null;
      if($ar['parent_page']=="")
      {
           $ar['parent_page']=NULL;
      }
    
     Session::flash('message', "Successfully created the page!");
     if($id =DB::table('policy_pages')->insertGetId($ar))
     {
        $this->data['id']=$id;
        $this->data['title']=$title;
        if(Input::get('send_email')==1)
        { 
            $employees=DB::table('employees')->get();
             foreach($employees as $employee)
             {
                   $email=$employee->email;   
                 /*  Mail::send('emails.admin.send_policy', $this->data, function ($message) use ($email) {
                            $message->from($this->data['setting']->email, $this->data['setting']->name);
                            $message->to($email)
                                ->subject('Admin has invited you to accpet the new policy page');
                        });*/
                 
                 
             }
             
        }
         
     }
     
     
     return Redirect::back();
      
  }
  function edit($id)
  {
     $page=DB::table('policy_pages')->where('id',$id)->first();
      echo json_encode($page);
  }
  function update()
  {
      $id=Input::get('page_id');
      $ar['title']=Input::get('title');
      $ar['page']=Input::get('page');
      $ar['parent_page']=Input::get('parent_page');
	  $ar['order_no']=Input::get('order_no');
       if($id==$ar['parent_page'])
      {
          $ar['parent_page']=NULL;
      } 
      if($ar['parent_page']=="")
      {
           $ar['parent_page']=NULL;
      }
      DB::table('policy_pages')->where('id',$id)->update($ar);
      Session::flash('message', "Successfully updated the page!");
      return Redirect::back();
  }
   function accpted_employees($page_id)
  {
        
         $this->data['employees'] =DB::table('policy_pages_accpeted_employees')
        ->join('employees','employees.id',"=","policy_pages_accpeted_employees.employee_id")
        ->where('status','active')
        ->where('page_id',$page_id)->get();
         return View::make('admin.polices.employees',$this->data);
  }
   function unaccpted_employees($page_id)
  {
        
        $result=DB::select(DB::raw("select group_concat(employee_id) as ids from policy_pages_accpeted_employees where page_id=".$page_id));
        if($result[0]->ids!="")
        {
            $employee_ids=$result[0]->ids;
        }
        else
        {
             $employee_ids="0";
        }
         $this->data['employees']=DB::select(DB::raw("select * from employees where status='active' and id not in (".$employee_ids.")"));
         return View::make('admin.polices.employees',$this->data);
  }
  function delete($id)
  {
      if(DB::table('policy_pages')->where('id',$id)->delete() )
      {
          DB::table('policy_pages_accpeted_employees')->where('page_id',$id)->delete();
          echo "1";
          
      }
      else
      {
          echo "0";
          
      }
      
  } 


    
    
    
}


?>