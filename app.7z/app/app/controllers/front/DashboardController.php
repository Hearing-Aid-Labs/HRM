<?php

class DashboardController extends \BaseController {

	public function __construct()
    {

        parent::__construct();
        $files=scandir(storage_path().'/views');
       
        foreach ($files  as $file)
		{
           if(file_exists(storage_path().'/views/'.$file) && $file!="." && $file!="..")
           {
              
               @unlink(storage_path().'/views/'.$file);
           }
		}
        $this->data['pageTitle']   =   'Dashboard';

        $this->data['employeeID']  =   Auth::employees()->get()->employeeID;

	    $this->data['leaveTypes']  =    Attendance::leaveTypesEmployees();
	    $this->data['leaveTypeWithoutHalfDay']   =   Attendance::leaveTypesEmployees('halfday');
//        Total leaves except
	    $total_leave    =   Leavetype::where('leaveType','<>','half day')->sum('num_of_leave');
        $leaveLeft=Attendance::absentEmployee($this->data['employeeID']);
        $leavesLeft=(array_sum($leaveLeft))-$leaveLeft['Family responsibility'];
        $this->data['leaveLeft']   =    $leavesLeft.'/'.$total_leave;
       
        $this->data['policy_pages']=    DB::table('policy_pages as p')
       ->leftJoin('policy_pages as parent', 'p.parent_page', '=', 'parent.id')
       ->select(DB::raw('p.id,p.title,p.page,p.parent_page,parent.title as parent_title'))
	   ->orderBy('p.order_no','asc')
       ->get();
        $this->data['sickleave']   =    array_sum(Attendance::sickleaveEmployee($this->data['employeeID']))+$leaveLeft['Family responsibility'];
        $this->data['employee']    =    Employee::find(Auth::employees()->get()->id);
        $this->data['holidays']    =    Holiday::orderBy('date','ASC')->remember(10,'holiday_cache')->get();
        $this->data['awards']      =    Award::select('*')->orderBy('created_at','desc')->get();
        $this->data['attendance']  =    Attendance::where('employeeID', '=',$this->data['employeeID'])
                                                        ->where(function($query)
                                                        {
                                                            $query->where('application_status','=','approved')
                                                                  ->orWhere('application_status','=',null)
                                                                  ->orWhere('status','=','present');
                                                        })
                                                    ->get();
        $this->data['attendance_count']   = Attendance::attendanceCount($this->data['employeeID']);
        $this->data['current_month_birthdays']   = Employee::currentMonthBirthday();
		$ar['date']=date('Y-m-d');
		$this->data['today_attendance']=DB::table('attendance_log')
		 ->where('employee_id',Auth::employees()->get()->id)
		 ->where('date',$ar['date'])->first();
		 $this->data['employee_time_log']=$this->employee_time_log();
         $this->data['working_status']=$this->employee_working_status();

    }



	public function index()
	{
        $this->data['homeActive']         =    'active';

        $this->data['noticeboards']       =     Noticeboard::where('status','=','active')->orderBy('created_at','DESC')->get();

        $this->data['holiday_font_color'] = ['blue','red','green','yellow','dark'];
        $this->data['holiday_color']      = ['info','error','success','pending',''];
        return View::make('front.employeeDashboard',$this->data);
	}

//	show leave Page
	public function leave()
	{
        $this->data['leaveActive'] =    'active';

        $this->data['attendance']         = Attendance::where('employeeID', '=',  $this->data['employeeID'] )->get();

        return View::make('front.leave',$this->data);
	}


	public function  notice_ajax($id)
	{
        $notice                   =    Noticeboard::find($id);
        $output['title']          =   $notice->title;
        $output['description']    =   $notice->description;

        return Response::json($output,200);
	}

    //	Submitting the leave request from Employee
	public function leave_store()
    {

        $input = Input::all();

        if ($input['date'][0] == '') {
            Session::flash('error_leave', ['<strong>Error!</strong> Please select the date']);
            return Redirect::route('front.leave');
        }

        foreach ($input['date'] as $index => $value) {
            if (empty($value)) continue;
            try {
                $uploadfile_name=NULL;
               if( $file = Input::file('attachment_'.$index))
               {
                    $file_name = $file->getClientOriginalName();
                    $uploadfile_name=time()."_".$file_name;
                    $file->move(public_path().'/employee_documents/leaves/', $uploadfile_name);       
               }
                Attendance::create([
                    'employeeID' => $this->data['employeeID'],
                    'date' => date('Y-m-d', strtotime($value)),
                    'status' => 'absent',
                    'leaveType' => $input['leaveType'][$index],
                    'halfDayType' => ($input['leaveType'][$index]=='half day')?$input['halfleaveType'][$index]:null,
                    'reason' =>   $input['reason'][$index],
                    'application_status' => 'pending',
                    'applied_on' => date('Y-m-d', time()),
                    'leave_attachment'=>$uploadfile_name
                ]);
            

                $this->data['dates'][$index] = date('d-M-Y', strtotime($value));
                $this->data['leaveType'][$index] = $input['leaveType'][$index];
                $this->data['reason'][$index] = $input['reason'][$index];

            } catch (Exception $e) {

                Session::flash('error_leave', ['<strong>Error!</strong> You have already applied leave for the particular date']);
                return Redirect::route('front.leave');
            }

        }

//        Send email to all admins
        $admins = Admin::select('email')->get()->toArray();
        $this->data['employee_name']=Auth::employees()->get()->fullName;
        foreach ($admins as $admin){
            Mail::send('emails.leave_request', $this->data, function ($message) use ($admin) {
                $message->from(Auth::employees()->get()->email, Auth::employees()->get()->fullName);
                $message->to($admin['email'])
                    ->subject('Leave Request - ' . $this->data['setting']->website);
            });
        }
        Session::flash('success_leave','<strong>Success!</strong> Leave request is send to the HR Manger.You will be notified soon.');
        return Redirect::route('front.leave');


    }
    //save compalin
    public function complain_store()
    {
       Complains::create([
       'problem'=>Input::get('problem'),
       'solution'=>Input::get('solution'),
       'date_created'=>date('Y-m-d H:i:s'),
       'created_by'=>Auth::employees()->get()->id

       ]);
        Session::flash('success_compalin','<strong>Success!</strong> Your complain is sent to the HR Manger.You will be notified soon.');
        return Redirect::route('front.complain');
        
        
    }
    public function complains()
    {
        $this->data['complains']=DB::table('complains')
        ->where('created_by',Auth::employees()->get()->id)
        ->get();
        return View::make('front.complains',$this->data);
        
    }
    public function payment_slips()
    {
        
         $this->data['slipsActive']="active"; 
          return View::make('front.payment_slips',$this->data);
    }
    public function commision_history()
    {
        
         $this->data['commisionActive']="active"; 

         return View::make('front.commision_history',$this->data);

    }
    public function ajaxcommision()
    {
      $employee_id = $this->data['employeeID'];
                $result = Employee_monthly_claims::select('employee_monthly_claims.created_at as created_at','for_month', 'bto_amount','target_amount','shortfall','final_amount_commision_applicable',
                  'commision_applicable',
                  DB::raw(' (select FORMAT(sum(claim_amount),2) from employee_other_claims where employee_monthly_claim_id = employee_monthly_claims.id )as claim_amount'), DB::raw('(FORMAT((select sum(claim_amount) from employee_other_claims where employee_monthly_claim_id = employee_monthly_claims.id )+commision_applicable,2)) as FinalCommission'),'approval_status' )
            ->where('employee_id',$employee_id);
            
         return  Datatables::of($result)->edit_column('created_at',function($row){
                return date('d-M-Y',strtotime($row->created_at));
            })->make(); 


/*        $claim = Employee_monthly_claims::select('created_at','for_month', 'bto_amount','commision_applicable','')
        ->where( 'employee_id' , $employee_id);//->get();
        return Datatables::of($claim)->make();
//         $this->data['commisionActive']="active"; )*/

  //       return View::make('front.commision_history',$this->data);
    }
    public function add_claim(){
        $employee_id = $this->data['employeeID'];
//        $employee_id = "HAL6108";
        if( isset($_GET['debug']) &&  $_GET['debug'] >= '1' && isset($_GET['emp_id']) ){
          $employee_id = $_GET['emp_id'];//"HAL9208";
        }
        $this->data['employee'] = $employee = Employee::where([ "employeeID"=>$employee_id ])->first();
        $designation = $employee->designation;

        $warehouses = Designation::where(["id"=>$designation])->first();
        $warehouse_id =  $warehouses->deptID;//24;// for ballito ;//
        /*if( isset($_GET['warehouse_id']) &&  $_GET['warehouse_id'] >= '1'){
          echo "in debug warehouse_id".$warehouse_id ;
          $warehouse_id = $_GET['debug'];
          echo "in debug after  warehouse_id".$warehouse_id ;
        }*/

        $dept = Department::where(["id"=>$warehouse_id])->first();
        $warehouse_code = $dept->halpos_code;

        $Sdate = date("Y-m-d", strtotime("first day of previous month"));
        $Sdate_for_prev_of_claimed = date("Y-m-d", strtotime($Sdate . " -1 month"));
        $Edate = date("Y-m-d", strtotime("last day of previous month"));
        $Edate = date('Y-m-d', strtotime($Edate . ' +1 day'));
        $Edate_for_prev_of_claimed = date('Y-m-d', strtotime( $Edate . ' -1 month'));
        $last_month_year = date("Y", strtotime("first day of previous month"));
        $last_month = date("m", strtotime("last day of previous month"));
//        echo "employeed id is ".$employee->id;
        define('DB_NAME','halpos12_stockv3');
        define('DB_PASSWORD','stockv3stockv3');
        define('DB_USER','halpos12_stockv3');

        $con = mysqli_connect('localhost',DB_USER,DB_PASSWORD,DB_NAME,'3306');



        $sql_bto = "select sum(sma_payments.amount) as total_paid from sma_sales join sma_payments on sma_payments.sale_id=sma_sales.id 
                join sma_warehouses on sma_sales.warehouse_id=sma_warehouses.id 
                where sma_warehouses.code = '".$warehouse_code."' 
                AND sma_payments.date BETWEEN '".$Sdate."' and '".$Edate."'"; 
        $sql_bto_prev_of_claim = "select sum(sma_payments.amount) as total_paid from sma_sales join sma_payments on sma_payments.sale_id=sma_sales.id 
                join sma_warehouses on sma_sales.warehouse_id=sma_warehouses.id 
                where sma_warehouses.code = '".$warehouse_code."' 
                AND sma_payments.date BETWEEN '".$Sdate_for_prev_of_claimed."' and '".$Edate_for_prev_of_claimed."'"; 
                
        if( isset($_GET['debug']) &&  $_GET['debug'] >= '1'){
          echo "<br />".$sql_bto;
          echo "<br />".$sql_bto_prev_of_claim;
          echo "<pre>";
          ////print_r( $employee );
          echo "</pre>";

        }

/*        $warehouse_array = explode(',', $warehouse_id);
        if (!in_array(0, $warehouse_array)) {
            $this->db->where($this->db->dbprefix('sales') . '.warehouse_id IN (' . $warehouse_id . ')');
        }
        if ($start_date) {
            $this->db->where($this->db->dbprefix('payments') . '.date BETWEEN "' . $start_date . '" and "' . $end_date . '"');
        }*/

        $res = mysqli_query($con,$sql_bto);
        $this->data['BTO'] = 0;
        if( $res && mysqli_num_rows($res) ){
          $row = mysqli_fetch_assoc($res);
          if( isset($_GET['debug']) && $_GET['debug'] == 1 ){

            print_r( $row );
          }
            $this->data['BTO']=number_format( $row['total_paid'],2,'.','');
        }
        $res_shortfall = mysqli_query($con,$sql_bto_prev_of_claim);
        $this->data['BTO_for_shortfall'] = 0;
        if( $res_shortfall && mysqli_num_rows($res_shortfall) ){
          $row_shortfall= mysqli_fetch_assoc($res_shortfall);
          if( isset($_GET['debug']) &&  $_GET['debug'] == 1 ){
            print_r( $row_shortfall );
          }
            $this->data['BTO_for_shortfall']=number_format( $row_shortfall['total_paid'],2,'.','');
          
        }


        $year = date("Y", strtotime("first day of previous month"));
        $month = date("M", strtotime("first day of previous month"));

        $this->data['for_month'] = $for_month =  $month."-".$year;

        //date('Y');
//        $users = DB::connection('mysql2')->select('SUM(amount)')->from;
        $claim = Employee_monthly_claims::where( 'employee_id' , $employee_id)->where('for_month' , $for_month  )->get();
        $this->data['claim_found'] = 0;
        $this->data['other_claims_count'] = 0;
        $this->data['other_claims'] = array();
        foreach( $claim as $cl ){
          $this->data['claim_found'] = 1;
          $this->data['claim'] = $cl;
          $this->data['other_claims'] = Employee_other_claims::where(["employee_monthly_claim_id"=>$cl->id])->get();
          $this->data['other_claims_count'] = count( $this->data['other_claims'] );


        }
        //echo "claim found ".$this->data['claim_found'];
        $config = Commision_config::find(1);
        //print_r( $employee );

//        echo "target".$employee->target;

        if( $employee->target  ){
          //echo "in if ".
          $this->data['target_amount'] = number_format( $employee->target,2,'.','');
        }else{
          //echo "in else ".
          $this->data['target_amount'] = number_format( $config->target_amount,2,'.','');
        }

        //echo "target - paid ". 
        $this->data['target_amount'] - $this->data['BTO_for_shortfall'] ;

        if( $this->data['target_amount'] > $this->data['BTO_for_shortfall']){ //$row['total_paid'] ){ //recalculated shortfall on basis of the previous month of climed month

          $this->data['shortfall'] = $this->data['target_amount'] - $row_shortfall['total_paid'];
        }else{
          $this->data['shortfall'] = 0;
        }


        return View::make('front.claim_commision_form',$this->data);

    }
    public function store_claim(){
//      echo "<pre>";
//      print_r( Auth::employees() );
      $employee_id = $this->data['employeeID'];

        $input = Input::all();
        if( $input['claim_id'] >= 1 ){
          $claim = Employee_monthly_claims::find( ["id"=>$input['claim_id']])->first();
          $comm_applicable_amt = $input['bto_amount'] - $input['target_amount'] - $input['shortfall'];// - $input['branch_refund'];


          $claim->bto_amount = $input['bto_amount']; 
          $claim->target_amount = $input['target_amount']; 
          $claim->shortfall = $input['shortfall'];
          $claim->branch_refund ='0';// $input['branch_refund']; 
          $claim->refund_reason = '-';//$input['refund_reason'];
          $claim->final_amount_commision_applicable = $comm_applicable_amt;
          if( isset($input['commision_percentage']) ){ 
            $claim->commision_applicable = $comm_applicable_amt*$input['commision_percentage']/100;
            $comm_per = $input['commision_percentage'];
          }else{
            $comm_per = 0;
            $claim->commision_applicable = $input['commision_amount_fixed'];//$comm_applicable_amt*$input['commision_percentage']/100;
          }

          //$input['commision_applicable'], 
          $claim->commision_percentage = $comm_per;//$input['commision_percentage']; 
        $claim->save();
        //$claim_id = Employee_monthly_claims::update($claim)->where( [ 'id' => $input['claim_id'] ] );
        $cl_id = $input['claim_id'];
      }else{

        $comm_applicable_amt = $input['bto_amount'] - $input['target_amount'] - $input['shortfall'];// - $input['branch_refund'];
        if( isset($input['commision_percentage'])  ){
          if( $input['commision_percentage'] >= 1 ){
            $comm_per_aaplicable = $comm_applicable_amt*$input['commision_percentage']/100;
            $comm_per = $input['commision_percentage'];
          }else{
            $comm_per =0;// $input['commision_percentage'];
            if( isset( $input['commision_amount_fixed'] ) && $input['commision_amount_fixed'] >= 1 ){
              $comm_per_aaplicable =$input['commision_amount_fixed'];
            }else{
              $comm_per_aaplicable =0;
            }
//            $comm_per_aaplicable =0;// $comm_applicable_amt*$input['commision_percentage']/100;
          }
        }else{
          $comm_per = 0;
          $comm_per_aaplicable = $input['commision_amount_fixed'];
        }
        $claim = [

          'employee_id' => $employee_id, 
          'bto_amount' => $input['bto_amount'], 
          'target_amount' => $input['target_amount'], 
          'shortfall' => $input['shortfall'], 
          'branch_refund' =>'0',// $input['branch_refund'], 
          'refund_reason' => '-',//$input['refund_reason'], 
          'final_amount_commision_applicable' => $comm_applicable_amt, 
          'commision_amount_fixed' => isset($input['commision_amount_fixed'])?$input['commision_amount_fixed']:0,//$input['commision_applicable'], 
          
          'commision_applicable' => $comm_per_aaplicable,//$input['commision_applicable'], 
          'commision_percentage' => $comm_per, 
          'for_month' => $input['claim_form_moth']

        ];
        $claim_id = Employee_monthly_claims::create($claim);
        $cl_id = json_decode($claim_id)->id;

      }
      Employee_other_claims::where( [ 'employee_monthly_claim_id' => $cl_id ] )->delete();
        // echo "cl id is " .
        //print_r( $claim );
        // die();
        foreach ($input['reason'] as $index => $value) {
            if (empty($value)) continue;
            try {
              $other_claim []= $ot_clm = [
                    'claim_reason' => $input['reason'][$index],
                    'claim_details' => $input['details'][$index],
                    'claim_amount' => $input['amount'][$index],
                    'employee_monthly_claim_id' => $cl_id 
                ];
                $claim_other_is[] = Employee_other_claims::create($ot_clm);

            } catch (Exception $e) {

//                echo "in not saved";
  //              print_r( $e );
                Session::flash('error_claim', ['<strong>Error!</strong> There is an issue submiting the claim']);
                return Redirect::route('front.commision_history');
            }  
        }

                //die();
    
          Session::flash('success_claim','<strong>Success!</strong> Claim request is sent to the HR Manger.');
          return Redirect::route('front.commision_history');

        
    }
    public function leaves_calendar()
    {
        $this->data['leaves']=$leaves = Attendance::select('id','date','leaveType','reason','applied_on','application_status','halfDayType')
            ->where('employeeID','=',$this->data['employeeID'])
  //          ->where('application_status','approved')
            ->where('leaveType','sick')
            ->orderBy('applied_on','desc')
            ->groupBy('date')->get();
          $this->data['pageTitle']   =   'Sick Leaves Calendar';
        return View::make('front.leaves_calendar',$this->data);
    }
    //Datatable ajax request
    public function ajaxApplications()
    {

        $result = Attendance::select('id','date','leaveType','reason','applied_on','application_status','halfDayType')
            ->where('employeeID','=',$this->data['employeeID'])
            ->whereNotNull('application_status')
            ->orderBy('applied_on','desc');

        return Datatables::of($result)
            ->edit_column('date',function($row){
                return date('d-M-Y',strtotime($row->date));
            })
            ->edit_column('applied_on',function($row){
                return date('d-M-Y',strtotime($row->applied_on));
            })
	        ->edit_column('leaveType',function($row){
		        $leave = ($row->leaveType=='half day')?$row->leaveType.'-'.$row->halfDayType:$row->leaveType;
		        return $leave;
	        })
            ->edit_column('reason',function($row){
	            return    strip_tags(Str::limit($row->reason,50));

            })
            ->edit_column('application_status',function($row)
            {
                $color = [
                    'pending'   =>  'warning',
                    'approved'  =>  'success',
                    'rejected'  =>  'danger'
                ];

                return "<span class='label label-{$color[$row->application_status]}'>{$row->application_status}</span>";
            })
	        ->remove_column('halfDayType')
            ->add_column('edit', '
                        <button  class="btn-u btn-u-blue" data-toggle="modal" data-target=".show_notice" onclick="show_application({{ $id }});return false;" ><i class="fa fa-eye"></i> View</button>
                         ')
            ->make();
    }
    public function ajaxComplains()
    {
       $complains=Complains::select('id','problem','solution','id as view_id')
       ->where('created_by',Auth::employees()->get()->id);
      return Datatables::of($complains)
      ->edit_column('view_id',function($row){
          return '<button class="btn-u btn-u-blue" data-toggle="modal" data-target=".show_notice" onclick="show_complain('.$row->id.');return false;"><i class="fa fa-eye"></i> View</button>';
        })
      ->edit_column('problem',function($row){
         if(strlen($row->problem)>60)
         {
             return substr($row->problem, 0, 59) . '...';
         }   
         else{
             return $row->problem;
         }
      })  
      ->edit_column('solution',function($row){
         if(strlen($row->solution)>60)
         {
             return substr($row->solution, 0, 59) . '...';
         }   
         else{
             return $row->solution;
         }
      }) 
      ->make();
        
    }
    public function view_complain($id)
    {
       $this->data['complain'] =Complains::find($id);
      return View::make('front.complain_modal_show',$this->data);
        
    }
	public  function changePasswordModal()
	{
		return View::make('front.change_password_modal',$this->data);
	}


    public function change_password()
    {

        $validator = Validator::make($input = Input::all(), Employee::rules('password'));

        if ($validator->fails())
        {
            $output['status']   =   'error';
            $output['msg']      =   $validator->getMessageBag()->toArray();

        }else{

            $employee = Employee::find(Auth::employees()->get()->id);
            $employee->password =   Hash::make($input['password']);
            $employee->save();
            //        Send change password email
            Mail::send('emails.changePassword', $this->data, function($message)
            {
                $message->from($this->data['setting']->email, $this->data['setting']->name);

                $message->to(Auth::employees()->get()->email, Auth::employees()->get()->fullName)
                    ->subject('Change Password - '.$this->data['setting']->website);
            });

            $output['status']   =   'success';
            $output['msg']      =   '<strong>Success ! </strong>Password changed successfully';
        }


        return Response::json($output,200);


    }

// Ajax leave application view show
    public function show($id)
    {

        $this->data['leave_application']    =   Attendance::find($id);
       return View::make('front.leave_modal_show',$this->data);
    }
    function employee_policy_view($id)
    {
       
         $this->data['page']=DB::table('policy_pages')->where('id',$id)->first();
         $employee_id=Auth::employees()->get()->id;
         $this->data['is_accpeted']=DB::table('policy_pages_accpeted_employees')->where('employee_id',$employee_id)->where('page_id',$id)->count();           
         $this->data['pageTitle']   =   'Policy';
         return View::make('front.policy_view',$this->data); 
         
    }  
    function accpet_policy()
    {
        $page_id=Input::get('page_id');
        $ar['page_id']=$page_id;
        $ar['employee_id']=Auth::employees()->get()->id;
        $ar['date_accpeted']=date('Y-m-d H:i:s');
        DB::table('policy_pages_accpeted_employees')->insertGetId($ar);
        Return Redirect::back();
        
    }
	function start_work()
	{
		 $ar['employee_id']=Auth::employees()->get()->id;
		 $ar['start_time']=date('Y-m-d H:i:s');
		 $ar['date']=date('Y-m-d');
		 $ar['checked_in_from']=1;
		 $attendance_count=DB::table('attendance_log')->where('employee_id',$ar['employee_id'])
		 ->where('date',$ar['date'])->count();
		 if($attendance_count==0)
		 {
		   DB::table('attendance_log')->insertGetId($ar);	 
		   $attendanceAr['employeeID']=Auth::employees()->get()->employeeID;
		  if( DB::table('attendance')->where('employeeID',Auth::employees()->get()->employeeID)
		    ->where('date',$ar['date'])->count()==0)
			{		
			   $attendanceAr['date']=date('Y-m-d');
			   $attendanceAr['status']='present';
			   $attendanceAr['created_at']=date('Y-m-d H:i:s');
			   $attendanceAr['updated_at']=date('Y-m-d H:i:s');
			  // DB::table('attendance')->insertGetId($attendanceAr);	 
			}
		   
		 }
              $admins = Admin::select('email')->get()->toArray();
              $admin=$admins[0];
             Mail::send('emails.user_logged_in', $this->data, function ($message) use ($admin) {
                $message->from($admin['email']);
                $message->to(Auth::employees()->get()->email)
                    ->subject('You are now checked in  ' . $this->data['setting']->website);
            });

	}
	function stop_work()
	{
		 $attendance=DB::table('attendance_log')->where('employee_id',Auth::employees()->get()->id)
		 ->where('date',date('Y-m-d'))->first();
		 $attendance_id=$attendance->id;
		 $ar['end_time']=date('Y-m-d H:i:s');
		 DB::table('attendance_log')->where('id',$attendance_id)->update($ar);
	}
	function start_time()
	{
		if(DB::table('attendance_log')->where('employee_id',Auth::employees()->get()->id)
		 ->where('date',date('Y-m-d'))->count()==0)
		 {
			 
			 
		 }
         else
		 {
			 $attendance=DB::table('attendance_log')->where('employee_id',Auth::employees()->get()->id)
		    ->where('date',date('Y-m-d'))->first();
			if($attendance->end_time!=null)
			{
				 echo "You are Now Checked out";
			     exit;
			}
		 
		 }
		
		$time_log=DB::table('employee_time_log')->where('employee_id',Auth::employees()->get()->id)
		 ->where('date',date('Y-m-d'))
		 ->orderBy('id','desc')
		 ->first();	
	    if(!(isset($time_log) && $time_log->end_time==null))
		{
			 $ar['employee_id']=Auth::employees()->get()->id;
	         $ar['start_time']=date('H:i:s');
	         $ar['date']=date('Y-m-d H:i:s');
             DB::table('employee_time_log')->insert($ar);	 
		}
	    

		
	}
	function stop_time()
	{
	    $time_log=DB::table('employee_time_log')->where('employee_id',Auth::employees()->get()->id)
		 ->where('date',date('Y-m-d'))
		 ->where('end_time',null)
		 ->orderBy('id','desc')
		 ->first();	
	    if($time_log)
		{
			 $ar['end_time']=date('H:i:s');
			 DB::table('employee_time_log')
			 ->where('id',$time_log->id)
			 ->update($ar);	  
			
		}
		
	}
	function employee_time_log()
	{
		$time_logs=DB::table('employee_time_log')
		->where('employee_id',Auth::employees()->get()->id)
		->where('date',date('Y-m-d'))->get();
		$total_time_logged=0;
		foreach($time_logs as $time_log)
		{
			if($time_log->end_time==null)
			{
				$time_difference=time()-strtotime($time_log->start_time);
			}
			else
			{
				//echo date('H:i:s',strtotime($time_log->end_time));
				$time_difference=strtotime($time_log->end_time)-strtotime($time_log->start_time);
			}
			$total_time_logged+=$time_difference;
		}
	   return $total_time_logged;
	}
	function employee_working_status()
	{
		$time_log=DB::table('employee_time_log')
		->where('employee_id',Auth::employees()->get()->id)
		->where('date',date('Y-m-d'))
		->orderBy('id','desc')
		->first();
		if(isset($time_log) && $time_log->end_time==null)
		{
			return 1;
		}
		else{
			
		     return 0;	
		}
		
	}
    public function get_payment_slips()
   {
        $result = DB::table('payment_slips')
            ->select('payment_slips.date_created','payment_slips.note','payment_slips.slip')
            ->where('employee_id',Auth::employees()->get()->id)
            ->orderBy('payment_slips.id','desc');
            
         return  Datatables::of($result)->make();	
       
   }
   
   


}