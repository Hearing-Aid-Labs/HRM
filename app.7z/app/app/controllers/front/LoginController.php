<?php

class LoginController extends \BaseController {


    public function __construct()
    {
      ini_set( 'display_errors', 1);
      error_reporting(E_ALL);
        parent::__construct();
        $this->data['pageTitle']    =   'Login Page';
    }

	public function index()
	{

        if(Auth::employees()->check())
        {
            return Redirect::route('dashboard.index');
        }else
        {
            return View::make('front.login',$this->data);
        }

	}

    public function ajaxLogin()
    {
        if (Request::ajax())
        {
            $output =   [];
            $input  = Input::all();

            $data	=	[
                'email'	    =>	$input['email'],
                'password'	=>	$input['password'],
	            'status'    =>  'active'
            ];

            //Rules to validate the incoming username and password
            $rules  =[
                'email'	    => 'required|email',
                'password'	=>	'required'
            ];

            $validator	= Validator::make($input,$rules);


            //if validator fails then move to this block
            if($validator->fails())
            {
                $output['status'] = 'error';
                $output['msg']    =  $validator->getMessageBag()->toArray();

            }

            // Check if employee exists in database with the credentials of not
            if (Auth::employees()->attempt($data))
            {
		            Event::fire('auth.login', Auth::employees()->get());
		            $output['status'] = 'success';
		            $output['msg']    = Lang::get('messages.loginSuccess');

	                return Response::json($output, 200);
            }

	        // For Blocked Users
	        $data['status']         =   'inactive';
            if(Auth::employees()->validate($data))
            {
	            $output['status']	=	'error';
	            $output['msg']		=	['error'=>Lang::get('messages.loginBlocked')];

            }
            //Show error Message if Employee with posted data does not exists
            else
	        {
		        $output['status']	=	'error';
		        $output['msg']		=	['error'=>Lang::get('messages.loginInvalid')];

	        }

            return Response::json($output, 200);

        }
    }

    public function logout()
    {
        Auth::employees()->logout();

        return Redirect::to('/');
    }
    public function reset_password_send_email()
    {
        $email=Input::get('email');
        if(!$user=DB::table('employees')->where('email',$email)->first())
        {
             return Redirect::back()->withErrors(['The email you entered does not belong to any account']);
        }
        $token=md5(rand(5, 15)).time().md5(time());
        $ar['reset_password_token']=$token;
        DB::table('employees')->where('id',$user->id)->update($ar);
        $this->data['token']=$token;
        $this->data['user']=$user;
        Mail::send('emails.reset_password', $this->data, function ($message) use ($email) {
                            $message->from($this->data['setting']->email, $this->data['setting']->name);
                            $message->to($email)
                                ->subject('Reset Password');
                        });
        Session::flash('message', 'The reset password link has been sent to your email account please check you email account');                
        return Redirect::back();
        
    }
    public function reset_password($id=null,$token=null)
    {    
          if($id)
          {  
              $user=DB::table('employees')->where('id',$id)->first();
              if($user->reset_password_token==$token)
              {
                  
                   return View::make('front.reset_change_password',$this->data);
              }   
              else
              {
                    echo "<h3>Link is expired or invalid token</h3>";
                     exit;
                  
              }
              
          }
          else
          {
            return View::make('front.reset_password',$this->data);
          }  
    }
    public function change_password($id,$token)
    {
        $user=DB::table('employees')->where('id',$id)->first();
        if($user->reset_password_token!=$token)
        {
             echo "<h3>Link is expired or invalid token</h3>";
             exit;
        }
        $password=Input::get('password');
        $confirm_password=Input::get('confirm_password');
        if($password!=$confirm_password)
        {
            return Redirect::back()->withErrors(['Confirm password and password must match']);
            
        }  
        else
        {
              $ar['password']=Hash::make($password); 
              DB::table('employees')->where('id',$id)->update($ar);
              Session::flash('message', 'Your new  password has been reset');
              return Redirect::to('/');
        }
        
    }
    public function check_login_status()
   {
       if(Auth::employees()->check())
       {
           $ar['type']=1;
       }
       else{
            $ar['type']=0;
       }
       echo json_encode($ar);
   }
    

}